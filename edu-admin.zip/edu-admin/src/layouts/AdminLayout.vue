<template>
  <div class="admin-layout">
    <!-- 侧边栏 -->
    <aside :class="['sidebar', { collapsed }]">
      <div class="sidebar-header">
        <img src="/logo.svg" alt="logo" class="logo-img" />
        <span v-if="!collapsed" class="logo-text">知学管理后台</span>
      </div>

      <el-scrollbar class="sidebar-scroll">
        <el-menu
          :default-active="route.path"
          :collapse="collapsed"
          router
          background-color="#001529"
          text-color="rgba(255,255,255,0.65)"
          active-text-color="#fff"
        >
          <el-menu-item index="/dashboard">
            <el-icon><DataLine /></el-icon>
            <template #title>数据看板</template>
          </el-menu-item>

          <el-sub-menu index="course">
            <template #title>
              <el-icon><VideoCamera /></el-icon>
              <span>课程管理</span>
            </template>
            <el-menu-item index="/course/list">课程列表</el-menu-item>
            <el-menu-item index="/course/category">课程分类</el-menu-item>
            <el-menu-item index="/teacher/list">讲师管理</el-menu-item>
          </el-sub-menu>

          <el-sub-menu index="ops">
            <template #title>
              <el-icon><Operation /></el-icon>
              <span>运营管理</span>
            </template>
            <el-menu-item index="/banner/list">轮播图</el-menu-item>
            <el-menu-item index="/comment/list">评论管理</el-menu-item>
            <el-menu-item index="/quiz/list">题库管理</el-menu-item>
          </el-sub-menu>

          <el-menu-item index="/member/list">
            <el-icon><UserFilled /></el-icon>
            <template #title>用户管理</template>
          </el-menu-item>

          <el-menu-item index="/order/list">
            <el-icon><List /></el-icon>
            <template #title>订单管理</template>
          </el-menu-item>
        </el-menu>
      </el-scrollbar>
    </aside>

    <!-- 右侧区域 -->
    <div class="main-wrapper">
      <!-- 顶部栏 -->
      <header class="topbar">
        <el-button circle @click="collapsed = !collapsed" class="toggle-btn">
          <el-icon><Expand v-if="collapsed" /><Fold v-else /></el-icon>
        </el-button>

        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>{{ route.meta.title }}</el-breadcrumb-item>
        </el-breadcrumb>

        <div class="topbar-right">
          <el-dropdown trigger="click">
            <div class="admin-info">
              <el-avatar :size="32">A</el-avatar>
              <span>管理员</span>
              <el-icon><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- 页面内容 -->
      <main class="page-content">
        <RouterView />
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { DataLine, VideoCamera, Operation, UserFilled, List, Expand, Fold, ArrowDown } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const collapsed = ref(false)

const logout = () => {
  localStorage.removeItem('admin_token')
  router.push('/login')
}
</script>

<style lang="scss" scoped>
.admin-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.sidebar {
  width: 220px;
  background: #0f172a;
  display: flex;
  flex-direction: column;
  transition: width 0.2s;
  flex-shrink: 0;

  &.collapsed { width: 64px; }
}

.sidebar-header {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 0 16px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  overflow: hidden;

  .logo-img { width: 30px; height: 30px; flex-shrink: 0; }
  .logo-text { color: #fff; font-size: 15px; font-weight: 600; white-space: nowrap; }
}

.sidebar-scroll { flex: 1; }

:deep(.el-menu) { border-right: none !important; }
:deep(.el-menu-item.is-active) {
  background: var(--el-color-primary) !important;
  border-radius: 6px !important;
  margin: 2px 8px !important;
}

.main-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.topbar {
  height: 64px;
  background: #fff;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  padding: 0 24px;
  gap: 16px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.05);

  .toggle-btn { border: none; }
}

.topbar-right {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 16px;
}

.admin-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  color: #333;
  font-size: 14px;
}

.page-content {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  background: #f0f2f5;
}
</style>
