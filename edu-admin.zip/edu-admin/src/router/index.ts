import { createRouter, createWebHistory } from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/login/LoginPage.vue'),
    meta: { title: '管理员登录' },
  },
  {
    path: '/',
    component: () => import('@/layouts/AdminLayout.vue'),
    meta: { requiresAuth: true },
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/DashboardPage.vue'),
        meta: { title: '数据看板', icon: 'DataLine' },
      },
      // 课程管理
      {
        path: 'course/list',
        name: 'CourseList',
        component: () => import('@/views/course/CourseListPage.vue'),
        meta: { title: '课程列表', icon: 'VideoCamera' },
      },
      {
        path: 'course/edit/:id?',
        name: 'CourseEdit',
        component: () => import('@/views/course/CourseEditPage.vue'),
        meta: { title: '编辑课程' },
      },
      {
        path: 'course/category',
        name: 'CategoryList',
        component: () => import('@/views/course/CategoryPage.vue'),
        meta: { title: '课程分类', icon: 'Grid' },
      },
      {
        path: 'teacher/list',
        name: 'TeacherList',
        component: () => import('@/views/teacher/TeacherListPage.vue'),
        meta: { title: '讲师管理', icon: 'User' },
      },
      // 运营管理
      {
        path: 'banner/list',
        name: 'BannerList',
        component: () => import('@/views/banner/BannerListPage.vue'),
        meta: { title: '轮播图管理', icon: 'PictureFilled' },
      },
      {
        path: 'comment/list',
        name: 'CommentList',
        component: () => import('@/views/comment/CommentListPage.vue'),
        meta: { title: '评论管理', icon: 'ChatDotRound' },
      },
      // 用户管理
      {
        path: 'member/list',
        name: 'MemberList',
        component: () => import('@/views/member/MemberListPage.vue'),
        meta: { title: '用户管理', icon: 'UserFilled' },
      },
      // 订单管理
      {
        path: 'order/list',
        name: 'OrderList',
        component: () => import('@/views/order/OrderListPage.vue'),
        meta: { title: '订单管理', icon: 'List' },
      },
      // 题库管理
      {
        path: 'quiz/list',
        name: 'QuizList',
        component: () => import('@/views/quiz/QuizListPage.vue'),
        meta: { title: '题库管理', icon: 'EditPen' },
      },
    ],
  },
  { path: '/:pathMatch(.*)*', redirect: '/' },
]

const router = createRouter({
  history: createWebHistory('/admin/'),
  routes,
})

router.beforeEach((to, from, next) => {
  NProgress.start()
  document.title = `${to.meta.title || '管理后台'} - 知学在线`

  if (to.meta.requiresAuth) {
    const token = localStorage.getItem('admin_token')
    if (!token) {
      next({ name: 'Login', query: { redirect: to.fullPath } })
      return
    }
  }
  next()
})

router.afterEach(() => NProgress.done())

export default router
