<template>
  <div class="banner-page">
    <div class="page-header">
      <h2>轮播图管理</h2>
      <el-button type="primary" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增轮播图
      </el-button>
    </div>

    <el-table :data="banners" border v-loading="loading" style="width:100%">
      <el-table-column label="轮播图" width="220">
        <template #default="{ row }">
          <img :src="row.imageUrl" :alt="row.title" style="width:200px;height:75px;object-fit:cover;border-radius:4px" />
        </template>
      </el-table-column>
      <el-table-column label="标题" prop="title" min-width="160" />
      <el-table-column label="链接" prop="linkUrl" min-width="200" show-overflow-tooltip />
      <el-table-column label="排序" prop="sort" width="80" align="center" />
      <el-table-column label="状态" width="80" align="center">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">
            {{ row.status === 1 ? '显示' : '隐藏' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="130" align="center">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="openDialog(row)">编辑</el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 编辑弹窗 -->
    <el-dialog v-model="dialogVisible" :title="editRow ? '编辑轮播图' : '新增轮播图'" width="500px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="标题" prop="title">
          <el-input v-model="form.title" placeholder="轮播图标题" />
        </el-form-item>
        <el-form-item label="图片" prop="imageUrl">
          <el-upload
            class="banner-uploader"
            :show-file-list="false"
            :before-upload="beforeImageUpload"
            :http-request="handleUpload"
            accept="image/*"
          >
            <img v-if="form.imageUrl" :src="form.imageUrl" class="uploaded-image" />
            <el-icon v-else class="uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div style="color:#999;font-size:12px;margin-top:4px">支持 JPG、PNG 格式，建议尺寸 1920×600，建议不超过 10MB</div>
        </el-form-item>
        <el-form-item label="跳转链接">
          <el-input v-model="form.linkUrl" placeholder="点击跳转链接（可选）" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="0" :max="999" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" :active-value="1" :inactive-value="0" active-text="显示" inactive-text="隐藏" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import request from '@/utils/request'

const loading = ref(false)
const dialogVisible = ref(false)
const submitting = ref(false)
const banners = ref<any[]>([])
const editRow = ref<any>(null)
const formRef = ref<FormInstance>()

const form = reactive({ title: '', imageUrl: '', linkUrl: '', sort: 0, status: 1 })
const rules = {
  title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
  imageUrl: [{ required: true, message: '请上传图片', trigger: 'change' }]
}

// 轮播图上传
async function beforeImageUpload(file: File) {
  const isImage = file.type.startsWith('image/')
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isImage) {
    ElMessage.error('只能上传图片文件！')
    return false
  }
  if (!isLt10M) {
    ElMessage.error('图片大小不能超过 10MB！')
    return false
  }
  return true
}

async function handleUpload(option: any) {
  const { file, onSuccess, onError } = option
  try {
    const formData = new FormData()
    formData.append('file', file)
    const res = await request.post('/course/file/upload/banner', formData)
    form.imageUrl = res.data
    ElMessage.success('上传成功')
    onSuccess(res)
  } catch (e: any) {
    ElMessage.error(e.message || '上传失败')
    onError(e)
  }
}

async function loadData() {
  loading.value = true
  try {
    const res = await request.get('/course/banner')
    banners.value = res.data || []
  } catch { } finally { loading.value = false }
}

function openDialog(row?: any) {
  editRow.value = row || null
  if (row) Object.assign(form, row)
  else Object.assign(form, { title: '', imageUrl: '', linkUrl: '', sort: 0, status: 1 })
  formRef.value?.resetFields()
  dialogVisible.value = true
}

async function handleSubmit() {
  await formRef.value?.validate()
  submitting.value = true
  try {
    if (editRow.value) {
      await request.put(`/course/admin/banner/${editRow.value.id}`, form)
    } else {
      await request.post('/course/admin/banner', form)
    }
    ElMessage.success('操作成功')
    dialogVisible.value = false
    loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  } finally { submitting.value = false }
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm('确定删除该轮播图吗？', '提示', { type: 'warning' })
  try {
    await request.delete(`/course/admin/banner/${row.id}`)
    ElMessage.success('删除成功')
    loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(loadData)
</script>

<style scoped lang="scss">
.banner-page { padding: 20px; }
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}
.banner-uploader {
  :deep(.el-upload) {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: border-color 0.2s;
    &:hover { border-color: #409eff; }
  }
  .uploaded-image {
    width: 300px;
    height: 112px;
    object-fit: cover;
    display: block;
  }
  .uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 300px;
    height: 112px;
    text-align: center;
    line-height: 112px;
  }
}
</style>
