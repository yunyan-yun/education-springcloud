<template>
  <div class="comment-page">
    <div class="page-header">
      <h2>评论管理</h2>
    </div>

    <div class="filter-bar">
      <el-input v-model="keyword" placeholder="搜索课程名称/评论内容" clearable style="width:280px" @input="handleSearch">
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
      <el-select v-model="scoreFilter" placeholder="评分筛选" clearable style="width:120px" @change="handleSearch">
        <el-option label="全部" value="" />
        <el-option v-for="s in [1,2,3,4,5]" :key="s" :label="s + '星'" :value="s" />
      </el-select>
    </div>

    <el-table :data="tableData" border v-loading="loading" :key="tableKey" style="width:100%">
      <el-table-column label="课程" prop="courseName" min-width="160" show-overflow-tooltip />
      <el-table-column label="用户" width="120">
        <template #default="{ row }">
          <div class="user-cell">
            <el-avatar :size="32" :src="getAvatarUrl(row)" :style="getAvatarStyle(row.memberNickname)">
              {{ row.memberNickname?.charAt(0) || '?' }}
            </el-avatar>
            <span>{{ row.memberNickname }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="评分" width="90" align="center">
        <template #default="{ row }">{{ row.score }}星</template>
      </el-table-column>
      <el-table-column label="内容" prop="content" min-width="240" show-overflow-tooltip />
      <el-table-column label="时间" prop="createTime" width="160">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="90" align="center">
        <template #default="{ row }">
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-wrap">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="loadData"
        background
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import request from '@/utils/request'
import dayjs from 'dayjs'

const loading = ref(false)
const keyword = ref('')
const tableKey = ref(0)
const scoreFilter = ref<number | ''>('')
const tableData = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(15)

function formatTime(t: string) { return t ? dayjs(t).format('MM-DD HH:mm') : '-' }

// 头像加载失败时返回 false，使用默认字符显示
function handleAvatarError() { return false }

// 获取头像URL，无效时返回空
function getAvatarUrl(row: any) {
  if (!row.memberAvatar || row.memberAvatar.startsWith('data:') || !row.memberAvatar.includes('://')) {
    return ''
  }
  return row.memberAvatar
}

// 根据昵称生成头像颜色
function getAvatarStyle(nickname?: string) {
  const colors = ['#0891b2', '#67C23A', '#E6A23C', '#F56C6C', '#909399', '#06b6d4']
  const index = nickname ? (nickname.charCodeAt(0) || 0) % colors.length : 0
  return { backgroundColor: colors[index], color: '#fff', fontSize: '14px', fontWeight: 600 }
}

let searchTimer: ReturnType<typeof setTimeout>
function handleSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => { currentPage.value = 1; loadData() }, 300)
}

async function loadData() {
  loading.value = true
  try {
    const res = await request.get('/course/admin/comment/page', {
      params: { current: currentPage.value, size: pageSize.value, keyword: keyword.value, score: scoreFilter.value || undefined }
    })
    console.log('【DEBUG】评论接口返回：', JSON.stringify(res))
    const records = res.data?.records || res?.records || []
    total.value = res.data?.total || res?.total || 0

    // 批量获取用户头像
    const memberIds = [...new Set(records.filter((r: any) => r.memberId).map((r: any) => r.memberId))]
    const avatarMap: Record<number, string> = {}

    await Promise.all(memberIds.map(async (memberId: number) => {
      try {
        const avatarRes = await request.get(`/user/member/avatar/${memberId}`)
        if (avatarRes.data) {
          avatarMap[memberId] = avatarRes.data
        }
      } catch { }
    }))

    // 更新评论的头像
    records.forEach((r: any) => {
      if (r.memberId && avatarMap[r.memberId]) {
        r.memberAvatar = avatarMap[r.memberId]
      }
    })

    tableData.value = records
    tableKey.value++

    // 如果当前页已无数据且非第一页，自动回退上一页
    if (records.length === 0 && currentPage.value > 1) {
      currentPage.value--
      await loadData()
    }
  } catch { } finally { loading.value = false }
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm('确定删除该评论吗？', '提示', { type: 'warning' })
  try {
    await request.delete(`/course/admin/comment/${row.id}`)
    ElMessage.success('删除成功')
    await loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(loadData)
</script>

<style scoped lang="scss">
.comment-page { padding: 20px; }
.page-header {
  margin-bottom: 20px;
  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}
.filter-bar { display: flex; gap: 12px; margin-bottom: 16px; }
.user-cell { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
</style>
