<template>
  <div class="category-page">
    <div class="page-header">
      <h2>分类管理</h2>
      <el-button type="primary" @click="openAdd(null)">
        <el-icon><Plus /></el-icon> 新增一级分类
      </el-button>
    </div>

    <el-table
      :data="categoryTree"
      row-key="id"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      border
      v-loading="loading"
      style="width:100%"
    >
      <el-table-column label="分类名称" prop="name" min-width="200">
        <template #default="{ row }">
          <span v-if="row.icon" style="margin-right:8px">{{ row.icon }}</span>
          {{ row.name }}
        </template>
      </el-table-column>
      <el-table-column label="排序" prop="sort" width="80" align="center" />
      <el-table-column label="层级" width="100" align="center">
        <template #default="{ row }">
          <el-tag :type="row.parentId === 0 ? 'primary' : 'info'" size="small">
            {{ row.parentId === 0 ? '一级' : '二级' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200" align="center">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
          <el-button v-if="row.parentId === 0" link type="success" size="small" @click="openAdd(row.id)">
            添加子分类
          </el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新增/编辑弹窗 -->
    <el-dialog v-model="dialogVisible" :title="editId ? '编辑分类' : '新增分类'" width="420px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="父级分类" v-if="form.parentId !== 0">
          <el-select v-model="form.parentId" style="width:100%">
            <el-option label="顶级分类（一级）" :value="0" />
            <el-option v-for="c in rootCategories" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="名称" prop="name">
          <el-input v-model="form.name" placeholder="分类名称" />
        </el-form-item>
        <el-form-item label="图标">
          <el-input v-model="form.icon" placeholder="Emoji 图标（可选）" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="0" :max="999" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import request from '@/utils/request'

const loading = ref(false)
const dialogVisible = ref(false)
const submitting = ref(false)
const editId = ref<number | null>(null)
const formRef = ref<FormInstance>()
const categoryTree = ref<any[]>([])

const form = reactive({ name: '', parentId: 0, sort: 0, icon: '' })
const rules = { name: [{ required: true, message: '请输入名称', trigger: 'blur' }] }

const rootCategories = computed(() => categoryTree.value)

async function loadCategories() {
  loading.value = true
  try {
    const res = await request.get('/course/category')
    categoryTree.value = res.data || []
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

function openAdd(parentId: number | null) {
  editId.value = null
  Object.assign(form, { name: '', parentId: parentId ?? 0, sort: 0, icon: '' })
  formRef.value?.resetFields()
  dialogVisible.value = true
}

function openEdit(row: any) {
  editId.value = row.id
  Object.assign(form, { name: row.name, parentId: row.parentId, sort: row.sort, icon: row.icon || '' })
  dialogVisible.value = true
}

async function handleSubmit() {
  await formRef.value?.validate()
  submitting.value = true
  try {
    if (editId.value) {
      await request.put(`/course/admin/category/${editId.value}`, form)
      ElMessage.success('更新成功')
    } else {
      await request.post('/course/admin/category', form)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    loadCategories()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  } finally {
    submitting.value = false
  }
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm(`确定删除分类「${row.name}」吗？`, '提示', { type: 'warning' })
  try {
    await request.delete(`/course/admin/category/${row.id}`)
    ElMessage.success('删除成功')
    loadCategories()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(loadCategories)
</script>

<style scoped lang="scss">
.category-page { padding: 20px; }
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}
</style>
