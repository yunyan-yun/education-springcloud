<template>
  <div class="course-edit-page">
    <div class="page-header">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/admin/course/list' }">课程管理</el-breadcrumb-item>
        <el-breadcrumb-item>{{ isEdit ? '编辑课程' : '新增课程' }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <el-form ref="formRef" :model="form" :rules="rules" label-width="100px" class="edit-form">
      <!-- 隐藏的视频上传 input -->
      <input
        ref="videoInputRef"
        type="file"
        accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-msvideo"
        style="display:none"
        @change="handleVideoChange"
      />
      <div class="form-row">
        <!-- 左列 -->
        <div class="form-col">
          <div class="section-card">
            <div class="section-title">基本信息</div>
            <el-form-item label="课程标题" prop="title">
              <el-input v-model="form.title" placeholder="请输入课程标题" maxlength="50" show-word-limit />
            </el-form-item>
            <el-form-item label="副标题" prop="subTitle">
              <el-input v-model="form.subTitle" placeholder="课程副标题（可选）" maxlength="100" />
            </el-form-item>
            <el-form-item label="所属分类" prop="categoryId">
              <el-select v-model="form.categoryId" placeholder="选择分类" style="width:100%">
                <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
              </el-select>
            </el-form-item>
            <el-form-item label="所属讲师" prop="teacherId">
              <el-select v-model="form.teacherId" placeholder="选择讲师" style="width:100%" @change="onTeacherChange">
                <el-option v-for="t in teachers" :key="t.id" :label="t.name" :value="t.id" />
              </el-select>
            </el-form-item>
            <el-form-item label="是否免费">
              <el-switch v-model="form.isFree" :active-value="1" :inactive-value="0" active-text="免费" inactive-text="付费" @change="onFreeChange" />
            </el-form-item>
            <el-form-item label="课程价格" prop="price" v-if="!form.isFree">
              <el-input-number v-model="form.price" :min="0" :precision="2" :step="10" style="width:180px" />
              <span style="margin-left:8px;color:#999">元</span>
            </el-form-item>
            <el-form-item label="原价" v-if="!form.isFree">
              <el-input-number v-model="form.originalPrice" :min="0" :precision="2" :step="10" style="width:180px" />
            </el-form-item>
            <el-form-item label="是否推荐">
              <el-switch v-model="form.isRecommend" :active-value="1" :inactive-value="0" />
            </el-form-item>
            <el-form-item label="是否热门">
              <el-switch v-model="form.isHot" :active-value="1" :inactive-value="0" />
            </el-form-item>
            <el-form-item label="排序">
              <el-input-number v-model="form.sort" :min="0" :max="999" style="width:120px" />
            </el-form-item>
          </div>
        </div>

        <!-- 右列 -->
        <div class="form-col">
          <div class="section-card">
            <div class="section-title">封面与描述</div>
            <el-form-item label="课程封面" prop="cover">
              <el-upload
                class="cover-uploader"
                action="#"
                :show-file-list="false"
                :before-upload="beforeCoverUpload"
                accept="image/*"
              >
                <img v-if="form.cover" :src="form.cover" class="cover-preview" />
                <div v-else class="upload-placeholder">
                  <el-icon :size="40"><Plus /></el-icon>
                  <span>上传封面</span>
                </div>
              </el-upload>
              <div class="upload-tip">建议尺寸 16:9，JPG/PNG，建议不超过 10MB</div>
            </el-form-item>
            <el-form-item label="课程简介" prop="description">
              <el-input
                v-model="form.description"
                type="textarea"
                :rows="4"
                placeholder="课程简介，200字以内"
                maxlength="200"
                show-word-limit
              />
            </el-form-item>
          </div>

          <div class="section-card">
            <div class="section-title">课程详情</div>
            <el-form-item label="">
              <div class="rich-editor-tip">此处为富文本编辑区，实际项目接入 WangEditor 或 TipTap</div>
              <el-input
                v-model="form.detail"
                type="textarea"
                :rows="8"
                placeholder="课程详细介绍（支持HTML格式）"
              />
            </el-form-item>
          </div>
        </div>
      </div>

      <!-- 章节管理 -->
      <div class="section-card">
        <div class="section-title">
          章节管理
          <el-button size="small" type="primary" @click="addChapter" style="margin-left:16px">
            <el-icon><Plus /></el-icon> 新增章节
          </el-button>
          <el-button size="small" type="info" @click="addUnfinishedChapter" style="margin-left:8px">
            <el-icon><More /></el-icon> 未完待续
          </el-button>
        </div>
        <div v-if="chapters.length === 0" class="empty-chapter">暂无章节，请添加</div>
        <div v-else class="chapter-list">
          <div v-for="(ch, ci) in chapters" :key="ci" class="chapter-item">
            <div class="chapter-header">
              <span class="chapter-num">{{ ch.title === '未完待续...' ? '' : '第' + (ci + 1) + '章' }}</span>
              <el-input v-model="ch.title" placeholder="章节标题" size="small" style="width:280px" />
              <el-button size="small" type="primary" @click="addVideo(ci)" v-if="ch.title !== '未完待续...'">
                <el-icon><VideoCamera /></el-icon> 添加视频
              </el-button>
              <el-button size="small" type="danger" @click="chapters.splice(ci, 1)">删除</el-button>
            </div>
            <div class="chapter-desc" style="padding: 8px 14px 4px;">
              <el-input
                v-model="ch.description"
                type="textarea"
                :rows="2"
                placeholder="章节描述（可选，用于AI摘要生成）"
                maxlength="500"
                show-word-limit
                size="small"
              />
            </div>
            <div class="video-list" v-if="ch.videos && ch.videos.length > 0">
              <div v-for="(v, vi) in ch.videos" :key="vi">
                <div class="video-item">
                  <el-icon><VideoPlay /></el-icon>
                  <el-input v-model="v.title" placeholder="视频标题" size="small" style="width:160px" />
                  <el-button size="small" @click="openVideoUpload(ci, vi)" :type="v.videoUrl ? 'success' : 'default'">
                    <el-icon><Upload /></el-icon> {{ v.videoUrl ? '重新上传' : '上传视频' }}
                  </el-button>
                  <span v-if="v.videoUrl" class="video-name">{{ getVideoName(v.videoUrl) }}</span>
                  <span v-if="v.duration !== undefined && v.duration !== null" class="video-duration">{{ formatDuration(v.duration) }}</span>
                  <el-switch v-model="v.isFree" :active-value="1" :inactive-value="0" active-text="免费试看" size="small" />
                  <el-button size="small" type="danger" @click="ch.videos.splice(vi, 1)">删除</el-button>
                </div>
                <div class="video-desc" style="padding: 4px 0 8px 28px;">
                  <el-input
                    v-model="v.description"
                    type="textarea"
                    :rows="2"
                    placeholder="视频描述（可选，用于AI章节摘要生成）"
                    maxlength="1000"
                    show-word-limit
                    size="small"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 操作按钮 -->
      <div class="form-actions">
        <el-button type="primary" :loading="saving" @click="handleSave('draft')">
          保存草稿
        </el-button>
        <el-button type="success" :loading="saving" @click="handleSave('publish')">
          保存并发布
        </el-button>
        <el-button @click="$router.back()">取消</el-button>
      </div>
    </el-form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { Plus, VideoCamera, VideoPlay, Upload } from '@element-plus/icons-vue'
import request from '@/utils/request'

const route = useRoute()
const router = useRouter()
const formRef = ref<FormInstance>()
const saving = ref(false)
const categories = ref<any[]>([])
const teachers = ref<any[]>([])
const chapters = ref<any[]>([])

const isEdit = computed(() => !!route.params.id)

// 视频上传相关
const currentUploadChapter = ref(-1)
const currentUploadVideo = ref(-1)
const videoInputRef = ref<HTMLInputElement>()

function openVideoUpload(chapterIndex: number, videoIndex: number) {
  currentUploadChapter.value = chapterIndex
  currentUploadVideo.value = videoIndex
  videoInputRef.value?.click()
}

function getVideoName(url: string) {
  if (!url) return ''
  return decodeURIComponent(url.split('/').pop() || url)
}

// 获取视频时长（秒）- 使用真实URL获取
function getVideoDuration(url: string): Promise<number> {
  return new Promise((resolve) => {
    const video = document.createElement('video')
    let settled = false
    
    const settle = (duration: number) => {
      if (settled) return
      settled = true
      console.log('getVideoDuration resolve:', duration)
      resolve(duration)
    }
    
    video.onloadedmetadata = () => {
      console.log('loadedmetadata, duration:', video.duration)
      const d = video.duration
      if (isFinite(d) && !isNaN(d) && d > 0 && d < 86400) {
        settle(Math.floor(d))
      } else {
        // duration 还没准备好，等一下
        video.oncanplay = () => {
          console.log('canplay, duration:', video.duration)
          const dd = video.duration
          if (isFinite(dd) && !isNaN(dd) && dd > 0) {
            settle(Math.floor(dd))
          } else {
            settle(0)
          }
        }
      }
    }
    
    video.onerror = () => {
      console.log('视频加载失败')
      settle(0)
    }
    
    video.preload = 'metadata'
    video.muted = true
    video.src = url
    
    video.load()
    
    // 超时保护（视频URL可访问的话一般几秒内就能获取到时长）
    setTimeout(() => settle(0), 30000)
  })
}

// 格式化时长（秒 -> mm:ss）
function formatDuration(seconds: number): string {
  if (!seconds) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

async function handleVideoChange(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return

  // 检查文件类型
  const allowedTypes = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo']
  if (!allowedTypes.includes(file.type)) {
    ElMessage.error('只支持 MP4、WebM、OGG 格式视频')
    input.value = ''
    return
  }

  // 检查大小 (2GB限制)
  if (file.size > 2 * 1024 * 1024 * 1024) {
    ElMessage.error('视频大小不能超过 2GB')
    input.value = ''
    return
  }

  ElMessage.info('正在上传视频，请稍候...')
  const formData = new FormData()
  formData.append('file', file)

  try {
    // 视频上传需要较长超时时间（10分钟）
    const res = await request.post('/course/file/upload/video', formData, {
      timeout: 600000
    })
    const videoUrl = res.data
    const video = chapters.value[currentUploadChapter.value].videos[currentUploadVideo.value]
    video.videoUrl = videoUrl
    
    // 获取视频时长（使用上传后的真实URL）
    const duration = await getVideoDuration(videoUrl)
    console.log('上传后设置视频时长:', duration)
    video.duration = duration
    ElMessage.success('视频上传成功，时长：' + formatDuration(duration))
  } catch (e: any) {
    ElMessage.error(e.message || '上传失败')
  }

  input.value = ''
}

const form = reactive({
  title: '',
  subTitle: '',
  cover: '',
  description: '',
  detail: '',
  categoryId: null as number | null,
  categoryName: '',
  teacherId: null as number | null,
  teacherName: '',
  price: 0,
  originalPrice: 0,
  isFree: false,
  isRecommend: false,
  isHot: false,
  sort: 0
})

const rules = {
  title: [{ required: true, message: '请输入课程标题', trigger: 'blur' }],
  categoryId: [{ required: true, message: '请选择分类', trigger: 'change' }],
  teacherId: [{ required: true, message: '请选择讲师', trigger: 'change' }],
  cover: [{ required: true, message: '请上传课程封面', trigger: 'change' }],
  description: [{ required: true, message: '请输入课程简介', trigger: 'blur' }]
}

function onTeacherChange(id: number) {
  const t = teachers.value.find(t => t.id === id)
  if (t) form.teacherName = t.name
}

async function beforeCoverUpload(file: File) {
  const isImage = file.type.startsWith('image/')
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isImage) { ElMessage.error('只支持图片格式'); return false }
  if (!isLt10M) { ElMessage.error('图片大小不能超过10MB'); return false }
  
  // 上传到阿里云 OSS
  const formData = new FormData()
  formData.append('file', file)
  try {
    const res = await request.post('/course/file/upload/cover', formData)
    form.cover = res.data
    ElMessage.success('封面上传成功')
  } catch (e: any) {
    ElMessage.error(e.message || '上传失败')
  }
  return false
}

function addChapter() {
  chapters.value.push({ title: '第' + (chapters.value.length + 1) + '章', description: '', videos: [] })
}

function addUnfinishedChapter() {
  chapters.value.push({ title: '未完待续...', videos: [] })
}

function addVideo(chIndex: number) {
  chapters.value[chIndex].videos.push({ title: '', isFree: false, videoUrl: '', duration: 0, description: '' })
}

function onFreeChange(isFree: number) {
  if (isFree === 1) {
    chapters.value.forEach((chapter: any) => {
      chapter.videos.forEach((video: any) => {
        video.isFree = 1
      })
    })
    ElMessage.success('已设置全部视频为免费试看')
  }
}

async function handleSave(type: 'draft' | 'publish') {
  await formRef.value?.validate()
  saving.value = true
  try {
    const payload = { course: { ...form, status: type === 'publish' ? 1 : 0 }, chapters: chapters.value }
    if (isEdit.value) {
      await request.put(`/course/admin/course/${route.params.id}`, payload)
    } else {
      await request.post('/course/admin/course', payload)
    }
    ElMessage.success(type === 'publish' ? '发布成功' : '保存成功')
    router.push('/admin/course/list')
  } catch (e: any) {
    ElMessage.error(e.message || '保存失败')
  } finally {
    saving.value = false
  }
}

async function loadBasicData() {
  try {
    const [catRes, teacherRes] = await Promise.all([
      request.get('/course/category'),
      request.get('/course/admin/teacher/list')
    ])
    // 展平分类列表
    const flattenCats = (list: any[]): any[] => {
      return list.flatMap((c: any) => [c, ...(c.children ? flattenCats(c.children) : [])])
    }
    categories.value = flattenCats(catRes.data || []).filter((c: any) => c.parentId !== 0)
    teachers.value = teacherRes.data || []
  } catch (e) {
    console.error(e)
  }
}

async function loadCourse() {
  if (!isEdit.value) return
  try {
    const res = await request.get(`/course/admin/course/${route.params.id}`)
    const d = res.data
    // 后端返回 { course: {...}, chapters: [...] }
    const courseData = d.course || d
    Object.assign(form, courseData)
    if (d.chapters) chapters.value = d.chapters
  } catch (e) {
    ElMessage.error('加载课程数据失败')
  }
}

onMounted(async () => {
  await loadBasicData()
  await loadCourse()
})
</script>

<style scoped lang="scss">
.course-edit-page { padding: 20px; }

.page-header { margin-bottom: 20px; }

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}

.form-col { display: flex; flex-direction: column; gap: 20px; }

.section-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.section-title {
  font-size: 15px;
  font-weight: 600;
  color: #1f2329;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
}

.cover-uploader {
  :deep(.el-upload) {
    border: 2px dashed #ddd;
    border-radius: 8px;
    width: 200px;
    height: 113px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: border-color 0.2s;
    overflow: hidden;
    &:hover { border-color: #0891b2; }
  }
}

.cover-preview { width: 100%; height: 100%; object-fit: cover; }

.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #999;
  font-size: 13px;
}

.upload-tip { font-size: 12px; color: #999; margin-top: 6px; }

.rich-editor-tip {
  background: #fef3c7;
  color: #92400e;
  font-size: 12px;
  padding: 8px 12px;
  border-radius: 6px;
  margin-bottom: 8px;
  width: 100%;
}

.empty-chapter { color: #999; text-align: center; padding: 20px; }

.chapter-list { display: flex; flex-direction: column; gap: 12px; }

.chapter-item {
  border: 1px solid #e8e8e8;
  border-radius: 8px;
  overflow: hidden;
}

.chapter-header {
  background: #fafafa;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 10px;
  .chapter-num { font-size: 13px; color: #666; white-space: nowrap; }
}

.video-list { padding: 8px 14px; display: flex; flex-direction: column; gap: 8px; }

.video-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 8px;
  background: #f9f9f9;
  border-radius: 6px;
  font-size: 13px;
  color: #666;
  flex-wrap: wrap;
}
.video-name {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #67c23a;
  font-size: 12px;
}
.video-duration {
  color: #909399;
  font-size: 12px;
  background: #f0f0f0;
  padding: 2px 6px;
  border-radius: 3px;
}

.form-actions {
  background: #fff;
  border-radius: 10px;
  padding: 20px 24px;
  display: flex;
  gap: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}
</style>
