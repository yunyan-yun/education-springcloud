<template>
  <div class="course-list-page">
    <el-card shadow="never">
      <!-- 搜索栏 -->
      <div class="toolbar">
        <el-input v-model="searchKeyword" placeholder="搜索课程名称" clearable style="width: 240px" @change="loadCourses" />
        <el-select v-model="searchStatus" clearable placeholder="发布状态" style="width: 140px" @change="loadCourses">
          <el-option label="草稿" :value="0" />
          <el-option label="已发布" :value="1" />
          <el-option label="已下架" :value="2" />
        </el-select>
        <el-button type="primary" :icon="Plus" @click="$router.push('/course/edit')">新增课程</el-button>
      </div>

      <!-- 表格 -->
      <el-table :data="courses" v-loading="loading" stripe>
        <el-table-column prop="cover" label="封面" width="80">
          <template #default="{ row }">
            <el-image :src="row.cover" style="width: 60px; height: 40px; object-fit: cover; border-radius: 4px" />
          </template>
        </el-table-column>
        <el-table-column prop="title" label="课程名称" min-width="200" show-overflow-tooltip />
        <el-table-column prop="teacherName" label="讲师" width="100" />
        <el-table-column prop="categoryName" label="分类" width="100" />
        <el-table-column prop="price" label="价格" width="90">
          <template #default="{ row }">
            <span v-if="row.isFree" style="color: #ff6b35">免费</span>
            <span v-else>¥{{ row.price }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="studyCount" label="学习人数" width="100" />
        <el-table-column prop="score" label="评分" width="80" />
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusTypes[row.status]">{{ statusLabels[row.status] }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="$router.push(`/course/edit/${row.id}`)">编辑</el-button>
            <el-button v-if="row.status !== 1" link type="success" @click="publish(row)">发布</el-button>
            <el-button v-if="row.status === 1" link type="warning" @click="offline(row)">下架</el-button>
            <el-button link type="danger" @click="del(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          layout="total, sizes, prev, pager, next"
          :page-sizes="[10, 20, 50]"
          @change="loadCourses"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/request'

const courses = ref<any[]>([])
const loading = ref(false)
const searchKeyword = ref('')
const searchStatus = ref<number | ''>('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

const statusLabels = ['草稿', '已发布', '已下架']
const statusTypes = ['info', 'success', 'warning'] as const

onMounted(loadCourses)

async function loadCourses() {
  loading.value = true
  try {
    const res = await request.get('/course/admin/course/page', {
      params: {
        current: currentPage.value,
        size: pageSize.value,
        keyword: searchKeyword.value || undefined,
        status: searchStatus.value !== '' ? searchStatus.value : undefined,
      },
    })
    courses.value = res.data?.records || []
    total.value = res.data?.total || 0
  } finally {
    loading.value = false
  }
}

const publish = async (row: any) => {
  await request.put(`/course/admin/course/${row.id}/publish`)
  ElMessage.success('发布成功')
  loadCourses()
}

const offline = async (row: any) => {
  await request.put(`/course/admin/course/${row.id}/offline`)
  ElMessage.success('下架成功')
  loadCourses()
}

const del = async (row: any) => {
  try {
    await ElMessageBox.confirm(`确认删除课程「${row.title}」？`, '提示', { type: 'warning' })
    await request.delete(`/course/admin/course/${row.id}`)
    ElMessage.success('删除成功')
    loadCourses()
  } catch {
    // 用户点击取消，不做任何操作
  }
}
</script>

<style lang="scss" scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  align-items: center;
  flex-wrap: wrap;
}
.pagination { margin-top: 16px; display: flex; justify-content: flex-end; }
</style>
