<template>
  <div class="dashboard">
    <!-- 统计卡片 -->
    <el-row :gutter="24" class="stat-cards">
      <el-col :span="6" v-for="item in statCards" :key="item.key">
        <div class="stat-card" :style="{ background: item.bg }">
          <div class="stat-info">
            <div class="stat-value">{{ item.value }}</div>
            <div class="stat-label">{{ item.label }}</div>
          </div>
          <el-icon :size="48" style="opacity: 0.25; color: #fff">
            <component :is="item.icon" />
          </el-icon>
        </div>
      </el-col>
    </el-row>

    <!-- 图表区域 -->
    <el-row :gutter="24" class="charts-row">
      <el-col :span="16">
        <el-card shadow="never">
          <template #header>近7天数据趋势</template>
          <v-chart :option="lineChartOption" style="height: 300px;" autoresize />
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="never">
          <template #header>课程分类分布</template>
          <v-chart :option="pieChartOption" style="height: 300px;" autoresize />
        </el-card>
      </el-col>
    </el-row>

    <!-- 最新订单 -->
    <el-card shadow="never" class="recent-orders">
      <template #header>
        <div class="card-header">
          <span>最新订单</span>
          <el-button link type="primary" @click="$router.push('/order/list')">查看全部</el-button>
        </div>
      </template>
      <el-table :data="recentOrders" stripe>
        <el-table-column prop="orderNo" label="订单号" width="200" />
        <el-table-column prop="courseTitle" label="课程" show-overflow-tooltip />
        <el-table-column prop="totalAmount" label="金额" width="100">
          <template #default="{ row }">¥{{ row.totalAmount }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getOrderStatusType(row.status)">
              {{ getOrderStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="时间" width="180" />
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart, PieChart } from 'echarts/charts'
import { TitleComponent, TooltipComponent, LegendComponent, GridComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import request from '@/utils/request'

use([LineChart, PieChart, TitleComponent, TooltipComponent, LegendComponent, GridComponent, CanvasRenderer])

const statCards = ref([
  { key: 'users', label: '注册用户', value: '...', icon: 'UserFilled', bg: '#0891b2' },
  { key: 'courses', label: '课程总数', value: '...', icon: 'VideoCamera', bg: '#0d9488' },
  { key: 'orders', label: '今日订单', value: '...', icon: 'List', bg: '#0284c7' },
  { key: 'income', label: '今日收入', value: '¥...', icon: 'Money', bg: '#059669' },
])

const recentOrders = ref<any[]>([])

// 订单状态映射
function getOrderStatusText(status: number): string {
  const statusMap: Record<number, string> = {
    0: '待支付',
    1: '已支付',
    2: '已取消',
    4: '退款中',
    5: '已退款'
  }
  return statusMap[status] || '未知'
}

function getOrderStatusType(status: number): string {
  const typeMap: Record<number, string> = {
    0: 'warning',   // 待支付 - 黄色
    1: 'success',   // 已支付 - 绿色
    2: 'info',      // 已取消 - 灰色
    4: 'danger',    // 退款中 - 红色
    5: 'warning'    // 已退款 - 黄色
  }
  return typeMap[status] || 'info'
}

const lineChartOption = ref({
  tooltip: { trigger: 'axis' },
  legend: { data: ['新增用户', '订单数', '收入(百元)'] },
  grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
  xAxis: {
    type: 'category',
    data: ['3/31', '4/1', '4/2', '4/3', '4/4', '4/5', '4/6'],
  },
  yAxis: { type: 'value' },
  series: [
    { name: '新增用户', type: 'line', smooth: true, data: [120, 132, 101, 134, 90, 230, 210] },
    { name: '订单数', type: 'line', smooth: true, data: [80, 92, 61, 94, 60, 130, 110] },
    { name: '收入(百元)', type: 'line', smooth: true, data: [60, 72, 51, 84, 50, 120, 100] },
  ],
})

const pieChartOption = ref({
  tooltip: { trigger: 'item' },
  legend: { bottom: '0' },
  series: [{
    type: 'pie',
    radius: ['40%', '65%'],
    label: { show: false },
    data: [
      { value: 35, name: '前端开发' },
      { value: 30, name: '后端开发' },
      { value: 15, name: '移动开发' },
      { value: 12, name: '人工智能' },
      { value: 8, name: '云原生' },
    ],
  }],
})

onMounted(async () => {
  try {
    // 并行获取统计数据
    const [userRes, courseRes, orderRes, recentRes, userStatsRes, orderStatsRes, categoryRes] = await Promise.all([
      request.get('/user/admin/member/count'),
      request.get('/course/admin/course/count'),
      request.get('/order/admin/order/today-stats'),
      request.get('/order/admin/order/page', { params: { current: 1, size: 5 } }),
      request.get('/user/admin/member/stats/7days'),
      request.get('/order/admin/order/stats/7days'),
      request.get('/course/admin/course/stats/category-distribution')
    ])

    // 更新统计数据
    const userCount = userRes.data || 0
    const courseCount = courseRes.data || 0
    const todayOrders = orderRes.data?.todayOrders || 0
    const todayIncome = orderRes.data?.todayIncome || 0

    statCards.value[0].value = userCount.toLocaleString()
    statCards.value[1].value = courseCount.toLocaleString()
    statCards.value[2].value = todayOrders.toLocaleString()
    statCards.value[3].value = '¥' + Number(todayIncome).toLocaleString()

    // 更新最新订单
    recentOrders.value = recentRes.data?.records || []

    // 更新近7天趋势图
    if (userStatsRes.data && orderStatsRes.data) {
      lineChartOption.value = {
        tooltip: { trigger: 'axis' },
        legend: { data: ['新增用户', '订单数', '收入(百元)'] },
        grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
        xAxis: {
          type: 'category',
          data: userStatsRes.data.dates || orderStatsRes.data.dates || [],
        },
        yAxis: { type: 'value' },
        series: [
          { name: '新增用户', type: 'line', smooth: true, data: userStatsRes.data.userCounts || [] },
          { name: '订单数', type: 'line', smooth: true, data: orderStatsRes.data.orderCounts || [] },
          { name: '收入(百元)', type: 'line', smooth: true, data: orderStatsRes.data.incomes || [] },
        ],
      }
    }

    // 更新课程分类分布图
    if (categoryRes.data && categoryRes.data.length > 0) {
      pieChartOption.value = {
        tooltip: { trigger: 'item' },
        legend: { bottom: '0' },
        series: [{
          type: 'pie',
          radius: ['40%', '65%'],
          label: { show: false },
          data: categoryRes.data,
        }],
      }
    }
  } catch (e) {
    console.error('获取统计数据失败', e)
  }
})
</script>

<style lang="scss" scoped>
.dashboard { display: flex; flex-direction: column; gap: 24px; }

.stat-cards { margin-bottom: 0; }

.stat-card {
  border-radius: 12px;
  padding: 24px;
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;

  .stat-value { font-size: 32px; font-weight: 700; margin-bottom: 4px; }
  .stat-label { font-size: 14px; opacity: 0.85; }
}

.charts-row { margin-bottom: 0; }

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.recent-orders { background: #fff; }
</style>
