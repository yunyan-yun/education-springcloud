<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-header">
        <h2>知学在线 管理后台</h2>
        <p>请使用管理员账号登录</p>
      </div>
      <el-form :model="form" :rules="rules" ref="formRef" @submit.prevent="doLogin">
        <el-form-item prop="account">
          <el-input v-model="form.account" placeholder="账号/手机号" :prefix-icon="User" size="large" />
        </el-form-item>
        <el-form-item prop="password">
          <el-input v-model="form.password" type="password" placeholder="密码" :prefix-icon="Lock" size="large" show-password />
        </el-form-item>
        <el-button type="primary" native-type="submit" size="large" style="width: 100%" :loading="loading">
          登 录
        </el-button>
      </el-form>
      <p class="hint">默认账号：13800000000 / 123456</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { User, Lock } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

const router = useRouter()
const formRef = ref()
const loading = ref(false)
const form = ref({ account: '13800000000', password: '123456' })
const rules = {
  account: [{ required: true, message: '请输入账号' }],
  password: [{ required: true, message: '请输入密码' }],
}

const doLogin = async () => {
  await formRef.value.validate()
  loading.value = true
  try {
    const res = await axios.post('/api/user/auth/login', form.value)
    if (res.data.code === 200 && res.data.data.userInfo.role === 'admin') {
      localStorage.setItem('admin_token', res.data.data.token)
      router.push('/')
      ElMessage.success('登录成功')
    } else {
      ElMessage.error('您没有管理员权限')
    }
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ecfeff;
}
.login-card {
  background: #fff;
  padding: 40px;
  border-radius: 16px;
  width: 380px;
  box-shadow: 0 20px 60px rgba(8, 145, 178, 0.15);
}
.login-header {
  text-align: center;
  margin-bottom: 32px;
  h2 { font-size: 22px; color: #1a1a1a; font-weight: 600; }
  p { color: #646464; font-size: 14px; margin-top: 4px; }
}
.hint { text-align: center; color: #999; font-size: 12px; margin-top: 16px; }
</style>
