<template>
  <div class="member-page">
    <div class="page-header">
      <h2>用户管理</h2>
    </div>

    <div class="filter-bar">
      <el-input v-model="keyword" placeholder="搜索手机号/昵称" clearable style="width:240px" @input="handleSearch">
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
      <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width:120px" @change="handleSearch">
        <el-option label="全部" value="" />
        <el-option label="正常" :value="1" />
        <el-option label="禁用" :value="0" />
      </el-select>
    </div>

    <el-table :data="tableData" border v-loading="loading" style="width:100%">
      <el-table-column label="用户" min-width="160">
        <template #default="{ row }">
          <div class="user-cell">
            <el-avatar :size="36" :src="row.avatar" />
            <div>
              <div class="nickname">{{ row.nickname || row.username }}</div>
              <div class="mobile">{{ row.mobile }}</div>
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="邮箱" prop="email" min-width="160" show-overflow-tooltip />
      <el-table-column label="角色" width="90" align="center">
        <template #default="{ row }">
          <el-tag :type="row.role === 'admin' ? 'danger' : 'primary'" size="small">
            {{ row.role === 'admin' ? '管理员' : '普通用户' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="90" align="center">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'danger'" size="small">
            {{ row.status === 1 ? '正常' : '禁用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="注册时间" prop="createTime" width="160">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="160" align="center">
        <template #default="{ row }">
          <el-button
            link
            :type="row.status === 1 ? 'warning' : 'success'"
            size="small"
            @click="toggleStatus(row)"
            :disabled="row.role === 'admin'"
          >
            {{ row.status === 1 ? '禁用' : '启用' }}
          </el-button>
          <el-button
            link
            type="danger"
            size="small"
            @click="handleDelete(row)"
            :disabled="row.role === 'admin'"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-wrap">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="loadData"
        background
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import request from '@/utils/request'
import dayjs from 'dayjs'

const loading = ref(false)
const keyword = ref('')
const statusFilter = ref<number | ''>('')
const tableData = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(15)

function formatTime(t: string) { return t ? dayjs(t).format('YYYY-MM-DD HH:mm') : '-' }

let searchTimer: ReturnType<typeof setTimeout>
function handleSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => { currentPage.value = 1; loadData() }, 300)
}

async function loadData() {
  loading.value = true
  try {
    const res = await request.get('/user/admin/member/page', {
      params: {
        page: currentPage.value,
        size: pageSize.value,
        keyword: keyword.value,
        status: statusFilter.value !== '' ? statusFilter.value : undefined
      }
    })
    tableData.value = res.data?.records || []
    total.value = res.data?.total || 0
  } catch { } finally { loading.value = false }
}

async function toggleStatus(row: any) {
  const action = row.status === 1 ? '禁用' : '启用'
  await ElMessageBox.confirm(`确定${action}用户「${row.nickname || row.mobile}」吗？`, '提示', { type: 'warning' })
  try {
    await request.put(`/user/admin/member/${row.id}/status`, { status: row.status === 1 ? 0 : 1 })
    ElMessage.success(`${action}成功`)
    row.status = row.status === 1 ? 0 : 1
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  }
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm(`确定删除用户「${row.nickname || row.mobile}」吗？删除后不可恢复！`, '危险操作', { type: 'error', confirmButtonText: '确认删除' })
  try {
    await request.delete(`/user/admin/member/${row.id}`)
    ElMessage.success('删除成功')
    loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(loadData)
</script>

<style scoped lang="scss">
.member-page { padding: 20px; }
.page-header {
  margin-bottom: 20px;
  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}
.filter-bar { display: flex; gap: 12px; margin-bottom: 16px; }
.user-cell {
  display: flex;
  align-items: center;
  gap: 10px;
  .nickname { font-size: 14px; font-weight: 500; }
  .mobile { font-size: 12px; color: #999; }
}
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
</style>
