<template>
  <div class="order-list-page">
    <el-card shadow="never">
      <div class="toolbar">
        <el-input v-model="keyword" placeholder="订单号/课程名称" clearable style="width: 240px" @change="loadOrders" />
        <el-select v-model="statusFilter" clearable placeholder="订单状态" style="width: 140px" @change="loadOrders">
          <el-option label="待支付" :value="0" />
          <el-option label="已支付" :value="1" />
          <el-option label="已取消" :value="2" />
          <el-option label="退款中" :value="4" />
          <el-option label="已退款" :value="5" />
        </el-select>
        <el-button @click="loadOrders">刷新</el-button>
      </div>

      <el-table :data="orders" v-loading="loading" stripe>
        <el-table-column prop="orderNo" label="订单号" width="180" />
        <el-table-column prop="courseTitle" label="课程" min-width="150" show-overflow-tooltip />
        <el-table-column prop="teacherName" label="讲师" width="80" />
        <el-table-column prop="totalAmount" label="金额" width="80">
          <template #default="{ row }">¥{{ row.totalAmount }}</template>
        </el-table-column>
        <el-table-column prop="payType" label="支付方式" width="80">
          <template #default="{ row }">{{ row.payType === 'alipay' ? '支付宝' : row.payType || '-' }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)">
              {{ statusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="refundReason" label="退款原因" width="150" show-overflow-tooltip>
          <template #default="{ row }">{{ row.refundReason || '-' }}</template>
        </el-table-column>
        <el-table-column prop="payTime" label="支付时间" width="150" />
        <el-table-column prop="createTime" label="创建时间" width="150" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <template v-if="row.status === 4">
              <el-button size="small" type="success" @click="handleApproveRefund(row)">同意退款</el-button>
              <el-button size="small" type="danger" @click="handleRejectRefund(row)">拒绝</el-button>
            </template>
            <template v-else-if="row.status === 5">
              <el-button size="small" link type="info" @click="showRefundDetail(row)">退款详情</el-button>
            </template>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          layout="total, prev, pager, next"
          @change="loadOrders"
        />
      </div>
    </el-card>

    <!-- 拒绝退款对话框 -->
    <el-dialog v-model="rejectDialogVisible" title="拒绝退款" width="400px">
      <el-form>
        <el-form-item label="拒绝原因">
          <el-input v-model="rejectRemark" type="textarea" :rows="3" placeholder="请输入拒绝原因..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmReject" :loading="rejectLoading">确认拒绝</el-button>
      </template>
    </el-dialog>

    <!-- 退款详情对话框 -->
    <el-dialog v-model="detailDialogVisible" title="退款详情" width="450px">
      <el-descriptions :column="1" border>
        <el-descriptions-item label="订单号">{{ currentOrder?.orderNo }}</el-descriptions-item>
        <el-descriptions-item label="课程">{{ currentOrder?.courseTitle }}</el-descriptions-item>
        <el-descriptions-item label="退款金额">¥{{ currentOrder?.totalAmount }}</el-descriptions-item>
        <el-descriptions-item label="退款原因">{{ currentOrder?.refundReason || '-' }}</el-descriptions-item>
        <el-descriptions-item label="退款时间">{{ currentOrder?.refundTime || '-' }}</el-descriptions-item>
        <el-descriptions-item label="管理员备注">{{ currentOrder?.refundRemark || '-' }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/request'

const orders = ref<any[]>([])
const loading = ref(false)
const keyword = ref('')
const statusFilter = ref<number | ''>('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

// 拒绝退款
const rejectDialogVisible = ref(false)
const rejectRemark = ref('')
const rejectLoading = ref(false)
const currentRejectOrder = ref<any>(null)

// 退款详情
const detailDialogVisible = ref(false)
const currentOrder = ref<any>(null)

function statusText(status: number) {
  const map: Record<number, string> = { 0: '待支付', 1: '已支付', 2: '已取消', 4: '退款中', 5: '已退款' }
  return map[status] ?? '未知'
}

function statusTagType(status: number) {
  const map: Record<number, string> = { 0: 'warning', 1: 'success', 2: 'info', 4: 'warning', 5: 'danger' }
  return map[status] ?? 'info'
}

onMounted(loadOrders)

async function loadOrders() {
  loading.value = true
  try {
    const res = await request.get('/order/admin/order/page', {
      params: {
        current: currentPage.value,
        size: pageSize.value,
        keyword: keyword.value || undefined,
        status: statusFilter.value !== '' ? statusFilter.value : undefined,
      },
    })
    orders.value = res.data?.records || []
    total.value = res.data?.total || 0
  } finally {
    loading.value = false
  }
}

async function handleApproveRefund(order: any) {
  try {
    await ElMessageBox.confirm(`确定同意该订单退款 ¥${order.totalAmount} 吗？`, '确认退款', {
      type: 'success'
    })
    await request.post(`/order/order/admin/refund/approve/${order.orderNo}`)
    ElMessage.success('退款已处理')
    loadOrders()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '操作失败')
    }
  }
}

function handleRejectRefund(order: any) {
  currentRejectOrder.value = order
  rejectRemark.value = ''
  rejectDialogVisible.value = true
}

async function confirmReject() {
  rejectLoading.value = true
  try {
    await request.post(`/order/order/admin/refund/reject/${currentRejectOrder.value.orderNo}`, null, {
      params: { remark: rejectRemark.value }
    })
    ElMessage.success('已拒绝退款申请')
    rejectDialogVisible.value = false
    loadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  } finally {
    rejectLoading.value = false
  }
}

function showRefundDetail(order: any) {
  currentOrder.value = order
  detailDialogVisible.value = true
}
</script>

<style lang="scss" scoped>
.toolbar { display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
.pagination { margin-top: 16px; display: flex; justify-content: flex-end; }
</style>
