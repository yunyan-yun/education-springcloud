<template>
  <div class="quiz-page">
    <div class="page-header">
      <h2>题库管理</h2>
      <el-button type="primary" @click="handleAdd">
        <el-icon><Plus /></el-icon> 新增题目
      </el-button>
    </div>

    <!-- 筛选栏 -->
    <div class="filter-bar">
      <el-select
        v-model="filterCourseId"
        placeholder="选择课程"
        clearable
        filterable
        style="width: 240px"
        @change="onCourseChange"
      >
        <el-option
          v-for="c in courseList"
          :key="c.id"
          :label="c.title"
          :value="c.id"
        />
      </el-select>
      <el-select
        v-model="filterChapterId"
        placeholder="选择章节"
        clearable
        style="width: 200px"
        @change="onChapterChange"
      >
        <el-option
          v-for="ch in chapterList"
          :key="ch.id"
          :label="ch.title"
          :value="ch.id"
        />
      </el-select>
      <el-select
        v-model="filterVideoId"
        placeholder="选择视频"
        clearable
        style="width: 200px"
        @change="handleSearch"
      >
        <el-option
          v-for="v in videoList"
          :key="v.id"
          :label="v.title"
          :value="v.id"
        />
      </el-select>
      <el-input
        v-model="keyword"
        placeholder="搜索题目内容"
        clearable
        style="width: 240px"
        @input="handleSearch"
      >
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
    </div>

    <!-- 数据表格 -->
    <el-table :data="tableData" border v-loading="loading" style="width: 100%">
      <el-table-column label="ID" prop="id" width="70" align="center" />
      <el-table-column label="题目内容" prop="content" min-width="280" show-overflow-tooltip />
      <el-table-column label="选项A" prop="optionA" min-width="120" show-overflow-tooltip />
      <el-table-column label="选项B" prop="optionB" min-width="120" show-overflow-tooltip />
      <el-table-column label="选项C" prop="optionC" min-width="120" show-overflow-tooltip />
      <el-table-column label="选项D" prop="optionD" min-width="120" show-overflow-tooltip />
      <el-table-column label="正确答案" width="90" align="center">
        <template #default="{ row }">
          <el-tag :type="row.answer === 'A' ? '' : row.answer === 'B' ? 'success' : row.answer === 'C' ? 'warning' : 'danger'" size="small">
            {{ row.answer }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="视频" prop="videoId" width="80" align="center" />
      <el-table-column label="排序" prop="sort" width="70" align="center" />
      <el-table-column label="创建时间" width="160" align="center">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="140" align="center" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <div class="pagination-wrap">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="loadData"
        background
      />
    </div>

    <!-- 新增/编辑弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '编辑题目' : '新增题目'"
      width="680px"
      :close-on-click-modal="false"
    >
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="课程" prop="courseId">
          <el-select v-model="form.courseId" placeholder="选择课程" filterable style="width: 100%" @change="onFormCourseChange">
            <el-option v-for="c in courseList" :key="c.id" :label="c.title" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="章节" prop="chapterId">
          <el-select v-model="form.chapterId" placeholder="选择章节" style="width: 100%" @change="onFormChapterChange">
            <el-option v-for="ch in formChapterList" :key="ch.id" :label="ch.title" :value="ch.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="视频" prop="videoId">
          <el-select v-model="form.videoId" placeholder="选择视频" style="width: 100%">
            <el-option v-for="v in formVideoList" :key="v.id" :label="v.title" :value="v.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="题目" prop="content">
          <el-input v-model="form.content" type="textarea" :rows="3" placeholder="请输入题目内容" />
        </el-form-item>
        <el-form-item label="选项A" prop="optionA">
          <el-input v-model="form.optionA" placeholder="请输入选项A" />
        </el-form-item>
        <el-form-item label="选项B" prop="optionB">
          <el-input v-model="form.optionB" placeholder="请输入选项B" />
        </el-form-item>
        <el-form-item label="选项C" prop="optionC">
          <el-input v-model="form.optionC" placeholder="请输入选项C" />
        </el-form-item>
        <el-form-item label="选项D" prop="optionD">
          <el-input v-model="form.optionD" placeholder="请输入选项D" />
        </el-form-item>
        <el-form-item label="正确答案" prop="answer">
          <el-radio-group v-model="form.answer">
            <el-radio value="A">A</el-radio>
            <el-radio value="B">B</el-radio>
            <el-radio value="C">C</el-radio>
            <el-radio value="D">D</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="解析">
          <el-input v-model="form.analysis" type="textarea" :rows="2" placeholder="请输入题目解析（可选）" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="0" :max="999" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import request from '@/utils/request'
import dayjs from 'dayjs'

// 表格数据
const loading = ref(false)
const tableData = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(15)

// 筛选
const keyword = ref('')
const filterCourseId = ref<number | undefined>()
const filterChapterId = ref<number | undefined>()
const filterVideoId = ref<number | undefined>()
const courseList = ref<any[]>([])
const chapterList = ref<any[]>([])
const videoList = ref<any[]>([])

// 弹窗
const dialogVisible = ref(false)
const isEdit = ref(false)
const editId = ref<number | null>(null)
const submitting = ref(false)
const formRef = ref()
const formChapterList = ref<any[]>([])
const formVideoList = ref<any[]>([])

const form = reactive({
  courseId: undefined as number | undefined,
  chapterId: undefined as number | undefined,
  videoId: undefined as number | undefined,
  content: '',
  optionA: '',
  optionB: '',
  optionC: '',
  optionD: '',
  answer: 'A',
  analysis: '',
  sort: 0,
})

const rules = {
  courseId: [{ required: true, message: '请选择课程', trigger: 'change' }],
  chapterId: [{ required: true, message: '请选择章节', trigger: 'change' }],
  videoId: [{ required: true, message: '请选择视频', trigger: 'change' }],
  content: [{ required: true, message: '请输入题目内容', trigger: 'blur' }],
  optionA: [{ required: true, message: '请输入选项A', trigger: 'blur' }],
  optionB: [{ required: true, message: '请输入选项B', trigger: 'blur' }],
  optionC: [{ required: true, message: '请输入选项C', trigger: 'blur' }],
  optionD: [{ required: true, message: '请输入选项D', trigger: 'blur' }],
  answer: [{ required: true, message: '请选择正确答案', trigger: 'change' }],
}

function formatTime(t: string) {
  return t ? dayjs(t).format('YYYY-MM-DD HH:mm') : '-'
}

// 加载课程列表（下拉用）
async function loadCourses() {
  try {
    const res = await request.get('/course/admin/course/page', {
      params: { current: 1, size: 100, status: 1 },
    })
    courseList.value = res.data?.records || []
  } catch {
    courseList.value = []
  }
}

// 加载章节列表
async function loadChapters(courseId: number) {
  if (!courseId) {
    chapterList.value = []
    return
  }
  try {
    const res = await request.get('/course/admin/question/chapters', {
      params: { courseId },
    })
    chapterList.value = res.data || []
  } catch {
    chapterList.value = []
  }
}

// 加载视频列表
async function loadVideos(chapterId: number) {
  if (!chapterId) {
    videoList.value = []
    return
  }
  try {
    const res = await request.get('/course/admin/question/videos', {
      params: { chapterId },
    })
    videoList.value = res.data || []
  } catch {
    videoList.value = []
  }
}

// 筛选-课程变化
function onCourseChange(val: number | undefined) {
  filterChapterId.value = undefined
  filterVideoId.value = undefined
  videoList.value = []
  loadChapters(val || 0)
  handleSearch()
}

// 筛选-章节变化
function onChapterChange(val: number | undefined) {
  filterVideoId.value = undefined
  loadVideos(val || 0)
  handleSearch()
}

// 表单-课程变化
function onFormCourseChange(val: number | undefined) {
  form.chapterId = undefined
  form.videoId = undefined
  formChapterList.value = []
  formVideoList.value = []
  if (val) {
    loadChapters(val).then(() => {
      formChapterList.value = chapterList.value
    })
  }
}

// 表单-章节变化
function onFormChapterChange(val: number | undefined) {
  form.videoId = undefined
  formVideoList.value = []
  if (val) {
    loadVideos(val).then(() => {
      formVideoList.value = videoList.value
    })
  }
}

// 搜索
let searchTimer: ReturnType<typeof setTimeout>
function handleSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => {
    currentPage.value = 1
    loadData()
  }, 300)
}

// 加载表格数据
async function loadData() {
  loading.value = true
  try {
    const params: any = {
      current: currentPage.value,
      size: pageSize.value,
    }
    if (filterCourseId.value) params.courseId = filterCourseId.value
    if (filterChapterId.value) params.chapterId = filterChapterId.value
    if (filterVideoId.value) params.videoId = filterVideoId.value
    if (keyword.value) params.keyword = keyword.value

    const res = await request.get('/course/admin/question/page', { params })
    tableData.value = res.data?.records || []
    total.value = res.data?.total || 0

    if (tableData.value.length === 0 && currentPage.value > 1) {
      currentPage.value--
      await loadData()
    }
  } catch {
    tableData.value = []
  } finally {
    loading.value = false
  }
}

// 新增
function handleAdd() {
  isEdit.value = false
  editId.value = null
  Object.assign(form, {
    courseId: undefined,
    chapterId: undefined,
    videoId: undefined,
    content: '',
    optionA: '',
    optionB: '',
    optionC: '',
    optionD: '',
    answer: 'A',
    analysis: '',
    sort: 0,
  })
  formChapterList.value = []
  formVideoList.value = []
  dialogVisible.value = true
}

// 编辑
async function handleEdit(row: any) {
  isEdit.value = true
  editId.value = row.id
  // 加载该课程的章节和视频
  await loadChapters(row.courseId)
  formChapterList.value = chapterList.value
  await loadVideos(row.chapterId)
  formVideoList.value = videoList.value
  Object.assign(form, {
    courseId: row.courseId,
    chapterId: row.chapterId,
    videoId: row.videoId,
    content: row.content,
    optionA: row.optionA,
    optionB: row.optionB,
    optionC: row.optionC,
    optionD: row.optionD,
    answer: row.answer,
    analysis: row.analysis || '',
    sort: row.sort || 0,
  })
  dialogVisible.value = true
}

// 提交表单
async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitting.value = true
  try {
    const data = { ...form }
    if (isEdit.value && editId.value) {
      await request.put(`/course/admin/question/${editId.value}`, data)
      ElMessage.success('修改成功')
    } else {
      await request.post('/course/admin/question', data)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    await loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  } finally {
    submitting.value = false
  }
}

// 删除
async function handleDelete(row: any) {
  await ElMessageBox.confirm(`确定删除题目「${row.content.substring(0, 30)}...」吗？`, '提示', { type: 'warning' })
  try {
    await request.delete(`/course/admin/question/${row.id}`)
    ElMessage.success('删除成功')
    await loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(() => {
  loadCourses()
  loadData()
})
</script>

<style scoped lang="scss">
.quiz-page { padding: 20px; }

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}

.filter-bar { display: flex; gap: 12px; margin-bottom: 16px; }

.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
</style>
