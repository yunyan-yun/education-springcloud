<template>
  <div class="teacher-page">
    <div class="page-header">
      <h2>讲师管理</h2>
      <el-button type="primary" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增讲师
      </el-button>
    </div>

    <div class="filter-bar">
      <el-input v-model="keyword" placeholder="搜索讲师名称" clearable style="width:240px" @input="handleSearch">
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
    </div>

    <el-table :data="tableData" border v-loading="loading" style="width:100%">
      <el-table-column label="讲师" width="200">
        <template #default="{ row }">
          <div class="teacher-cell">
            <el-avatar :size="40" :src="row.avatar" />
            <span>{{ row.name }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="职称/简介" prop="career" min-width="180" show-overflow-tooltip />
      <el-table-column label="简介" prop="intro" min-width="200" show-overflow-tooltip />
      <el-table-column label="排序" prop="sort" width="80" align="center" />
      <el-table-column label="状态" width="80" align="center">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">
            {{ row.status === 1 ? '启用' : '禁用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="140" align="center">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="openDialog(row)">编辑</el-button>
          <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-wrap">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="loadData"
        background
      />
    </div>

    <!-- 编辑弹窗 -->
    <el-dialog v-model="dialogVisible" :title="editRow ? '编辑讲师' : '新增讲师'" width="500px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" placeholder="讲师姓名" />
        </el-form-item>
        <el-form-item label="头像">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :before-upload="beforeAvatarUpload"
            accept="image/*"
          >
            <img v-if="form.avatar" :src="form.avatar" class="avatar-preview" />
            <div v-else class="avatar-placeholder">
              <el-icon :size="24"><Plus /></el-icon>
              <span>上传头像</span>
            </div>
          </el-upload>
          <div class="upload-tip">建议 1:1 正方形，JPG/PNG，建议不超过 10MB</div>
        </el-form-item>
        <el-form-item label="职称">
          <el-input v-model="form.career" placeholder="职称（如：资深工程师）" />
        </el-form-item>
        <el-form-item label="简介">
          <el-input v-model="form.intro" type="textarea" :rows="3" placeholder="讲师简介" />
        </el-form-item>
        <el-form-item label="排序">
          <el-input-number v-model="form.sort" :min="0" :max="999" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" :active-value="1" :inactive-value="0" active-text="启用" inactive-text="禁用" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import request from '@/utils/request'

const loading = ref(false)
const dialogVisible = ref(false)
const submitting = ref(false)
const keyword = ref('')
const tableData = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const editRow = ref<any>(null)
const formRef = ref<FormInstance>()

const form = reactive({ name: '', avatar: '', career: '', intro: '', sort: 0, status: 1 })
const rules = { name: [{ required: true, message: '请输入姓名', trigger: 'blur' }] }

let searchTimer: ReturnType<typeof setTimeout>
function handleSearch() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => { currentPage.value = 1; loadData() }, 300)
}

async function loadData() {
  loading.value = true
  try {
    const res = await request.get('/course/admin/teacher/page', {
      params: { page: currentPage.value, size: pageSize.value, keyword: keyword.value }
    })
    tableData.value = res.data?.records || []
    total.value = res.data?.total || 0
  } catch {
    // fallback
  } finally {
    loading.value = false
  }
}

function openDialog(row?: any) {
  if (row) {
    // 编辑时，从 tableData 中获取最新数据，确保显示的是更新后的值
    const latestRow = tableData.value.find(t => t.id === row.id) || row
    editRow.value = latestRow
    Object.assign(form, {
      name: latestRow.name || '',
      avatar: latestRow.avatar || '',
      career: latestRow.career || '',
      intro: latestRow.intro || '',
      sort: latestRow.sort || 0,
      status: latestRow.status ?? 1
    })
  } else {
    editRow.value = null
    Object.assign(form, { name: '', avatar: '', career: '', intro: '', sort: 0, status: 1 })
  }
  formRef.value?.resetFields()
  dialogVisible.value = true
}

async function handleSubmit() {
  await formRef.value?.validate()
  submitting.value = true
  try {
    if (editRow.value) {
      await request.put(`/course/admin/teacher/${editRow.value.id}`, form)
      // 乐观更新：立即刷新列表中的对应行
      const idx = tableData.value.findIndex(t => t.id === editRow.value.id)
      if (idx !== -1) {
        const updated = {
          id: editRow.value.id,
          name: form.name,
          avatar: form.avatar,
          career: form.career,
          intro: form.intro,
          sort: form.sort,
          status: form.status
        }
        // 替换整行，确保响应式更新
        tableData.value.splice(idx, 1, updated)
        // 更新 editRow 引用，下次编辑时能获取最新数据
        editRow.value = updated
      }
    } else {
      await request.post('/course/admin/teacher', form)
      // 新增后重新加载以获取完整数据
      await loadData()
    }
    ElMessage.success('操作成功')
    dialogVisible.value = false
  } catch (e: any) {
    ElMessage.error(e.message || '操作失败')
  } finally {
    submitting.value = false
  }
}

async function beforeAvatarUpload(file: File) {
  const isImage = file.type.startsWith('image/')
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isImage) { ElMessage.error('只支持图片格式'); return false }
  if (!isLt10M) { ElMessage.error('图片大小不能超过10MB'); return false }

  // 上传到阿里云 OSS
  const formData = new FormData()
  formData.append('file', file)
  try {
    const res = await request.post('/course/file/upload/teacher', formData)
    form.avatar = res.data
    ElMessage.success('头像上传成功')
  } catch (e: any) {
    ElMessage.error(e.message || '上传失败')
  }
  return false
}

async function handleDelete(row: any) {
  await ElMessageBox.confirm(`确定删除讲师「${row.name}」吗？`, '提示', { type: 'warning' })
  try {
    await request.delete(`/course/admin/teacher/${row.id}`)
    ElMessage.success('删除成功')
    loadData()
  } catch (e: any) {
    ElMessage.error(e.message || '删除失败')
  }
}

onMounted(loadData)
</script>

<style scoped lang="scss">
.teacher-page { padding: 20px; }
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  h2 { margin: 0; font-size: 18px; font-weight: 600; }
}
.filter-bar { margin-bottom: 16px; }
.teacher-cell { display: flex; align-items: center; gap: 10px; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }

.avatar-uploader {
  :deep(.el-upload) {
    border: 2px dashed #dcdfe6;
    border-radius: 50%;
    width: 80px;
    height: 80px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    transition: border-color 0.2s;
    &:hover { border-color: #0891b2; }
  }
}

.avatar-preview { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }

.avatar-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  color: #999;
  font-size: 12px;
  width: 100%;
  height: 100%;
}

.upload-tip { font-size: 12px; color: #999; margin-top: 6px; }

</style>
