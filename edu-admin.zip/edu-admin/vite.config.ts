import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({ resolvers: [ElementPlusResolver()], imports: ['vue', 'vue-router', 'pinia'] }),
    Components({ resolvers: [ElementPlusResolver()] }),
  ],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  server: {
    port: 3001,
    proxy: {
      // 统一转发到 API 网关
      '/api/user': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/user/, '/user'),
        // 大文件上传超时（10分钟）
        configure: (proxy) => {
          proxy.on('proxyReq', (_, req) => {
            req.setTimeout(600000)
          })
        }
      },
      '/api/course': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/course/, '/course'),
        // 大文件上传超时（10分钟）
        configure: (proxy) => {
          proxy.on('proxyReq', (_, req) => {
            req.setTimeout(600000)
          })
        }
      },
      '/api/order': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/order/, '/order'),
      },
      '/api/ai': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/ai/, '/ai'),
      },
    },
    // 文件上传大小限制 (500MB)
    bodySizeLimit: '500mb',
  },
})
