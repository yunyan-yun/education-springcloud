package com.edu.ai.config;

import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRule;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRuleManager;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Sentinel 规则配置（流控 + 熔断）
 * 在应用启动完成后初始化规则，使 @SentinelResource 注解真正生效
 */
@Component
public class SentinelRuleConfig implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(SentinelRuleConfig.class);

    @Override
    public void run(String... args) {
        // 加载流控规则
        List<FlowRule> flowRules = new ArrayList<>();

        FlowRule chatFlowRule = new FlowRule();
        chatFlowRule.setResource("ai-chat");
        chatFlowRule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        chatFlowRule.setCount(10);  // QPS 阈值：每秒最多 10 次对话请求
        chatFlowRule.setControlBehavior(RuleConstant.CONTROL_BEHAVIOR_DEFAULT);
        flowRules.add(chatFlowRule);

        FlowRuleManager.loadRules(flowRules);
        log.info("[Sentinel] 流控规则初始化完成，已加载 {} 条", flowRules.size());

        // 加载熔断规则
        List<DegradeRule> degradeRules = new ArrayList<>();

        DegradeRule chatDegradeRule = new DegradeRule();
        chatDegradeRule.setResource("ai-chat");
        chatDegradeRule.setGrade(RuleConstant.DEGRADE_GRADE_EXCEPTION_RATIO);
        chatDegradeRule.setCount(0.5);          // 异常比例阈值：50%
        chatDegradeRule.setMinRequestAmount(5);  // 最小请求数：5 个
        chatDegradeRule.setStatIntervalMs(10000); // 统计时间窗口：10 秒
        chatDegradeRule.setTimeWindow(30);       // 熔断时长：30 秒（AI服务恢复需要更长时间）
        degradeRules.add(chatDegradeRule);

        DegradeRuleManager.loadRules(degradeRules);
        log.info("[Sentinel] 熔断规则初始化完成，已加载 {} 条", degradeRules.size());
    }
}
