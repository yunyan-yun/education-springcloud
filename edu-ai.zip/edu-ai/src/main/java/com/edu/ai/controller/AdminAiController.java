package com.edu.ai.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.ai.entity.AiChat;
import com.edu.ai.service.AiChatService;
import com.edu.common.result.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ai/admin/ai")
public class AdminAiController {

    @Autowired
    private AiChatService aiChatService;

    /**
     * AI对话历史记录列表（分页）
     */
    @GetMapping("/history")
    public R<Page<AiChat>> history(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Long memberId,
            @RequestParam(required = false) String sessionId) {

        Page<AiChat> page = aiChatService.getPageList(pageNum, pageSize, memberId, sessionId);
        return R.ok(page);
    }

    /**
     * 删除聊天记录
     */
    @DeleteMapping("/history/{id}")
    public R<Void> delete(@PathVariable Long id) {
        boolean removed = aiChatService.removeById(id);
        return removed ? R.ok() : R.fail("删除失败");
    }

    /**
     * 按会话分组查询会话列表
     */
    @GetMapping("/sessions")
    public R<?> sessions(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Long memberId) {
        // 返回最近会话列表，按最后消息时间排序
        Page<AiChat> page = new Page<>(pageNum, pageSize);
        QueryWrapper<AiChat> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);

        if (memberId != null) {
            wrapper.eq("member_id", memberId);
        }

        wrapper.groupBy("session_id").orderByDesc("create_time");
        Page<AiChat> result = aiChatService.page(page, wrapper);
        return R.ok(result);
    }

    /**
     * 删除用户的所有AI对话记录（级联）
     */
    @DeleteMapping("/member/{memberId}")
    public R<Void> deleteByMember(@PathVariable Long memberId) {
        aiChatService.remove(new QueryWrapper<AiChat>().eq("member_id", memberId));
        return R.ok();
    }
}
