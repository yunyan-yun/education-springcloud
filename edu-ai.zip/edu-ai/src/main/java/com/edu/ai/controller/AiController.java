package com.edu.ai.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.edu.ai.entity.AiChat;
import com.edu.ai.mapper.AiChatMapper;
import com.edu.ai.service.AiService;
import com.edu.common.result.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/ai/ai")
public class AiController {

    @Autowired
    private AiService aiService;

    @Autowired
    private AiChatMapper aiChatMapper;

    // 内存缓存会话历史（用于返回给前端，保持原有逻辑）
    private final Map<String, List<Map<String, String>>> sessionHistories = new HashMap<>();

    @PostMapping("/chat")
    @SentinelResource(value = "ai-chat", blockHandler = "chatBlockHandler")
    public R<Map<String, Object>> chat(@RequestParam String message,
                                       @RequestParam(required = false) String sessionId,
                                       @RequestHeader(value = "X-User-Id", required = false) Long memberId) {
        // 获取或创建会话ID
        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = UUID.randomUUID().toString();
        }

        // 获取历史对话
        List<Map<String, String>> history = sessionHistories.computeIfAbsent(sessionId, k -> new ArrayList<>());

        // 添加用户消息到历史
        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", message);
        history.add(userMsg);

        // 调用AI服务
        String answer = aiService.chat(message, history);

        // 添加AI回复到历史
        Map<String, String> assistantMsg = new HashMap<>();
        assistantMsg.put("role", "assistant");
        assistantMsg.put("content", answer);
        history.add(assistantMsg);

        // ========== 保存到数据库 ==========
        try {
            LocalDateTime now = LocalDateTime.now();

            // 保存用户消息
            AiChat userRecord = new AiChat();
            userRecord.setMemberId(memberId);
            userRecord.setRole("user");
            userRecord.setContent(message);
            userRecord.setSessionId(sessionId);
            userRecord.setCreateTime(now);
            userRecord.setUpdateTime(now);
            aiChatMapper.insert(userRecord);

            // 保存AI回复
            AiChat assistantRecord = new AiChat();
            assistantRecord.setMemberId(memberId);
            assistantRecord.setRole("assistant");
            assistantRecord.setContent(answer);
            assistantRecord.setSessionId(sessionId);
            assistantRecord.setCreateTime(now);
            assistantRecord.setUpdateTime(now);
            aiChatMapper.insert(assistantRecord);
        } catch (Exception e) {
            // 记录失败但不影响返回
            System.err.println("保存聊天记录失败: " + e.getMessage());
        }
        // ========== 保存结束 ==========

        // 限制历史记录长度（保留最近20条）
        if (history.size() > 20) {
            history = history.subList(history.size() - 20, history.size());
            sessionHistories.put(sessionId, history);
        }

        // 返回结果
        Map<String, Object> data = new HashMap<>();
        data.put("answer", answer);
        data.put("type", "text");
        data.put("sessionId", sessionId);
        return R.ok(data);
    }

    /**
     * AI对话接口流控降级处理
     * 触发条件：QPS超过阈值
     * 保护AI接口不被过度调用，控制调用成本
     */
    public R<Map<String, Object>> chatBlockHandler(String message, String sessionId, Long memberId, BlockException ex) {
        Map<String, Object> data = new java.util.HashMap<>();
        data.put("code", 429);
        data.put("message", "AI请求过于频繁，请稍后再试");
        return R.fail(429, "AI请求过于频繁，请稍后再试");
    }

    @PostMapping("/recommend")
    public R<?> recommend(@RequestParam String interests) {
        List<Map<String, Object>> courses = aiService.recommend(interests);
        return R.ok(courses);
    }

    @PostMapping("/plan")
    public R<Map<String, Object>> studyPlan(
            @RequestParam String courseName,
            @RequestParam String targetTime,
            @RequestParam String hoursPerDay) {
        Map<String, Object> plan = aiService.generateStudyPlan(courseName, targetTime, hoursPerDay);
        return R.ok(plan);
    }

    @PostMapping("/summarize")
    public R<Map<String, Object>> chapterSummary(@RequestParam String content) {
        Map<String, Object> summary = aiService.summarizeChapter(content);
        return R.ok(summary);
    }

    /**
     * 获取聊天历史（从数据库）
     */
    @GetMapping("/history")
    public R<List<Map<String, String>>> getChatHistory(@RequestParam String sessionId,
                                                        @RequestHeader(value = "X-User-Id", required = false) Long memberId) {
        LambdaQueryWrapper<AiChat> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AiChat::getSessionId, sessionId);
        if (memberId != null) {
            wrapper.eq(AiChat::getMemberId, memberId);
        }
        wrapper.orderByAsc(AiChat::getCreateTime);

        List<AiChat> records = aiChatMapper.selectList(wrapper);
        List<Map<String, String>> history = new ArrayList<>();
        for (AiChat chat : records) {
            Map<String, String> msg = new HashMap<>();
            msg.put("role", chat.getRole());
            msg.put("content", chat.getContent());
            history.add(msg);
        }
        return R.ok(history);
    }

    /**
     * 获取用户的会话列表
     */
    @GetMapping("/sessions")
    public R<List<Map<String, Object>>> getSessionList(@RequestHeader(value = "X-User-Id", required = false) Long memberId) {
        if (memberId == null) {
            return R.ok(new ArrayList<>());
        }

        // 查询用户的所有会话ID和最后一条消息
        LambdaQueryWrapper<AiChat> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AiChat::getMemberId, memberId)
               .select(AiChat::getSessionId)
               .groupBy(AiChat::getSessionId)
               .orderByDesc(AiChat::getCreateTime);

        List<AiChat> sessions = aiChatMapper.selectList(wrapper);
        List<Map<String, Object>> result = new ArrayList<>();

        for (AiChat session : sessions) {
            Map<String, Object> item = new HashMap<>();
            item.put("sessionId", session.getSessionId());

            // 获取该会话的第一条和最后一条消息
            LambdaQueryWrapper<AiChat> msgWrapper = new LambdaQueryWrapper<>();
            msgWrapper.eq(AiChat::getSessionId, session.getSessionId())
                      .orderByAsc(AiChat::getCreateTime);
            List<AiChat> messages = aiChatMapper.selectList(msgWrapper);

            if (!messages.isEmpty()) {
                item.put("firstMessage", messages.get(0).getContent());
                item.put("lastMessage", messages.get(messages.size() - 1).getContent());
                item.put("lastTime", messages.get(messages.size() - 1).getCreateTime());
                item.put("messageCount", messages.size());
            }
            result.add(item);
        }
        return R.ok(result);
    }

    /**
     * 清除聊天历史
     */
    @DeleteMapping("/history")
    public R<Void> clearHistory(@RequestParam String sessionId,
                                 @RequestHeader(value = "X-User-Id", required = false) Long memberId) {
        LambdaQueryWrapper<AiChat> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AiChat::getSessionId, sessionId);
        if (memberId != null) {
            wrapper.eq(AiChat::getMemberId, memberId);
        }
        aiChatMapper.delete(wrapper);
        // 同时清除内存缓存
        sessionHistories.remove(sessionId);
        return R.ok();
    }
}
