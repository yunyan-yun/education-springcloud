package com.edu.ai.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("edu_ai_chat")
public class AiChat {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 用户ID */
    private Long memberId;

    /** user/assistant */
    private String role;

    /** 消息内容 */
    private String content;

    /** 会话ID */
    private String sessionId;

    /** 是否删除 */
    private Integer isDeleted;

    /** 创建时间 - 数据库自动生成 */
    private LocalDateTime createTime;

    /** 更新时间 - 数据库自动生成 */
    private LocalDateTime updateTime;
}
