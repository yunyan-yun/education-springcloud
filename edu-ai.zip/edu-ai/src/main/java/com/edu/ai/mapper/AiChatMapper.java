package com.edu.ai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.ai.entity.AiChat;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AiChatMapper extends BaseMapper<AiChat> {
}
