package com.edu.ai.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.edu.ai.entity.AiChat;

public interface AiChatService extends IService<AiChat> {

    /**
     * 分页查询聊天记录
     */
    Page<AiChat> getPageList(int pageNum, int pageSize, Long memberId, String sessionId);
}
