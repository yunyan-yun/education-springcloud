package com.edu.ai.service;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.edu.common.result.R;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AiService {

    private static final String DASHSCOPE_API_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions";
    private static final String MODEL_QWEN = "qwen-plus";

    @Value("${ai.dashscope.api-key:}")
    private String apiKey;

    @Value("${ai.dashscope.enabled:false}")
    private boolean enabled;

    @Value("${ai.course-service-url:http://localhost:8082}")
    private String courseServiceUrl;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public AiService() {
        // 配置 RestTemplate 超时，避免请求阻塞
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(3000);   // 连接超时 3秒
        factory.setReadTimeout(5000);       // 读取超时 5秒
        this.restTemplate = new RestTemplate(factory);
        this.objectMapper = new ObjectMapper();
    }

    /**
     * 通义千问对话
     */
    public String chat(String message, List<Map<String, String>> history) {
        if (!enabled || apiKey == null || apiKey.isEmpty() || apiKey.equals("your-api-key-here")) {
            return getSimulatedResponse(message);
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + apiKey);

            // 构建消息列表
            List<Map<String, String>> messages = new ArrayList<>();

            // 系统提示
            Map<String, String> systemMsg = new HashMap<>();
            systemMsg.put("role", "system");
            systemMsg.put("content", "你是知学在线教育平台的AI学习助手，名叫小知。你的职责是帮助学生解答学习问题、提供课程推荐、制定学习计划、总结章节内容。你应该专业、耐心、友好，用简洁清晰的语言回答。");
            messages.add(systemMsg);

            // 添加历史对话
            if (history != null) {
                for (Map<String, String> msg : history) {
                    messages.add(msg);
                }
            }

            // 添加当前消息
            Map<String, String> userMsg = new HashMap<>();
            userMsg.put("role", "user");
            userMsg.put("content", message);
            messages.add(userMsg);

            // 构建请求体
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("model", MODEL_QWEN);
            requestBody.put("messages", messages);
            requestBody.put("temperature", 0.7);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

            // 为通义千问对话设置合理的超时（AI响应可能较慢）
            SimpleClientHttpRequestFactory chatFactory = new SimpleClientHttpRequestFactory();
            chatFactory.setConnectTimeout(10000);   // 10秒连接超时
            chatFactory.setReadTimeout(25000);       // 25秒读取超时（AI响应较慢）
            RestTemplate chatRestTemplate = new RestTemplate(chatFactory);

            ResponseEntity<String> response = chatRestTemplate.exchange(
                    DASHSCOPE_API_URL,
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode root = objectMapper.readTree(response.getBody());
                JsonNode choices = root.path("choices");
                if (choices.isArray() && choices.size() > 0) {
                    JsonNode messageNode = choices.get(0).path("message");
                    return messageNode.path("content").asText();
                }
            }

            log.error("通义千问API调用失败: {}", response.getStatusCode());
            return "抱歉，AI服务暂时不可用，请稍后再试。";

        } catch (Exception e) {
            log.error("调用通义千问API异常: {}", e.getMessage());
            return "抱歉，AI服务暂时不可用，请稍后再试。";
        }
    }

    /**
     * 生成学习推荐（方案A：AI智能处理用户描述+平台课程数据）
     */
    public List<Map<String, Object>> recommend(String interests) {
        try {
            // 1. 从课程服务获取课程数据
            List<Map<String, Object>> allCourses = fetchCoursesFromService();
            
            if (allCourses == null || allCourses.isEmpty()) {
                log.warn("课程服务返回空数据，降级到模拟推荐");
                return getSimulatedRecommend(interests);
            }
            
            // 2. 如果AI未启用，降级到规则匹配
            if (!enabled || apiKey == null || apiKey.isEmpty() || apiKey.equals("your-api-key-here")) {
                return matchCoursesByInterest(allCourses, interests);
            }
            
            // 3. 方案A：发送给AI做智能匹配
            return recommendByAI(allCourses, interests);
            
        } catch (Exception e) {
            log.error("获取推荐课程失败: {}", e.getMessage());
            return getSimulatedRecommend(interests);
        }
    }
    
    /**
     * AI智能推荐：发送用户兴趣+课程数据给AI，生成个性化推荐
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> recommendByAI(List<Map<String, Object>> courses, String interests) {
        try {
            // 构造发送给AI的prompt
            StringBuilder prompt = new StringBuilder();
            prompt.append("作为知学在线教育平台的AI课程推荐助手，请根据用户的兴趣描述，从课程列表中智能推荐最合适的课程。\n\n");
            prompt.append("【用户兴趣描述】: ").append(interests).append("\n\n");
            prompt.append("【平台课程列表】(共").append(courses.size()).append("门课程):\n");
            
            // 取最多20门课程发给AI，避免token超限
            int maxCourses = Math.min(courses.size(), 20);
            for (int i = 0; i < maxCourses; i++) {
                Map<String, Object> course = courses.get(i);
                prompt.append("- ID:").append(course.get("id"))
                      .append(", 课程名:").append(course.get("title"))
                      .append(", 分类:").append(getStringOrDefault(course.get("categoryName"), "未知"))
                      .append(", 讲师:").append(getStringOrDefault(course.get("teacherName"), "未知"))
                      .append(", 价格:").append(course.get("price"))
                      .append(", 学习人数:").append(course.get("studyCount"))
                      .append(", 评分:").append(course.get("score"))
                      .append(", 简介:").append(getStringOrDefault(course.get("description"), "暂无描述"))
                      .append("\n");
            }
            
            prompt.append("\n【推荐要求】:\n");
            prompt.append("1. 根据用户兴趣【").append(interests).append("】，从上述课程中智能匹配3-5门最合适的课程\n");
            prompt.append("2. 每门课程需说明匹配原因（为什么推荐这门课，它如何满足用户需求）\n");
            prompt.append("3. 推荐理由要个性化，不要泛泛而谈，要具体说明课程与用户兴趣的关联\n");
            prompt.append("4. 按推荐程度从高到低排序\n");
            prompt.append("5. 直接返回JSON数组格式，每项包含: id, title, teacherName, price, reason(推荐理由)\n");
            prompt.append("6. 只返回JSON，不要任何解释说明\n\n");
            prompt.append("请开始推荐：");
            
            String aiResponse = callAI(prompt.toString());
            
            // 解析AI返回的JSON
            List<Map<String, Object>> aiRecommendations = parseAIRecommendResponse(aiResponse, courses);
            
            if (!aiRecommendations.isEmpty()) {
                return aiRecommendations;
            }
            
            // AI解析失败，降级到规则匹配
            log.warn("AI推荐解析失败，降级到规则匹配");
            return matchCoursesByInterest(courses, interests);
            
        } catch (Exception e) {
            log.error("AI智能推荐失败: {}", e.getMessage());
            return matchCoursesByInterest(courses, interests);
        }
    }
    
    /**
     * 解析AI推荐响应
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseAIRecommendResponse(String response, List<Map<String, Object>> courses) {
        try {
            // 尝试提取JSON数组
            String jsonStr = response.trim();
            if (jsonStr.contains("```json")) {
                jsonStr = jsonStr.substring(jsonStr.indexOf("```json") + 7);
                jsonStr = jsonStr.substring(0, jsonStr.indexOf("```"));
            } else if (jsonStr.contains("```")) {
                jsonStr = jsonStr.substring(jsonStr.indexOf("```") + 3);
                jsonStr = jsonStr.substring(0, jsonStr.indexOf("```"));
            }
            jsonStr = jsonStr.trim();
            
            if (!jsonStr.startsWith("[")) {
                jsonStr = "[" + jsonStr;
            }
            if (!jsonStr.endsWith("]")) {
                jsonStr = jsonStr + "]";
            }
            
            JSONArray aiRecs = JSON.parseArray(jsonStr);
            
            // 补充课程完整信息
            Map<Long, Map<String, Object>> courseMap = new HashMap<>();
            for (Map<String, Object> c : courses) {
                Object idObj = c.get("id");
                if (idObj != null) {
                    Long id = idObj instanceof Number ? ((Number) idObj).longValue() : Long.parseLong(idObj.toString());
                    courseMap.put(id, c);
                }
            }
            
            List<Map<String, Object>> result = new ArrayList<>();
            for (int i = 0; i < aiRecs.size(); i++) {
                JSONObject rec = aiRecs.getJSONObject(i);
                Object idObj = rec.get("id");
                if (idObj != null) {
                    Long id = idObj instanceof Number ? ((Number) idObj).longValue() : Long.parseLong(idObj.toString());
                    Map<String, Object> originalCourse = courseMap.get(id);
                    if (originalCourse != null) {
                        Map<String, Object> enriched = new HashMap<>(originalCourse);
                        enriched.put("reason", rec.get("reason")); // AI生成的个性化推荐理由
                        enriched.put("matchScore", 100); // 标记为AI推荐
                        result.add(enriched);
                    }
                }
            }
            
            return result;
        } catch (Exception e) {
            log.warn("解析AI推荐响应失败: {}", e.getMessage());
            return new ArrayList<>();
        }
    }
    
    /**
     * 从课程服务获取课程列表
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> fetchCoursesFromService() {
        try {
            // 调用课程服务的推荐课程和热门课程接口
            List<Map<String, Object>> recommendCourses = callCourseService("/course/recommend");
            List<Map<String, Object>> hotCourses = callCourseService("/course/hot");
            List<Map<String, Object>> latestCourses = callCourseService("/course/latest");
            
            // 合并去重
            Set<Long> seenIds = new HashSet<>();
            List<Map<String, Object>> allCourses = new ArrayList<>();
            
            for (List<Map<String, Object>> list : Arrays.asList(recommendCourses, hotCourses, latestCourses)) {
                if (list != null) {
                    for (Map<String, Object> course : list) {
                        Object idObj = course.get("id");
                        if (idObj != null) {
                            Long id = idObj instanceof Number ? ((Number) idObj).longValue() : Long.parseLong(idObj.toString());
                            if (!seenIds.contains(id)) {
                                seenIds.add(id);
                                allCourses.add(course);
                            }
                        }
                    }
                }
            }
            
            // 如果合并后数据不够，获取更多课程
            if (allCourses.size() < 10) {
                Map<String, Object> listResult = callCourseServiceList();
                if (listResult != null && listResult.containsKey("records")) {
                    List<Map<String, Object>> moreCourses = (List<Map<String, Object>>) listResult.get("records");
                    for (Map<String, Object> course : moreCourses) {
                        Object idObj = course.get("id");
                        if (idObj != null) {
                            Long id = idObj instanceof Number ? ((Number) idObj).longValue() : Long.parseLong(idObj.toString());
                            if (!seenIds.contains(id)) {
                                seenIds.add(id);
                                allCourses.add(course);
                            }
                        }
                    }
                }
            }
            
            return allCourses;
        } catch (Exception e) {
            log.error("调用课程服务失败: {}", e.getMessage());
            return null;
        }
    }
    
    /**
     * 调用课程服务获取列表数据
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> callCourseService(String path) {
        try {
            String url = courseServiceUrl + path;
            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
            
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                JSONObject json = JSON.parseObject(response.getBody());
                if (json.getIntValue("code") == 200) {
                    Object data = json.get("data");
                    if (data instanceof JSONArray) {
                        JSONArray jsonArray = json.getJSONArray("data");
                        @SuppressWarnings("unchecked")
                        List<Map<String, Object>> result = (List<Map<String, Object>>) (List<?>) jsonArray.toJavaList(Map.class);
                        return result;
                    }
                }
            }
        } catch (Exception e) {
            log.warn("调用{}失败: {}", path, e.getMessage());
        }
        return null;
    }
    
    /**
     * 调用课程列表接口
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> callCourseServiceList() {
        try {
            String url = courseServiceUrl + "/course/list?current=1&size=20";
            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
            
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                JSONObject json = JSON.parseObject(response.getBody());
                if (json.getIntValue("code") == 200) {
                    return json.getJSONObject("data");
                }
            }
        } catch (Exception e) {
            log.warn("调用课程列表失败: {}", e.getMessage());
        }
        return null;
    }
    
    /**
     * 根据兴趣关键词匹配课程
     */
    private List<Map<String, Object>> matchCoursesByInterest(List<Map<String, Object>> courses, String interests) {
        // 预处理兴趣关键词
        String[] keywords = Arrays.stream(interests.toLowerCase()
                .replaceAll("[,，、]", " ")
                .split("\\s+"))
                .filter(k -> k.length() > 1)
                .toArray(String[]::new);
        
        if (keywords.length == 0) {
            // 如果没有有效关键词，按学习人数排序返回
            return courses.stream()
                    .sorted((a, b) -> {
                        Integer countA = parseIntOrDefault(a.get("studyCount"), 0);
                        Integer countB = parseIntOrDefault(b.get("studyCount"), 0);
                        return countB.compareTo(countA);
                    })
                    .collect(Collectors.toList());
        }
        
        // 计算每门课程的匹配得分
        List<Map<String, Object>> scored = new ArrayList<>();
        for (Map<String, Object> course : courses) {
            int score = calculateMatchScore(course, keywords);
            if (score > 0) {
                Map<String, Object> scoredCourse = new HashMap<>(course);
                scoredCourse.put("matchScore", score);
                scoredCourse.put("reason", generateRecommendReason(course, keywords));
                scored.add(scoredCourse);
            }
        }
        
        // 按匹配得分排序
        scored.sort((a, b) -> {
            Integer scoreA = parseIntOrDefault(a.get("matchScore"), 0);
            Integer scoreB = parseIntOrDefault(b.get("matchScore"), 0);
            return scoreB.compareTo(scoreA);
        });
        
        // 如果没有匹配结果，返回按热度排序的课程
        if (scored.isEmpty()) {
            return courses.stream()
                    .sorted((a, b) -> {
                        Integer countA = parseIntOrDefault(a.get("studyCount"), 0);
                        Integer countB = parseIntOrDefault(b.get("studyCount"), 0);
                        return countB.compareTo(countA);
                    })
                    .limit(5)
                    .collect(Collectors.toList());
        }
        
        return scored;
    }
    
    /**
     * 计算课程与兴趣的匹配得分
     */
    private int calculateMatchScore(Map<String, Object> course, String[] keywords) {
        int score = 0;
        
        String title = getStringOrDefault(course.get("title"), "").toLowerCase();
        String description = getStringOrDefault(course.get("description"), "").toLowerCase();
        String subTitle = getStringOrDefault(course.get("subTitle"), "").toLowerCase();
        String categoryName = getStringOrDefault(course.get("categoryName"), "").toLowerCase();
        
        for (String keyword : keywords) {
            // 标题匹配权重最高
            if (title.contains(keyword)) {
                score += 10;
            }
            // 副标题匹配
            if (subTitle.contains(keyword)) {
                score += 5;
            }
            // 分类匹配
            if (categoryName.contains(keyword)) {
                score += 5;
            }
            // 描述匹配
            if (description.contains(keyword)) {
                score += 3;
            }
        }
        
        return score;
    }
    
    /**
     * 生成推荐理由
     */
    private String generateRecommendReason(Map<String, Object> course, String[] keywords) {
        StringBuilder reason = new StringBuilder();
        String categoryName = getStringOrDefault(course.get("categoryName"), "");
        Integer studyCount = parseIntOrDefault(course.get("studyCount"), 0);
        Object scoreObj = course.get("score");
        Double score = scoreObj != null ? (scoreObj instanceof Number ? ((Number) scoreObj).doubleValue() : Double.parseDouble(scoreObj.toString())) : 0.0;
        
        if (!categoryName.isEmpty()) {
            reason.append("属于").append(categoryName).append("类别，");
        }
        
        if (studyCount > 0) {
            reason.append("已有").append(studyCount).append("人学习，");
        }
        
        if (score > 0) {
            reason.append("评分").append(String.format("%.1f", score)).append("分，");
        }
        
        // 关联兴趣词
        List<String> matched = new ArrayList<>();
        for (String keyword : keywords) {
            String title = getStringOrDefault(course.get("title"), "").toLowerCase();
            if (title.contains(keyword)) {
                matched.add(keyword);
            }
        }
        
        if (!matched.isEmpty()) {
            reason.append("涵盖【").append(String.join("、", matched)).append("】等知识点");
        } else {
            reason.append("内容实用，适合学习");
        }
        
        return reason.toString();
    }
    
    private String getStringOrDefault(Object obj, String defaultVal) {
        return obj != null ? obj.toString() : defaultVal;
    }
    
    private Integer parseIntOrDefault(Object obj, int defaultVal) {
        if (obj == null) return defaultVal;
        if (obj instanceof Number) return ((Number) obj).intValue();
        try {
            return Integer.parseInt(obj.toString().replaceAll("[^0-9]", ""));
        } catch (Exception e) {
            return defaultVal;
        }
    }

    /**
     * 生成学习计划（方案A：AI基于课程章节信息生成个性化计划）
     */
    public Map<String, Object> generateStudyPlan(String courseName, String targetTime, String hoursPerDay) {
        try {
            // 1. 尝试获取课程详情（包括章节信息）
            Map<String, Object> courseDetail = fetchCourseDetail(courseName);
            
            if (courseDetail == null) {
                log.warn("未获取到课程详情，使用简化模式");
                courseDetail = new HashMap<>();
                courseDetail.put("title", courseName);
                courseDetail.put("chapters", Collections.emptyList());
            }
            
            // 2. 如果AI未启用，降级到模拟计划
            if (!enabled || apiKey == null || apiKey.isEmpty() || apiKey.equals("your-api-key-here")) {
                return getSimulatedStudyPlan(courseName, targetTime, hoursPerDay);
            }
            
            // 3. 方案A：发送课程章节+学习目标给AI，生成个性化计划
            return generatePlanByAI(courseDetail, targetTime, hoursPerDay);
            
        } catch (Exception e) {
            log.error("生成学习计划失败: {}", e.getMessage());
            return getSimulatedStudyPlan(courseName, targetTime, hoursPerDay);
        }
    }
    
    /**
     * AI生成个性化学习计划
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> generatePlanByAI(Map<String, Object> courseDetail, String targetTime, String hoursPerDay) {
        try {
            String courseName = getStringOrDefault(courseDetail.get("title"), "");
            List<Map<String, Object>> chapters = (List<Map<String, Object>>) courseDetail.getOrDefault("chapters", Collections.emptyList());
            
            // 构造发送给AI的prompt
            StringBuilder prompt = new StringBuilder();
            prompt.append("作为知学在线教育平台的AI学习规划助手，请根据课程章节和用户需求，制定一份详细的学习计划。\n\n");
            prompt.append("【课程名称】: ").append(courseName).append("\n\n");
            
            // 添加章节信息
            if (!chapters.isEmpty()) {
                prompt.append("【课程章节】:\n");
                for (int i = 0; i < chapters.size(); i++) {
                    Map<String, Object> chapter = chapters.get(i);
                    prompt.append((i + 1)).append(". ")
                          .append(getStringOrDefault(chapter.get("title"), "第" + (i+1) + "章"))
                          .append(" - 课时:")
                          .append(getStringOrDefault(chapter.get("duration"), "?"))
                          .append("分钟\n");
                }
            } else {
                prompt.append("【课程章节】: 暂无章节详情\n");
            }
            
            prompt.append("\n【用户学习目标】:\n");
            prompt.append("- 目标学习时长: ").append(targetTime).append("\n");
            prompt.append("- 每天可投入时间: ").append(hoursPerDay).append("小时\n\n");
            
            prompt.append("【计划要求】:\n");
            prompt.append("1. 根据章节数量和用户每天可用时间，合理分配学习任务\n");
            prompt.append("2. 每周学习任务要具体，包括要学的章节、目标、重点内容\n");
            prompt.append("3. 考虑循序渐进、由浅入深的原则\n");
            prompt.append("4. JSON格式返回，包含以下字段:\n");
            prompt.append("   - totalDays: 总学习天数\n");
            prompt.append("   - weeks: 每周计划数组，每项包含 weekNum(周次), goal(本周目标), chapters(学习章节), keyPoints(重点), dailyHours(每天小时数)\n");
            prompt.append("   - summary: 整体学习建议\n");
            prompt.append("5. 只返回JSON，不要有任何解释说明\n\n");
            prompt.append("请开始制定学习计划：");
            
            String aiResponse = callAI(prompt.toString());
            return parsePlanResponse(aiResponse, courseName);
            
        } catch (Exception e) {
            log.error("AI生成学习计划失败: {}", e.getMessage());
            return getSimulatedStudyPlan(getStringOrDefault(courseDetail.get("title"), ""), targetTime, hoursPerDay);
        }
    }
    
    /**
     * 获取课程详情（包括章节信息）
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> fetchCourseDetail(String courseName) {
        try {
            // 先搜索课程获取ID
            String searchUrl = courseServiceUrl + "/course/list?current=1&size=10&title=" + java.net.URLEncoder.encode(courseName, "UTF-8");
            ResponseEntity<String> response = restTemplate.getForEntity(searchUrl, String.class);
            
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                JSONObject json = JSON.parseObject(response.getBody());
                if (json.getIntValue("code") == 200) {
                    JSONObject data = json.getJSONObject("data");
                    if (data != null && data.containsKey("records")) {
                        JSONArray records = data.getJSONArray("records");
                        if (!records.isEmpty()) {
                            // 获取第一个匹配课程的详情
                            JSONObject course = records.getJSONObject(0);
                            Long courseId = course.getLong("id");
                            
                            // 获取课程章节信息
                            String detailUrl = courseServiceUrl + "/course/detail/" + courseId;
                            ResponseEntity<String> detailResp = restTemplate.getForEntity(detailUrl, String.class);
                            
                            if (detailResp.getStatusCode() == HttpStatus.OK && detailResp.getBody() != null) {
                                JSONObject detailJson = JSON.parseObject(detailResp.getBody());
                                if (detailJson.getIntValue("code") == 200) {
                                    JSONObject detailData = detailJson.getJSONObject("data");
                                    if (detailData != null) {
                                        // 提取章节信息
                                        List<Map<String, Object>> chapters = new ArrayList<>();
                                        if (detailData.containsKey("chapters")) {
                                            JSONArray chapterArr = detailData.getJSONArray("chapters");
                                            for (int i = 0; i < chapterArr.size(); i++) {
                                                JSONObject ch = chapterArr.getJSONObject(i);
                                                Map<String, Object> chapterMap = new HashMap<>();
                                                chapterMap.put("title", ch.getString("title"));
                                                chapterMap.put("duration", ch.getInteger("duration"));
                                                chapters.add(chapterMap);
                                            }
                                        }
                                        
                                        Map<String, Object> result = new HashMap<>();
                                        result.put("title", detailData.getString("title"));
                                        result.put("description", detailData.getString("description"));
                                        result.put("chapters", chapters);
                                        return result;
                                    }
                                }
                            }
                            
                            // 如果获取章节失败，返回基本信息
                            Map<String, Object> basic = new HashMap<>();
                            basic.put("title", course.getString("title"));
                            basic.put("chapters", Collections.emptyList());
                            return basic;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.warn("获取课程详情失败: {}", e.getMessage());
        }
        return null;
    }

    /**
     * 章节总结
     */
    public Map<String, Object> summarizeChapter(String content) {
        if (!enabled || apiKey == null || apiKey.isEmpty() || apiKey.equals("your-api-key-here")) {
            return getSimulatedSummary(content);
        }

        String prompt = "作为知学在线教育平台的AI助手，请总结以下学习内容：\n" + content + "\n" +
                       "请以JSON格式返回，包含title（总结标题）、content（总结内容）、keyPoints（关键知识点数组）。";

        String response = callAI(prompt);
        return parseSummaryResponse(response, content);
    }

    /**
     * 调用AI生成内容
     */
    private String callAI(String prompt) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + apiKey);

            List<Map<String, String>> messages = new ArrayList<>();

            Map<String, String> systemMsg = new HashMap<>();
            systemMsg.put("role", "system");
            systemMsg.put("content", "你是知学在线教育平台的AI学习助手。请直接返回JSON格式的内容，不要添加其他解释。");
            messages.add(systemMsg);

            Map<String, String> userMsg = new HashMap<>();
            userMsg.put("role", "user");
            userMsg.put("content", prompt);
            messages.add(userMsg);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("model", MODEL_QWEN);
            requestBody.put("messages", messages);
            requestBody.put("temperature", 0.7);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

            // 为通义千问 API 设置较短超时，避免长时间等待
            SimpleClientHttpRequestFactory aiFactory = new SimpleClientHttpRequestFactory();
            aiFactory.setConnectTimeout(5000);   // 5秒连接超时
            aiFactory.setReadTimeout(15000);     // 15秒读取超时
            RestTemplate aiRestTemplate = new RestTemplate(aiFactory);

            ResponseEntity<String> response = aiRestTemplate.exchange(
                    DASHSCOPE_API_URL,
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode root = objectMapper.readTree(response.getBody());
                JsonNode choices = root.path("choices");
                if (choices.isArray() && choices.size() > 0) {
                    return choices.get(0).path("message").path("content").asText();
                }
            }

            return "";
        } catch (Exception e) {
            log.error("调用AI异常: {}", e.getMessage());
            return "";
        }
    }

    // ==================== 模拟响应（当未配置API时使用） ====================

    private String getSimulatedResponse(String message) {
        return "【模拟模式】收到了您的消息：" + message + "\n\n" +
               "当前AI服务未配置真实API密钥，已启用模拟模式。\n" +
               "如需启用真实AI功能，请在 edu-ai 的 application.yml 中配置通义千问API密钥。";
    }

    private List<Map<String, Object>> getSimulatedRecommend(String interests) {
        List<Map<String, Object>> courses = new ArrayList<>();
        
        // 模拟真实课程数据结构
        String[][] sampleCourses = {
            {"1", "Java零基础入门", "编程", "张老师", "covers/java.jpg"},
            {"2", "Vue3全栈开发精讲", "前端", "李老师", "covers/vue.jpg"},
            {"3", "Python数据分析实战", "数据科学", "王老师", "covers/python.jpg"},
            {"4", "Spring Boot微服务架构", "后端", "刘老师", "covers/spring.jpg"},
            {"5", "React Native移动开发", "移动开发", "陈老师", "covers/react.jpg"}
        };
        
        for (String[] sample : sampleCourses) {
            Map<String, Object> course = new HashMap<>();
            course.put("id", Long.parseLong(sample[0]));
            course.put("title", sample[1]);
            course.put("categoryName", sample[2]);
            course.put("teacherName", sample[3]);
            course.put("cover", sample[4]);
            course.put("price", 99.00);
            course.put("studyCount", 1000 + new Random().nextInt(5000));
            course.put("score", 4.5 + new Random().nextDouble() * 0.5);
            course.put("reason", "根据您感兴趣的【" + interests + "】，这门课程非常适合您学习");
            courses.add(course);
        }
        
        return courses;
    }

    private Map<String, Object> getSimulatedStudyPlan(String courseName, String targetTime, String hoursPerDay) {
        Map<String, Object> plan = new HashMap<>();
        plan.put("week1", "学习" + courseName + "基础概念");
        plan.put("week2", "深入理解核心知识点");
        plan.put("week3", "完成课后练习");
        plan.put("week4", "实战项目应用");
        return plan;
    }

    private Map<String, Object> getSimulatedSummary(String content) {
        Map<String, Object> summary = new HashMap<>();
        summary.put("title", "章节内容总结");
        summary.put("content", "本章节主要介绍了相关概念和核心知识点，请认真学习并完成练习。");
        summary.put("keyPoints", Arrays.asList("核心概念", "关键特性", "实践应用", "复习要点"));
        return summary;
    }

    // ==================== 响应解析（用于AI生成的学习计划和总结） ====================

    private Map<String, Object> parsePlanResponse(String response, String courseName) {
        Map<String, Object> plan = new HashMap<>();
        try {
            if (response.startsWith("{")) {
                Map<String, Object> parsed = objectMapper.readValue(response, Map.class);
                return parsed;
            }
        } catch (Exception e) {
            log.warn("解析计划响应失败: {}", e.getMessage());
        }
        return getSimulatedStudyPlan(courseName, "", "");
    }

    private Map<String, Object> parseSummaryResponse(String response, String content) {
        Map<String, Object> summary = new HashMap<>();
        try {
            if (response.startsWith("{")) {
                Map<String, Object> parsed = objectMapper.readValue(response, Map.class);
                return parsed;
            }
        } catch (Exception e) {
            log.warn("解析总结响应失败: {}", e.getMessage());
        }
        return getSimulatedSummary(content);
    }
}
