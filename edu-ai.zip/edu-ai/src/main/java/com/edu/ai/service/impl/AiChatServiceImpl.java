package com.edu.ai.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.edu.ai.entity.AiChat;
import com.edu.ai.mapper.AiChatMapper;
import com.edu.ai.service.AiChatService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class AiChatServiceImpl extends ServiceImpl<AiChatMapper, AiChat> implements AiChatService {

    @Override
    public Page<AiChat> getPageList(int pageNum, int pageSize, Long memberId, String sessionId) {
        Page<AiChat> page = new Page<>(pageNum, pageSize);
        QueryWrapper<AiChat> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0).orderByDesc("create_time");

        if (memberId != null) {
            wrapper.eq("member_id", memberId);
        }
        if (StringUtils.hasText(sessionId)) {
            wrapper.eq("session_id", sessionId);
        }

        return this.page(page, wrapper);
    }
}
