package com.edu.course.config;
// 此文件已废弃，OSS配置已迁移至 MinioConfig.java
