package com.edu.course.config;

import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRule;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRuleManager;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Sentinel 规则配置（流控 + 熔断）
 * 在应用启动完成后初始化规则，使 @SentinelResource 注解真正生效
 */
@Component
public class SentinelRuleConfig implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(SentinelRuleConfig.class);

    @Override
    public void run(String... args) {
        // 加载流控规则
        List<FlowRule> flowRules = new ArrayList<>();

        FlowRule listFlowRule = new FlowRule();
        listFlowRule.setResource("course-list");
        listFlowRule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        listFlowRule.setCount(50);  // QPS 阈值
        listFlowRule.setControlBehavior(RuleConstant.CONTROL_BEHAVIOR_DEFAULT);
        flowRules.add(listFlowRule);

        FlowRuleManager.loadRules(flowRules);
        log.info("[Sentinel] 流控规则初始化完成，已加载 {} 条", flowRules.size());

        // 加载熔断规则
        List<DegradeRule> degradeRules = new ArrayList<>();

        DegradeRule listDegradeRule = new DegradeRule();
        listDegradeRule.setResource("course-list");
        listDegradeRule.setGrade(RuleConstant.DEGRADE_GRADE_EXCEPTION_RATIO);
        listDegradeRule.setCount(0.5);          // 异常比例阈值：50%
        listDegradeRule.setMinRequestAmount(10); // 最小请求数：10 个
        listDegradeRule.setStatIntervalMs(10000); // 统计时间窗口：10 秒
        listDegradeRule.setTimeWindow(10);       // 熔断时长：10 秒
        degradeRules.add(listDegradeRule);

        DegradeRuleManager.loadRules(degradeRules);
        log.info("[Sentinel] 熔断规则初始化完成，已加载 {} 条", degradeRules.size());
    }
}
