package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.page.PageResult;
import com.edu.common.result.R;
import com.edu.course.entity.Banner;
import com.edu.course.mapper.BannerMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course/admin/banner")
@RequiredArgsConstructor
public class AdminBannerController {

    private final BannerMapper bannerMapper;

    @GetMapping("/page")
    public R<PageResult<Banner>> page(
            @RequestParam(defaultValue = "1") Long current,
            @RequestParam(defaultValue = "10") Long size) {
        Page<Banner> page = new Page<>(current, size);
        QueryWrapper<Banner> wrapper = new QueryWrapper<Banner>().orderByDesc("sort");
        Page<Banner> result = bannerMapper.selectPage(page, wrapper);
        return R.ok(PageResult.of(result.getTotal(), result.getPages(),
            result.getCurrent(), result.getSize(), result.getRecords()));
    }

    @GetMapping("/list")
    public R<List<Banner>> list() {
        QueryWrapper<Banner> wrapper = new QueryWrapper<Banner>().orderByDesc("sort");
        return R.ok(bannerMapper.selectList(wrapper));
    }

    @GetMapping("/{id}")
    public R<Banner> getById(@PathVariable Long id) {
        return R.ok(bannerMapper.selectById(id));
    }

    @PostMapping
    public R<Void> add(@RequestBody Banner banner) {
        bannerMapper.insert(banner);
        return R.ok();
    }

    @PutMapping("/{id}")
    public R<Void> update(@PathVariable Long id, @RequestBody Banner banner) {
        banner.setId(id);
        bannerMapper.updateById(banner);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        bannerMapper.deleteById(id);
        return R.ok();
    }
}
