package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.page.PageResult;
import com.edu.common.result.R;
import com.edu.course.entity.Category;
import com.edu.course.mapper.CategoryMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course/admin/category")
@RequiredArgsConstructor
public class AdminCategoryController {

    private final CategoryMapper categoryMapper;

    @GetMapping("/tree")
    public R<List<Category>> getTree() {
        QueryWrapper<Category> wrapper = new QueryWrapper<Category>().orderByAsc("sort");
        List<Category> all = categoryMapper.selectList(wrapper);
        return R.ok(buildTree(all));
    }

    @GetMapping("/page")
    public R<PageResult<Category>> page(
            @RequestParam(defaultValue = "1") Long current,
            @RequestParam(defaultValue = "10") Long size,
            @RequestParam(required = false) String name) {
        Page<Category> page = new Page<>(current, size);
        QueryWrapper<Category> wrapper = new QueryWrapper<Category>();
        if (name != null) wrapper.like("name", name);
        wrapper.orderByAsc("sort");
        Page<Category> result = categoryMapper.selectPage(page, wrapper);
        return R.ok(PageResult.of(result.getTotal(), result.getPages(),
            result.getCurrent(), result.getSize(), result.getRecords()));
    }

    @PostMapping
    public R<Void> add(@RequestBody Category category) {
        categoryMapper.insert(category);
        return R.ok();
    }

    @PutMapping("/{id}")
    public R<Void> update(@PathVariable Long id, @RequestBody Category category) {
        category.setId(id);
        categoryMapper.updateById(category);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        // 先删除子分类
        categoryMapper.delete(new QueryWrapper<Category>().eq("parent_id", id));
        // 再删除当前分类
        categoryMapper.deleteById(id);
        return R.ok();
    }

    @GetMapping
    public R<List<Category>> list() {
        QueryWrapper<Category> wrapper = new QueryWrapper<Category>().orderByAsc("sort");
        List<Category> all = categoryMapper.selectList(wrapper);
        return R.ok(buildTree(all));
    }

    private List<Category> buildTree(List<Category> flat) {
        return flat.stream()
            .filter(c -> c.getParentId() == 0)
            .peek(p -> p.setChildren(flat.stream()
                .filter(c -> c.getParentId().equals(p.getId()))
                .toList()))
            .toList();
    }
}
