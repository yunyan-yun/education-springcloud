package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.Comment;
import com.edu.course.mapper.CommentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/course/admin/comment")
@RequiredArgsConstructor
public class AdminCommentController {

    private final CommentMapper commentMapper;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/page")
    public R<Map<String, Object>> page(
            @RequestParam(defaultValue = "1") Long current,
            @RequestParam(defaultValue = "10") Long size,
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer score) {
        long offset = (current - 1) * size;

        // SQL 层分页
        List<Comment> records = commentMapper.selectCommentPageListWithJoin(keyword, score, courseId, offset, size);

        // 同步用户最新头像
        if (!records.isEmpty()) {
            Set<Long> memberIds = records.stream()
                    .map(Comment::getMemberId)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());

            if (!memberIds.isEmpty()) {
                Map<Long, String> avatarMap = getMemberAvatars(memberIds);
                for (Comment comment : records) {
                    if (comment.getMemberId() != null && avatarMap.containsKey(comment.getMemberId())) {
                        comment.setMemberAvatar(avatarMap.get(comment.getMemberId()));
                    }
                }
            }
        }

        long total = commentMapper.selectCommentPageCountWithJoin(keyword, score, courseId);

        Map<String, Object> result = new HashMap<>();
        result.put("records", records);
        result.put("total", total);
        result.put("current", current);
        result.put("size", size);

        return R.ok(result);
    }

    /**
     * 批量获取用户头像
     */
    private Map<Long, String> getMemberAvatars(Set<Long> memberIds) {
        Map<Long, String> result = new HashMap<>();
        for (Long memberId : memberIds) {
            try {
                String url = "http://edu-user/user/member/avatar/" + memberId;
                ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
                if (response.getStatusCode().value() == 200 && response.getBody() != null) {
                    Map<String, Object> body = response.getBody();
                    if ("200".equals(body.get("code")) || Boolean.TRUE.equals(body.get("success"))) {
                        Object data = body.get("data");
                        if (data != null && !data.toString().isEmpty()) {
                            result.put(memberId, data.toString());
                        }
                    }
                }
            } catch (Exception e) {
                // 忽略错误
            }
        }
        return result;
    }

    @GetMapping("/list")
    public R<List<Comment>> list() {
        QueryWrapper<Comment> wrapper = new QueryWrapper<Comment>().orderByDesc("create_time");
        return R.ok(commentMapper.selectList(wrapper));
    }

    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        System.out.println(">>> 删除评论 id=" + id);
        commentMapper.deleteById(id);
        // 验证删除后总数
        long count = commentMapper.selectCommentPageCountWithJoin(null, null, null);
        System.out.println(">>> 删除后数据库总数=" + count);
        return R.ok();
    }

    /**
     * 删除用户的所有评论（级联）
     */
    @DeleteMapping("/member/{memberId}")
    public R<Void> deleteByMember(@PathVariable Long memberId) {
        commentMapper.delete(new QueryWrapper<Comment>().eq("member_id", memberId));
        return R.ok();
    }
}
