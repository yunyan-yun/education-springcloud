package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.result.R;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import com.edu.course.entity.Course;
import com.edu.course.entity.Category;
import com.edu.course.entity.Chapter;
import com.edu.course.entity.Video;
import com.edu.course.entity.Comment;
import com.edu.course.entity.Favorite;
import com.edu.course.mapper.CourseMapper;
import com.edu.course.mapper.CategoryMapper;
import com.edu.course.mapper.ChapterMapper;
import com.edu.course.mapper.VideoMapper;
import com.edu.course.mapper.CommentMapper;
import com.edu.course.mapper.FavoriteMapper;
import com.edu.course.service.CourseService;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/course/admin/course")
@RequiredArgsConstructor
public class AdminCourseController {

    private final CourseMapper courseMapper;
    private final CategoryMapper categoryMapper;
    private final ChapterMapper chapterMapper;
    private final VideoMapper videoMapper;
    private final CommentMapper commentMapper;
    private final FavoriteMapper favoriteMapper;
    private final CourseService courseService;
    private final RestTemplate restTemplate;

    @GetMapping("/page")
    public R<?> page(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {

        Page<Course> page = new Page<>(current, size);
        QueryWrapper<Course> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);

        if (StringUtils.hasText(keyword)) {
            wrapper.like("title", keyword);
        }
        if (status != null) {
            wrapper.eq("status", status);
        }
        wrapper.orderByDesc("create_time");

        Page<Course> result = courseMapper.selectPage(page, wrapper);
        // 实时更新学习人数和评分
        courseService.enrichCoursesWithStats(result.getRecords());
        return R.ok(result);
    }

    @GetMapping("/{id}")
    public R<?> getById(@PathVariable Long id) {
        Course course = courseMapper.selectById(id);

        // 获取章节和视频
        LambdaQueryWrapper<Chapter> cw = new LambdaQueryWrapper<>();
        cw.eq(Chapter::getCourseId, id).orderByAsc(Chapter::getSort);
        List<Chapter> chapters = chapterMapper.selectList(cw);

        for (Chapter chapter : chapters) {
            LambdaQueryWrapper<Video> vw = new LambdaQueryWrapper<>();
            vw.eq(Video::getChapterId, chapter.getId()).orderByAsc(Video::getSort);
            chapter.setVideos(videoMapper.selectList(vw));
        }

        Map<String, Object> result = new HashMap<>();
        result.put("course", course);
        result.put("chapters", chapters);
        return R.ok(result);
    }

    /**
     * 获取课程总数
     */
    @GetMapping("/count")
    public R<Long> getCourseCount() {
        QueryWrapper<Course> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);
        long count = courseMapper.selectCount(wrapper);
        return R.ok(count);
    }

    @PutMapping("/{id}/publish")
    public R<?> publish(@PathVariable Long id) {
        Course course = new Course();
        course.setId(id);
        course.setStatus(1);
        courseMapper.updateById(course);
        return R.ok();
    }

    @PutMapping("/{id}/offline")
    public R<?> offline(@PathVariable Long id) {
        Course course = new Course();
        course.setId(id);
        course.setStatus(2);
        courseMapper.updateById(course);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    public R<?> delete(@PathVariable Long id) {
        // 1. 删除该课程的所有评论（物理删除）
        commentMapper.delete(new QueryWrapper<Comment>().eq("course_id", id));

        // 2. 删除该课程的所有收藏（物理删除）
        favoriteMapper.delete(new QueryWrapper<Favorite>().eq("course_id", id));

        // 3. 删除该课程的所有章节和视频（物理删除）
        LambdaQueryWrapper<Chapter> cw = new LambdaQueryWrapper<Chapter>().eq(Chapter::getCourseId, id);
        List<Chapter> chapters = chapterMapper.selectList(cw);
        if (!chapters.isEmpty()) {
            List<Long> chapterIds = chapters.stream().map(Chapter::getId).collect(Collectors.toList());
            // 删除章节下的所有视频
            videoMapper.delete(new LambdaQueryWrapper<Video>().in(Video::getChapterId, chapterIds));
        }
        // 删除所有章节
        chapterMapper.delete(cw);

        // 4. 物理删除课程本身（绕过 @TableLogic）
        courseMapper.physicalDeleteById(id);

        return R.ok();
    }

    /**
     * 保存新课程（含章节和视频）
     */
    @PostMapping
    public R<?> save(@RequestBody Map<String, Object> payload) {
        // 取出课程基本信息
        Object courseObj = payload.get("course");
        Course course = new Course();
        if (courseObj instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> courseMap = (Map<String, Object>) courseObj;
            course.setId(null); // 确保新增
            course.setStatus(0); // 默认草稿状态
            if (courseMap.get("title") != null) course.setTitle((String) courseMap.get("title"));
            if (courseMap.get("subTitle") != null) course.setSubTitle((String) courseMap.get("subTitle"));
            if (courseMap.get("cover") != null) course.setCover((String) courseMap.get("cover"));
            if (courseMap.get("price") != null) course.setPrice(new java.math.BigDecimal(courseMap.get("price").toString()));
            if (courseMap.get("originalPrice") != null) course.setOriginalPrice(new java.math.BigDecimal(courseMap.get("originalPrice").toString()));
            if (courseMap.get("teacherId") != null) course.setTeacherId(((Number) courseMap.get("teacherId")).longValue());
            if (courseMap.get("teacherName") != null) course.setTeacherName((String) courseMap.get("teacherName"));
            if (courseMap.get("categoryId") != null) course.setCategoryId(((Number) courseMap.get("categoryId")).longValue());
            if (courseMap.get("categoryName") != null) course.setCategoryName((String) courseMap.get("categoryName"));
            if (courseMap.get("description") != null) course.setDescription((String) courseMap.get("description"));
            if (courseMap.get("detail") != null) course.setDetail((String) courseMap.get("detail"));
            // 处理 isFree（前端可能是 Boolean 或 Number）
            Object isFree = courseMap.get("isFree");
            if (isFree instanceof Boolean) {
                course.setIsFree(((Boolean) isFree) ? 1 : 0);
            } else if (isFree instanceof Number) {
                course.setIsFree(((Number) isFree).intValue());
            }
            Object isRecommend = courseMap.get("isRecommend");
            if (isRecommend instanceof Boolean) {
                course.setIsRecommend(((Boolean) isRecommend) ? 1 : 0);
            } else if (isRecommend instanceof Number) {
                course.setIsRecommend(((Number) isRecommend).intValue());
            }
            Object isHot = courseMap.get("isHot");
            if (isHot instanceof Boolean) {
                course.setIsHot(((Boolean) isHot) ? 1 : 0);
            } else if (isHot instanceof Number) {
                course.setIsHot(((Number) isHot).intValue());
            }
            if (courseMap.get("sort") != null) course.setSort(((Number) courseMap.get("sort")).intValue());
        }
        courseMapper.insert(course);
        Long courseId = course.getId();

        // 处理章节和视频
        List<Map<String, Object>> chaptersData = (List<Map<String, Object>>) payload.get("chapters");
        if (chaptersData != null && courseId != null) {
            for (int i = 0; i < chaptersData.size(); i++) {
                Map<String, Object> chapterData = chaptersData.get(i);
                Chapter chapter = new Chapter();
                chapter.setCourseId(courseId);
                chapter.setTitle((String) chapterData.get("title"));
                if (chapterData.get("description") != null) {
                    chapter.setDescription((String) chapterData.get("description"));
                }
                chapter.setSort(i + 1);
                chapterMapper.insert(chapter);

                List<Map<String, Object>> videosData = (List<Map<String, Object>>) chapterData.get("videos");
                if (videosData != null) {
                    for (int j = 0; j < videosData.size(); j++) {
                        Map<String, Object> videoData = videosData.get(j);
                        Video video = new Video();
                        video.setCourseId(courseId);
                        video.setChapterId(chapter.getId());
                        video.setTitle((String) videoData.get("title"));
                        if (videoData.get("description") != null) {
                            video.setDescription((String) videoData.get("description"));
                        }
                        video.setVideoUrl((String) videoData.get("videoUrl"));
                        Object duration = videoData.get("duration");
                        Long durationValue = duration != null ? ((Number) duration).longValue() : null;
                        video.setDuration(durationValue);
                        Object isFree = videoData.get("isFree");
                        if (isFree instanceof Boolean) {
                            video.setIsFree(((Boolean) isFree) ? 1 : 0);
                        } else if (isFree instanceof Number) {
                            video.setIsFree(((Number) isFree).intValue());
                        }
                        video.setSort(j + 1);
                        videoMapper.insert(video);
                    }
                }
            }
        }

        return R.ok(course);
    }

    /**
     * 更新课程（含章节和视频）
     */
    @PutMapping("/{id}")
    public R<?> update(@PathVariable Long id, @RequestBody Map<String, Object> payload) {
        // 取出课程基本信息（前端发的是 course 嵌套对象）
        Object courseObj = payload.get("course");
        Course course = new Course();
        if (courseObj instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> courseMap = (Map<String, Object>) courseObj;
            course.setId(id);
            if (courseMap.get("title") != null) course.setTitle((String) courseMap.get("title"));
            if (courseMap.get("subTitle") != null) course.setSubTitle((String) courseMap.get("subTitle"));
            if (courseMap.get("cover") != null) course.setCover((String) courseMap.get("cover"));
            if (courseMap.get("price") != null) course.setPrice(new java.math.BigDecimal(courseMap.get("price").toString()));
            if (courseMap.get("originalPrice") != null) course.setOriginalPrice(new java.math.BigDecimal(courseMap.get("originalPrice").toString()));
            if (courseMap.get("teacherId") != null) course.setTeacherId(((Number) courseMap.get("teacherId")).longValue());
            if (courseMap.get("teacherName") != null) course.setTeacherName((String) courseMap.get("teacherName"));
            if (courseMap.get("categoryId") != null) course.setCategoryId(((Number) courseMap.get("categoryId")).longValue());
            if (courseMap.get("categoryName") != null) course.setCategoryName((String) courseMap.get("categoryName"));
            if (courseMap.get("description") != null) course.setDescription((String) courseMap.get("description"));
            if (courseMap.get("detail") != null) course.setDetail((String) courseMap.get("detail"));
            // 处理 isFree（前端可能是 Boolean 或 Number）
            Object isFree = courseMap.get("isFree");
            if (isFree instanceof Boolean) {
                course.setIsFree(((Boolean) isFree) ? 1 : 0);
            } else if (isFree instanceof Number) {
                course.setIsFree(((Number) isFree).intValue());
            }
            Object isRecommend = courseMap.get("isRecommend");
            if (isRecommend instanceof Boolean) {
                course.setIsRecommend(((Boolean) isRecommend) ? 1 : 0);
            } else if (isRecommend instanceof Number) {
                course.setIsRecommend(((Number) isRecommend).intValue());
            }
            Object isHot = courseMap.get("isHot");
            if (isHot instanceof Boolean) {
                course.setIsHot(((Boolean) isHot) ? 1 : 0);
            } else if (isHot instanceof Number) {
                course.setIsHot(((Number) isHot).intValue());
            }
            if (courseMap.get("status") != null) course.setStatus(((Number) courseMap.get("status")).intValue());
            if (courseMap.get("sort") != null) course.setSort(((Number) courseMap.get("sort")).intValue());
        }
        courseMapper.updateById(course);

        // 处理章节和视频
        List<Map<String, Object>> chaptersData = (List<Map<String, Object>>) payload.get("chapters");
        if (chaptersData != null) {
            // 1. 删除该课程原有视频和章节
            LambdaQueryWrapper<Chapter> cw = new LambdaQueryWrapper<Chapter>().eq(Chapter::getCourseId, id);
            List<Chapter> oldChapters = chapterMapper.selectList(cw);
            List<Long> oldChapterIds = oldChapters.stream().map(Chapter::getId).collect(java.util.stream.Collectors.toList());
            if (!oldChapterIds.isEmpty()) {
                videoMapper.delete(new LambdaQueryWrapper<Video>().in(Video::getChapterId, oldChapterIds));
            }
            chapterMapper.delete(cw);

            // 2. 重新插入章节和视频
            for (int i = 0; i < chaptersData.size(); i++) {
                Map<String, Object> chapterData = chaptersData.get(i);
                Chapter chapter = new Chapter();
                chapter.setCourseId(id);
                chapter.setTitle((String) chapterData.get("title"));
                if (chapterData.get("description") != null) {
                    chapter.setDescription((String) chapterData.get("description"));
                }
                chapter.setSort(i + 1);
                chapterMapper.insert(chapter);

                List<Map<String, Object>> videosData = (List<Map<String, Object>>) chapterData.get("videos");
                if (videosData != null) {
                    for (int j = 0; j < videosData.size(); j++) {
                        Map<String, Object> videoData = videosData.get(j);
                        Video video = new Video();
                        video.setCourseId(id);
                        video.setChapterId(chapter.getId());
                        video.setTitle((String) videoData.get("title"));
                        if (videoData.get("description") != null) {
                            video.setDescription((String) videoData.get("description"));
                        }
                        video.setVideoUrl((String) videoData.get("videoUrl"));
                        Object duration = videoData.get("duration");
                        Long durationValue = duration != null ? ((Number) duration).longValue() : null;
                        video.setDuration(durationValue);
                        // 处理免费试看（前端可能是 Boolean 或 Number）
                        Object isFree = videoData.get("isFree");
                        if (isFree instanceof Boolean) {
                            video.setIsFree(((Boolean) isFree) ? 1 : 0);
                        } else if (isFree instanceof Number) {
                            video.setIsFree(((Number) isFree).intValue());
                        }
                        video.setSort(j + 1);
                        videoMapper.insert(video);
                    }
                }
            }
        }

        // 3. 同步更新所有相关订单的冗余字段（课程名称、封面、讲师名称）
        try {
            restTemplate.postForObject(
                "http://edu-order/order/admin/order/sync-by-course/" + id,
                null, Map.class
            );
        } catch (Exception e) {
            // 同步失败不影响课程更新结果的返回
            System.err.println("同步订单冗余字段失败: " + e.getMessage());
        }

        return R.ok(course);
    }

    /**
     * 获取课程分类分布
     */
    @GetMapping("/stats/category-distribution")
    public R<List<Map<String, Object>>> getCategoryDistribution() {
        List<Map<String, Object>> result = new ArrayList<>();

        // 获取所有一级分类
        QueryWrapper<Category> categoryWrapper = new QueryWrapper<>();
        categoryWrapper.eq("is_deleted", 0).isNull("parent_id").or().eq("parent_id", 0);
        List<Category> categories = categoryMapper.selectList(categoryWrapper);

        for (Category category : categories) {
            // 统计该分类下的课程数量
            QueryWrapper<Course> courseWrapper = new QueryWrapper<>();
            courseWrapper.eq("is_deleted", 0)
                        .eq("status", 1) // 已发布
                        .eq("category_id", category.getId());
            long count = courseMapper.selectCount(courseWrapper);

            if (count > 0) {
                Map<String, Object> item = new HashMap<>();
                item.put("name", category.getName());
                item.put("value", count);
                result.add(item);
            }
        }

        // 按数量排序，取前5
        result.sort((a, b) -> Long.compare((Long) b.get("value"), (Long) a.get("value")));
        if (result.size() > 5) {
            result = result.subList(0, 5);
        }

        return R.ok(result);
    }
}
