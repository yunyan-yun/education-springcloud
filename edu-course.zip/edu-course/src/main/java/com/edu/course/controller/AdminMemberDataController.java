package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.Favorite;
import com.edu.course.entity.StudyProgress;
import com.edu.course.mapper.FavoriteMapper;
import com.edu.course.mapper.StudyProgressMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/course/admin")
@RequiredArgsConstructor
public class AdminMemberDataController {

    private final FavoriteMapper favoriteMapper;
    private final StudyProgressMapper studyProgressMapper;

    /**
     * 删除用户的所有收藏（级联）
     */
    @DeleteMapping("/favorite/member/{memberId}")
    public R<Void> deleteFavoritesByMember(@PathVariable Long memberId) {
        favoriteMapper.delete(new QueryWrapper<Favorite>().eq("member_id", memberId));
        return R.ok();
    }

    /**
     * 删除用户的学习进度（级联）
     */
    @DeleteMapping("/progress/member/{memberId}")
    public R<Void> deleteProgressByMember(@PathVariable Long memberId) {
        studyProgressMapper.delete(new QueryWrapper<StudyProgress>().eq("member_id", memberId));
        return R.ok();
    }
}
