package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.result.R;
import com.edu.course.entity.Chapter;
import com.edu.course.entity.Question;
import com.edu.course.entity.Video;
import com.edu.course.mapper.ChapterMapper;
import com.edu.course.mapper.QuestionMapper;
import com.edu.course.mapper.VideoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/course/admin/question")
@RequiredArgsConstructor
public class AdminQuestionController {

    private final QuestionMapper questionMapper;
    private final ChapterMapper chapterMapper;
    private final VideoMapper videoMapper;

    /**
     * 分页查询题目列表
     */
    @GetMapping("/page")
    public R<?> page(
            @RequestParam(defaultValue = "1") Long current,
            @RequestParam(defaultValue = "10") Long size,
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) Long chapterId,
            @RequestParam(required = false) Long videoId,
            @RequestParam(required = false) String keyword) {

        Page<Question> page = new Page<>(current, size);
        LambdaQueryWrapper<Question> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Question::getIsDeleted, 0);
        if (courseId != null) {
            wrapper.eq(Question::getCourseId, courseId);
        }
        if (chapterId != null) {
            wrapper.eq(Question::getChapterId, chapterId);
        }
        if (videoId != null) {
            wrapper.eq(Question::getVideoId, videoId);
        }
        if (keyword != null && !keyword.trim().isEmpty()) {
            wrapper.like(Question::getContent, keyword.trim());
        }
        wrapper.orderByAsc(Question::getSort);
        wrapper.orderByDesc(Question::getCreateTime);

        Page<Question> result = questionMapper.selectPage(page, wrapper);
        return R.ok(result);
    }

    /**
     * 获取单个题目
     */
    @GetMapping("/{id}")
    public R<Question> getById(@PathVariable Long id) {
        Question question = questionMapper.selectById(id);
        if (question == null || question.getIsDeleted() == 1) {
            return R.fail(404, "题目不存在");
        }
        return R.ok(question);
    }

    /**
     * 新增题目
     */
    @PostMapping
    public R<Void> add(@RequestBody Question question) {
        if (question.getCourseId() == null || question.getChapterId() == null || question.getVideoId() == null) {
            return R.fail(400, "课程ID、章节ID和视频ID不能为空");
        }
        if (question.getContent() == null || question.getContent().trim().isEmpty()) {
            return R.fail(400, "题目内容不能为空");
        }
        if (question.getAnswer() == null || !question.getAnswer().matches("[A-Da-d]")) {
            return R.fail(400, "正确答案必须是A/B/C/D");
        }
        if (question.getSort() == null) {
            question.setSort(0);
        }
        questionMapper.insert(question);
        return R.ok();
    }

    /**
     * 修改题目
     */
    @PutMapping("/{id}")
    public R<Void> update(@PathVariable Long id, @RequestBody Question question) {
        Question exist = questionMapper.selectById(id);
        if (exist == null || exist.getIsDeleted() == 1) {
            return R.fail(404, "题目不存在");
        }
        if (question.getAnswer() != null && !question.getAnswer().matches("[A-Da-d]")) {
            return R.fail(400, "正确答案必须是A/B/C/D");
        }
        question.setId(id);
        questionMapper.updateById(question);
        return R.ok();
    }

    /**
     * 删除题目
     */
    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        questionMapper.deleteById(id);
        return R.ok();
    }

    /**
     * 获取课程下的章节列表（下拉选择用）
     */
    @GetMapping("/chapters")
    public R<List<Chapter>> getChapters(@RequestParam Long courseId) {
        LambdaQueryWrapper<Chapter> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Chapter::getCourseId, courseId)
               .eq(Chapter::getIsDeleted, 0)
               .orderByAsc(Chapter::getSort);
        return R.ok(chapterMapper.selectList(wrapper));
    }

    /**
     * 获取章节下的视频列表（下拉选择用）
     */
    @GetMapping("/videos")
    public R<List<Video>> getVideos(@RequestParam Long chapterId) {
        LambdaQueryWrapper<Video> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Video::getChapterId, chapterId)
               .eq(Video::getIsDeleted, 0)
               .orderByAsc(Video::getSort);
        return R.ok(videoMapper.selectList(wrapper));
    }
}
