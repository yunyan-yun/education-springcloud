package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.page.PageResult;
import com.edu.common.result.R;
import com.edu.course.entity.Teacher;
import com.edu.course.entity.Course;
import com.edu.course.mapper.TeacherMapper;
import com.edu.course.mapper.CourseMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course/admin/teacher")
@RequiredArgsConstructor
public class AdminTeacherController {

    private final TeacherMapper teacherMapper;
    private final CourseMapper courseMapper;

    @GetMapping("/page")
    public R<PageResult<Teacher>> page(
            @RequestParam(defaultValue = "1") Long current,
            @RequestParam(defaultValue = "10") Long size,
            @RequestParam(required = false) String name) {
        Page<Teacher> page = new Page<>(current, size);
        QueryWrapper<Teacher> wrapper = new QueryWrapper<Teacher>();
        if (name != null) wrapper.like("name", name);
        wrapper.orderByAsc("sort");
        Page<Teacher> result = teacherMapper.selectPage(page, wrapper);
        return R.ok(PageResult.of(result.getTotal(), result.getPages(),
            result.getCurrent(), result.getSize(), result.getRecords()));
    }

    @GetMapping("/list")
    public R<List<Teacher>> list() {
        QueryWrapper<Teacher> wrapper = new QueryWrapper<Teacher>().orderByAsc("sort");
        return R.ok(teacherMapper.selectList(wrapper));
    }

    @GetMapping("/{id}")
    public R<Teacher> getById(@PathVariable Long id) {
        return R.ok(teacherMapper.selectById(id));
    }

    @PostMapping
    public R<Void> add(@RequestBody Teacher teacher) {
        if (teacher.getSort() == null) teacher.setSort(0);
        if (teacher.getStatus() == null) teacher.setStatus(1);
        teacherMapper.insert(teacher);
        return R.ok();
    }

    @PutMapping("/{id}")
    public R<Void> update(@PathVariable Long id, @RequestBody Teacher teacher) {
        teacher.setId(id);
        teacherMapper.updateById(teacher);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        // 先更新关联课程中的讲师名称
        UpdateWrapper<Course> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("teacher_id", id);
        updateWrapper.set("teacher_name", "[讲师已删除]");
        courseMapper.update(null, updateWrapper);
        // 再物理删除讲师
        teacherMapper.deleteById(id);
        return R.ok();
    }
}
