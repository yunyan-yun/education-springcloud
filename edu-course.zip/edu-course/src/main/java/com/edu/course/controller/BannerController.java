package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.Banner;
import com.edu.course.mapper.BannerMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/course/banner")
@RequiredArgsConstructor
public class BannerController {

    private final BannerMapper bannerMapper;

    @GetMapping
    public R<List<Banner>> getBannerList() {
        QueryWrapper<Banner> wrapper = new QueryWrapper<Banner>()
            .eq("is_deleted", 0)
            .orderByDesc("sort");
        return R.ok(bannerMapper.selectList(wrapper));
    }
}
