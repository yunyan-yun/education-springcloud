package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.Category;
import com.edu.course.mapper.CategoryMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/course/category")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryMapper categoryMapper;

    @GetMapping
    public R<List<Category>> getCategoryTree() {
        QueryWrapper<Category> wrapper = new QueryWrapper<Category>().orderByAsc("sort");
        List<Category> all = categoryMapper.selectList(wrapper);
        return R.ok(buildTree(all));
    }

    private List<Category> buildTree(List<Category> flat) {
        return flat.stream()
            .filter(c -> c.getParentId() == 0)
            .peek(p -> p.setChildren(flat.stream()
                .filter(c -> c.getParentId().equals(p.getId()))
                .toList()))
            .toList();
    }
}
