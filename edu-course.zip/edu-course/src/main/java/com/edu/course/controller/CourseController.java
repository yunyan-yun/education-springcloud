package com.edu.course.controller;

import com.edu.common.result.R;
import com.edu.course.entity.Comment;
import com.edu.course.entity.StudyProgress;
import com.edu.course.service.CourseService;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/course")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping("/recommend")
    public R<?> getRecommendCourses() {
        return R.ok(courseService.getRecommendCourses());
    }

    @GetMapping("/hot")
    public R<?> getHotCourses() {
        return R.ok(courseService.getHotCourses());
    }

    @GetMapping("/latest")
    public R<?> getLatestCourses() {
        return R.ok(courseService.getLatestCourses());
    }

    @GetMapping("/list")
    @SentinelResource(value = "course-list", blockHandler = "listBlockHandler")
    public R<Map<String, Object>> searchCourses(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Integer isFree,
            @RequestParam(required = false) String sortBy,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "12") Integer size) {
        return R.ok(courseService.searchCourses(keyword, categoryId, isFree, sortBy, current, size));
    }

    /**
     * 课程列表接口流控降级处理
     * 触发条件：QPS超过阈值
     */
    public R<Map<String, Object>> listBlockHandler(
            String keyword, Long categoryId, Integer isFree, String sortBy, Integer current, Integer size,
            BlockException ex) {
        return R.fail(429, "请求过于频繁，请稍后再试");
    }

    @GetMapping("/detail/{id}")
    public R<Map<String, Object>> getCourseDetail(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        return R.ok(courseService.getCourseDetail(id, userId));
    }

    private Long getUserIdOptional(HttpServletRequest request) {
        try {
            String userId = request.getHeader("X-User-Id");
            if (userId != null && !userId.isEmpty()) {
                return Long.parseLong(userId);
            }
        } catch (Exception e) {
            // 忽略，用户未登录
        }
        return null;
    }

    @GetMapping("/video/{videoId}/play")
    public R<String> getPlayUrl(@PathVariable Long videoId, HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        return R.ok(courseService.getPlayUrl(videoId, userId));
    }

    /**
     * 记录学习进度
     */
    @PostMapping("/progress")
    public R<Void> recordProgress(
            @RequestBody Map<String, Object> params,
            HttpServletRequest request) {
        Long userId = getUserId(request);
        
        // 参数校验
        Object videoIdObj = params.get("videoId");
        Object watchTimeObj = params.get("watchTime");
        if (videoIdObj == null || watchTimeObj == null) {
            return R.fail(400, "参数错误：缺少必要参数");
        }
        
        Long videoId;
        Integer watchTime;
        try {
            videoId = Long.valueOf(videoIdObj.toString());
            watchTime = Integer.valueOf(watchTimeObj.toString());
        } catch (NumberFormatException e) {
            return R.fail(400, "参数错误：参数格式不正确");
        }
        
        Boolean finished = Boolean.valueOf(params.getOrDefault("finished", false).toString());
        courseService.recordProgress(userId, videoId, watchTime, finished);
        return R.ok();
    }

    /**
     * 获取学习进度
     */
    @GetMapping("/progress/{videoId}")
    public R<StudyProgress> getProgress(
            @PathVariable Long videoId,
            HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        if (userId == null) {
            return R.ok(null);
        }
        return R.ok(courseService.getProgress(userId, videoId));
    }

    /**
     * 获取用户已购课程（个人中心）
     */
    @GetMapping("/purchased")
    public R<?> getPurchasedCourses(HttpServletRequest request) {
        Long userId = getUserId(request);
        return R.ok(courseService.getPurchasedCourses(userId));
    }

    /**
     * 获取用户最近学习的课程（按最新学习时间排序）
     */
    @GetMapping("/recent-courses")
    public R<?> getRecentCourses(
            @RequestParam(defaultValue = "3") Integer limit,
            HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        if (userId == null) {
            return R.ok(java.util.Collections.emptyList());
        }
        return R.ok(courseService.getRecentStudyCourses(userId, limit != null ? limit : 3));
    }

    /**
     * 获取用户学习统计数据（个人中心用）
     */
    @GetMapping("/stats")
    public R<Map<String, Object>> getUserStats(HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        if (userId == null) {
            Map<String, Object> emptyStats = new java.util.HashMap<>();
            emptyStats.put("courseCount", 0);
            emptyStats.put("studyMinutes", 0);
            emptyStats.put("finishedCount", 0);
            return R.ok(emptyStats);
        }
        return R.ok(courseService.getUserStudyStats(userId));
    }

    /**
     * 收藏/取消收藏课程
     * @return true 已收藏 false 未收藏
     */
    @PostMapping("/{courseId}/favorite")
    public R<Boolean> toggleFavorite(
            @PathVariable Long courseId,
            HttpServletRequest request) {
        Long userId = getUserId(request);
        boolean isFavorited = courseService.toggleFavorite(userId, courseId);
        return R.ok(isFavorited);
    }

    /**
     * 获取用户收藏的课程列表
     */
    @GetMapping("/favorites")
    public R<?> getFavorites(HttpServletRequest request) {
        Long userId = getUserId(request);
        return R.ok(courseService.getFavorites(userId));
    }

    /**
     * 获取课程评论列表
     */
    @GetMapping("/{courseId}/comments")
    public R<Map<String, Object>> getComments(
            @PathVariable Long courseId,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size) {
        return R.ok(courseService.getComments(courseId, current, size));
    }

    /**
     * 添加评论
     */
    @PostMapping("/{courseId}/comment")
    public R<Comment> addComment(
            @PathVariable Long courseId,
            @RequestBody Map<String, Object> params,
            HttpServletRequest request) {
        try {
            Long userId = getUserId(request);
            String content = params.get("content") != null ? params.get("content").toString() : "";
            Integer score = params.get("score") != null ? Integer.parseInt(params.get("score").toString()) : 5;
            String nickname = params.get("nickname") != null ? params.get("nickname").toString() : "匿名用户";
            String avatar = params.get("avatar") != null ? params.get("avatar").toString() : "";
            
            if (content == null || content.trim().isEmpty()) {
                return R.fail(400, "评论内容不能为空");
            }
            
            Comment comment = courseService.addComment(courseId, userId, nickname, avatar, content, score);
            return R.ok(comment);
        } catch (RuntimeException e) {
            return R.fail(400, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail(500, "系统错误，请稍后重试");
        }
    }

    /**
     * 获取用户打卡统计数据
     */
    @GetMapping("/checkin/stats")
    public R<Map<String, Object>> getCheckinStats(HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        if (userId == null) {
            Map<String, Object> empty = new java.util.HashMap<>();
            empty.put("totalDays", 0);
            empty.put("continuousDays", 0);
            empty.put("todayCheckedIn", false);
            return R.ok(empty);
        }
        return R.ok(courseService.getCheckinStats(userId));
    }

    /**
     * 获取用户某月的打卡日历
     */
    @GetMapping("/checkin/calendar")
    public R<List<String>> getCheckinCalendar(
            @RequestParam int year,
            @RequestParam int month,
            HttpServletRequest request) {
        Long userId = getUserIdOptional(request);
        if (userId == null) {
            return R.ok(new java.util.ArrayList<>());
        }
        return R.ok(courseService.getCheckinCalendar(userId, year, month));
    }

    /**
     * 获取课程证书数据
     */
    @GetMapping("/certificate/{courseId}")
    public R<Map<String, Object>> getCertificateData(
            @PathVariable Long courseId,
            HttpServletRequest request) {
        Long userId = getUserId(request);
        return R.ok(courseService.getCertificateData(userId, courseId));
    }

    private Long getUserId(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId != null && !userId.isEmpty()) {
            return Long.parseLong(userId);
        }
        throw new RuntimeException("请先登录");
    }
}
