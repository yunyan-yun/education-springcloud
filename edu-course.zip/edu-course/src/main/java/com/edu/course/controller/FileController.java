package com.edu.course.controller;

import cn.hutool.core.date.DateUtil;
import com.edu.common.result.R;
import com.edu.course.config.MinioConfig;
import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.SetBucketPolicyArgs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.UUID;

/**
 * 文件上传控制器 - MinIO 对象存储
 */
@RestController
@RequestMapping("/course/file")
public class FileController {

    @Autowired
    private MinioClient minioClient;

    @Autowired
    private MinioConfig minioConfig;

    // 上传前缀配置
    private static final String PREFIX_AVATAR  = "avatar/";   // 用户头像
    private static final String PREFIX_TEACHER = "teacher/";  // 讲师头像
    private static final String PREFIX_COVER   = "cover/";    // 课程封面
    private static final String PREFIX_BANNER  = "banner/";   // 轮播图
    private static final String PREFIX_VIDEO   = "video/";    // 课程视频

    /**
     * 生成文件名（带日期和唯一标识）
     */
    private String generateFileName(String prefix, String originalFilename) {
        String suffix = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            suffix = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        return prefix + DateUtil.format(new Date(), "yyyyMMdd") + "/" + UUID.randomUUID().toString().replace("-", "") + suffix;
    }

    /**
     * 确保 Bucket 存在，不存在则自动创建并设为公开读
     */
    private void ensureBucketExists() throws Exception {
        String bucketName = minioConfig.getBucketName();
        boolean exists = minioClient.bucketExists(
                BucketExistsArgs.builder().bucket(bucketName).build()
        );
        if (!exists) {
            // 创建 Bucket
            minioClient.makeBucket(
                    MakeBucketArgs.builder().bucket(bucketName).build()
            );
            // 设置为公开读策略（Anonymous 用户只有 READ 权限）
            String policyJson = String.format("""
                {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Effect": "Allow",
                            "Principal": {"AWS": "*"},
                            "Action": "s3:GetObject",
                            "Resource": "arn:aws:s3:::%s/*"
                        }
                    ]
                }
                """, bucketName);
            minioClient.setBucketPolicy(
                    SetBucketPolicyArgs.builder().bucket(bucketName).config(policyJson).build()
            );
            System.out.println("Bucket [" + bucketName + "] 已自动创建并设为公开读");
        }
    }

    /**
     * 上传到 MinIO 并返回访问 URL
     */
    private String uploadToMinio(String objectName, MultipartFile file) throws Exception {
        // 确保 Bucket 存在
        ensureBucketExists();

        minioClient.putObject(
                PutObjectArgs.builder()
                        .bucket(minioConfig.getBucketName())
                        .object(objectName)
                        .stream(file.getInputStream(), file.getSize(), -1)
                        .contentType(file.getContentType())
                        .build()
        );
        return minioConfig.getPublicUrlPrefix() + "/" + objectName;
    }

    /**
     * 用户头像上传
     * POST /course/file/upload/avatar
     */
    @PostMapping("/upload/avatar")
    public R<String> uploadAvatar(@RequestParam("file") MultipartFile file) {
        try {
            String objectName = generateFileName(PREFIX_AVATAR, file.getOriginalFilename());
            String url = uploadToMinio(objectName, file);
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("上传失败: " + e.getMessage());
        }
    }

    /**
     * 讲师头像上传
     * POST /course/file/upload/teacher
     */
    @PostMapping("/upload/teacher")
    public R<String> uploadTeacher(@RequestParam("file") MultipartFile file) {
        try {
            String objectName = generateFileName(PREFIX_TEACHER, file.getOriginalFilename());
            String url = uploadToMinio(objectName, file);
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("上传失败: " + e.getMessage());
        }
    }

    /**
     * 课程封面上传
     * POST /course/file/upload/cover
     */
    @PostMapping("/upload/cover")
    public R<String> uploadCover(@RequestParam("file") MultipartFile file) {
        try {
            String objectName = generateFileName(PREFIX_COVER, file.getOriginalFilename());
            String url = uploadToMinio(objectName, file);
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("上传失败: " + e.getMessage());
        }
    }

    /**
     * 轮播图上传
     * POST /course/file/upload/banner
     */
    @PostMapping("/upload/banner")
    public R<String> uploadBanner(@RequestParam("file") MultipartFile file) {
        try {
            String objectName = generateFileName(PREFIX_BANNER, file.getOriginalFilename());
            String url = uploadToMinio(objectName, file);
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("上传失败: " + e.getMessage());
        }
    }

    /**
     * 课程视频上传
     * POST /course/file/upload/video
     */
    @PostMapping("/upload/video")
    public R<String> uploadVideo(@RequestParam("file") MultipartFile file) {
        try {
            String objectName = generateFileName(PREFIX_VIDEO, file.getOriginalFilename());
            String url = uploadToMinio(objectName, file);
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("上传失败: " + e.getMessage());
        }
    }

    /**
     * 获取文件访问URL（公开访问）
     * GET /course/file/url/{filename}
     */
    @GetMapping("/url/{filename:.+}")
    public R<String> getFileAccessUrl(@PathVariable String filename) {
        try {
            String url = minioConfig.getPublicUrlPrefix() + "/" + filename;
            return R.ok(url);
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail("获取文件URL失败: " + e.getMessage());
        }
    }
}
