package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.Note;
import com.edu.course.mapper.NoteMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/course/note")
public class NoteController {

    @Autowired
    private NoteMapper noteMapper;

    private Long getUserId(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId != null && !userId.isEmpty()) {
            return Long.parseLong(userId);
        }
        throw new RuntimeException("请先登录");
    }

    /**
     * 获取当前视频的笔记列表
     */
    @GetMapping("/video/{videoId}")
    public R<List<Note>> listByVideo(@PathVariable Long videoId, HttpServletRequest request) {
        Long memberId = getUserId(request);
        LambdaQueryWrapper<Note> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Note::getMemberId, memberId)
               .eq(Note::getVideoId, videoId)
               .orderByDesc(Note::getCreateTime);
        List<Note> notes = noteMapper.selectList(wrapper);
        return R.ok(notes);
    }

    /**
     * 新增笔记
     */
    @PostMapping
    public R<Note> add(@RequestBody Map<String, Object> params, HttpServletRequest request) {
        Long memberId = getUserId(request);
        Long videoId = Long.parseLong(params.get("videoId").toString());
        Long courseId = params.get("courseId") != null ? Long.parseLong(params.get("courseId").toString()) : null;
        Long chapterId = params.get("chapterId") != null ? Long.parseLong(params.get("chapterId").toString()) : null;
        String content = params.get("content") != null ? params.get("content").toString() : "";

        if (content.trim().isEmpty()) {
            return R.fail(400, "笔记内容不能为空");
        }

        Note note = new Note();
        note.setMemberId(memberId);
        note.setVideoId(videoId);
        note.setCourseId(courseId);
        note.setChapterId(chapterId);
        note.setContent(content.trim());
        noteMapper.insert(note);
        return R.ok(note);
    }

    /**
     * 编辑笔记
     */
    @PutMapping("/{id}")
    public R<Void> update(@PathVariable Long id, @RequestBody Map<String, Object> params, HttpServletRequest request) {
        Long memberId = getUserId(request);
        String content = params.get("content") != null ? params.get("content").toString() : "";

        if (content.trim().isEmpty()) {
            return R.fail(400, "笔记内容不能为空");
        }

        Note note = noteMapper.selectById(id);
        if (note == null || !note.getMemberId().equals(memberId)) {
            return R.fail(403, "笔记不存在或无权修改");
        }

        note.setContent(content.trim());
        noteMapper.updateById(note);
        return R.ok();
    }

    /**
     * 删除笔记
     */
    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id, HttpServletRequest request) {
        Long memberId = getUserId(request);

        Note note = noteMapper.selectById(id);
        if (note == null || !note.getMemberId().equals(memberId)) {
            return R.fail(403, "笔记不存在或无权删除");
        }

        noteMapper.deleteById(id);
        return R.ok();
    }
}
