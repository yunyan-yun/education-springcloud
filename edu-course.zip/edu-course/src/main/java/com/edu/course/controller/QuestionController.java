package com.edu.course.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.edu.common.result.R;
import com.edu.course.entity.AnswerRecord;
import com.edu.course.entity.Question;
import com.edu.course.mapper.AnswerRecordMapper;
import com.edu.course.mapper.QuestionMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/course/question")
public class QuestionController {

    @Autowired
    private QuestionMapper questionMapper;

    @Autowired
    private AnswerRecordMapper answerRecordMapper;

    private Long getUserId(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId != null && !userId.isEmpty()) {
            return Long.parseLong(userId);
        }
        throw new RuntimeException("请先登录");
    }

    /**
     * 获取视频测验题（同时返回用户答题记录）
     */
    @GetMapping("/video/{videoId}")
    public R<List<Map<String, Object>>> getByVideo(@PathVariable Long videoId, HttpServletRequest request) {
        Long memberId = getUserId(request);

        LambdaQueryWrapper<Question> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Question::getVideoId, videoId)
               .eq(Question::getIsDeleted, 0)
               .orderByAsc(Question::getSort);
        List<Question> questions = questionMapper.selectList(wrapper);

        if (questions.isEmpty()) {
            return R.ok(new ArrayList<>());
        }

        List<Long> questionIds = questions.stream().map(Question::getId).collect(Collectors.toList());

        // 获取用户答题记录
        LambdaQueryWrapper<AnswerRecord> recordWrapper = new LambdaQueryWrapper<>();
        recordWrapper.eq(AnswerRecord::getMemberId, memberId)
                     .in(AnswerRecord::getQuestionId, questionIds);
        List<AnswerRecord> records = answerRecordMapper.selectList(recordWrapper);
        Map<Long, AnswerRecord> recordMap = records.stream()
                .collect(Collectors.toMap(AnswerRecord::getQuestionId, r -> r, (a, b) -> a));

        List<Map<String, Object>> result = new ArrayList<>();
        for (Question q : questions) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", q.getId());
            item.put("content", q.getContent());
            item.put("optionA", q.getOptionA());
            item.put("optionB", q.getOptionB());
            item.put("optionC", q.getOptionC());
            item.put("optionD", q.getOptionD());
            item.put("analysis", q.getAnalysis());

            AnswerRecord record = recordMap.get(q.getId());
            if (record != null) {
                item.put("userAnswer", record.getUserAnswer());
                item.put("isCorrect", record.getIsCorrect());
                item.put("answered", true);
            } else {
                item.put("answered", false);
            }

            // 前端不需要正确答案，提交后才显示
            result.add(item);
        }

        return R.ok(result);
    }

    /**
     * 提交答案
     */
    @PostMapping("/submit")
    public R<Map<String, Object>> submit(@RequestBody Map<String, Object> params, HttpServletRequest request) {
        Long memberId = getUserId(request);
        Long questionId = Long.parseLong(params.get("questionId").toString());
        String userAnswer = params.get("userAnswer") != null ? params.get("userAnswer").toString().toUpperCase() : "";

        if (userAnswer.isEmpty() || userAnswer.length() != 1) {
            return R.fail(400, "请选择答案");
        }

        Question question = questionMapper.selectById(questionId);
        if (question == null) {
            return R.fail(404, "题目不存在");
        }

        boolean isCorrect = userAnswer.equals(question.getAnswer());

        // 查找已有记录
        LambdaQueryWrapper<AnswerRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AnswerRecord::getMemberId, memberId)
               .eq(AnswerRecord::getQuestionId, questionId);
        AnswerRecord existRecord = answerRecordMapper.selectOne(wrapper);

        if (existRecord != null) {
            // 更新已有记录
            existRecord.setUserAnswer(userAnswer);
            existRecord.setIsCorrect(isCorrect ? 1 : 0);
            answerRecordMapper.updateById(existRecord);
        } else {
            // 新增记录
            AnswerRecord record = new AnswerRecord();
            record.setMemberId(memberId);
            record.setQuestionId(questionId);
            record.setUserAnswer(userAnswer);
            record.setIsCorrect(isCorrect ? 1 : 0);
            answerRecordMapper.insert(record);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("isCorrect", isCorrect);
        result.put("correctAnswer", question.getAnswer());
        result.put("analysis", question.getAnalysis());
        return R.ok(result);
    }

    /**
     * 批量查询用户在各视频的测验通过状态
     * 返回 Map<videoId, passed(Boolean)>
     * 通过条件：该视频所有题目都已作答且正确率 >= 60%
     */
    @GetMapping("/quiz-passed/{courseId}")
    public R<Map<Long, Boolean>> getQuizPassedStatus(@PathVariable Long courseId, HttpServletRequest request) {
        Long memberId = getUserId(request);

        // 查询该课程所有题目（未删除）
        LambdaQueryWrapper<Question> qWrapper = new LambdaQueryWrapper<>();
        qWrapper.eq(Question::getCourseId, courseId)
                .eq(Question::getIsDeleted, 0);
        List<Question> questions = questionMapper.selectList(qWrapper);

        // 按视频ID分组
        Map<Long, List<Question>> videoQuestionMap = questions.stream()
                .collect(Collectors.groupingBy(Question::getVideoId));

        // 获取用户在所有相关题目上的答题记录
        List<Long> allQuestionIds = questions.stream().map(Question::getId).collect(Collectors.toList());
        Map<Long, Boolean> result = new HashMap<>();

        if (allQuestionIds.isEmpty()) {
            return R.ok(result);
        }

        LambdaQueryWrapper<AnswerRecord> rWrapper = new LambdaQueryWrapper<>();
        rWrapper.eq(AnswerRecord::getMemberId, memberId)
                .in(AnswerRecord::getQuestionId, allQuestionIds);
        List<AnswerRecord> records = answerRecordMapper.selectList(rWrapper);
        Map<Long, AnswerRecord> recordMap = records.stream()
                .collect(Collectors.toMap(AnswerRecord::getQuestionId, r -> r, (a, b) -> a));

        // 逐视频判定
        for (Map.Entry<Long, List<Question>> entry : videoQuestionMap.entrySet()) {
            Long videoId = entry.getKey();
            List<Question> videoQuestions = entry.getValue();
            int total = videoQuestions.size();
            int answered = 0;
            int correct = 0;
            for (Question q : videoQuestions) {
                AnswerRecord record = recordMap.get(q.getId());
                if (record != null) {
                    answered++;
                    if (record.getIsCorrect() != null && record.getIsCorrect() == 1) {
                        correct++;
                    }
                }
            }
            // 所有题目都已答且正确率>=60%才算通过
            boolean passed = answered == total && total > 0 && (correct * 100.0 / total) >= 60;
            result.put(videoId, passed);
        }

        return R.ok(result);
    }

    /**
     * 获取课程测验统计
     */
    @GetMapping("/stats/{courseId}")
    public R<Map<String, Object>> getStats(@PathVariable Long courseId, HttpServletRequest request) {
        Long memberId = getUserId(request);

        // 该课程所有题目
        LambdaQueryWrapper<Question> qWrapper = new LambdaQueryWrapper<>();
        qWrapper.eq(Question::getCourseId, courseId)
                .eq(Question::getIsDeleted, 0);
        long totalQuestions = questionMapper.selectCount(qWrapper);

        // 该用户在该课程的答题记录
        List<Question> questions = questionMapper.selectList(qWrapper);
        if (questions.isEmpty()) {
            Map<String, Object> empty = new HashMap<>();
            empty.put("totalQuestions", 0);
            empty.put("answeredCount", 0);
            empty.put("correctCount", 0);
            empty.put("accuracy", 0);
            return R.ok(empty);
        }

        List<Long> questionIds = questions.stream().map(Question::getId).collect(Collectors.toList());
        LambdaQueryWrapper<AnswerRecord> rWrapper = new LambdaQueryWrapper<>();
        rWrapper.eq(AnswerRecord::getMemberId, memberId)
                .in(AnswerRecord::getQuestionId, questionIds);
        List<AnswerRecord> records = answerRecordMapper.selectList(rWrapper);

        long answeredCount = records.size();
        long correctCount = records.stream().filter(r -> r.getIsCorrect() == 1).count();
        double accuracy = answeredCount > 0 ? Math.round(correctCount * 100.0 / answeredCount) : 0;

        Map<String, Object> result = new HashMap<>();
        result.put("totalQuestions", totalQuestions);
        result.put("answeredCount", answeredCount);
        result.put("correctCount", correctCount);
        result.put("accuracy", accuracy);
        return R.ok(result);
    }
}
