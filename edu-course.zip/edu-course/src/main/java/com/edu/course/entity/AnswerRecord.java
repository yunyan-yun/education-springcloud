package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_answer_record")
public class AnswerRecord {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long memberId;
    private Long questionId;
    private String userAnswer;
    private Integer isCorrect;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    private Integer isDeleted;
}
