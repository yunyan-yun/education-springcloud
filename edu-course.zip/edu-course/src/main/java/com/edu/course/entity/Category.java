package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("edu_category")
public class Category {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private String icon;
    private Long parentId;
    private Integer sort;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    // 已移除 @TableLogic 注解，支持物理删除
    private Integer isDeleted;
    
    // 用于树形结构，非数据库字段
    @TableField(exist = false)
    private List<Category> children;
}
