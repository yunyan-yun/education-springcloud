package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_comment")
public class Comment {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long courseId;
    private Long memberId;
    private String memberNickname;
    private String memberAvatar;
    private String content;
    private Integer score;
    private String courseName;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    private Integer isDeleted;
}
