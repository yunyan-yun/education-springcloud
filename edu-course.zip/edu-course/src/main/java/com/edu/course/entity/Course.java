package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("edu_course")
public class Course {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String title;
    private String subTitle;
    private String cover;
    private BigDecimal price;
    private BigDecimal originalPrice;
    private Long teacherId;
    private String teacherName;
    private Long categoryId;
    private String categoryName;
    private String description;
    private String detail;
    private Integer studyCount;
    private Integer commentCount;
    private BigDecimal score;
    private Integer duration;
    private Integer chapterCount;
    private Integer status;
    private Integer isFree;
    private Integer isRecommend;
    private Integer isHot;
    private Integer sort;
    @TableField(exist = false)
    private Boolean isPurchased;  // 非数据库字段，用于判断是否已购买

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
