package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_favorite")
public class Favorite {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long memberId;
    private Long courseId;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    private Integer isDeleted;
}
