package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_note")
public class Note {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long memberId;
    private Long courseId;
    private Long chapterId;
    private Long videoId;
    private String content;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
