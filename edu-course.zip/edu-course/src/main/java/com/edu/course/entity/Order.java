package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 课程服务专用的订单实体（只读，用于查询已购课程）
 */
@Data
@TableName("edu_order")
public class Order {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String orderNo;
    private Long memberId;
    private Long courseId;
    private String courseTitle;
    private String courseCover;
    private String teacherName;
    private BigDecimal totalAmount;
    private Integer status;
    private String payType;
    private String tradeNo;
    private LocalDateTime payTime;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    @TableLogic
    private Integer isDeleted;
}
