package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_study_progress")
public class StudyProgress {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long memberId;
    private Long courseId;
    private Long videoId;
    private Integer watchTime;    // 已观看时长（秒）
    private Integer totalTime;    // 视频总时长（秒）
    private Integer finished;      // 是否看完 0否 1是
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
