package com.edu.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_teacher")
public class Teacher {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private String avatar;
    private String intro;
    private String career;
    private Integer sort;
    private Integer status;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    // 已移除 @TableLogic 注解，标记为非数据库字段
    @TableField(exist = false)
    private Integer isDeleted;
}
