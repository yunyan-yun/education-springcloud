package com.edu.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.Category;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CategoryMapper extends BaseMapper<Category> {
    // 物理删除（绕过 @TableLogic 逻辑删除）
    int physicalDeleteById(@Param("id") Long id);

    // 物理删除子分类
    int physicalDeleteByParentId(@Param("parentId") Long parentId);
}
