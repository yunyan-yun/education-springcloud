package com.edu.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

    @Select("SELECT c.*, cu.title as course_name " +
            "FROM edu_comment c " +
            "LEFT JOIN edu_course cu ON c.course_id = cu.id " +
            "WHERE c.is_deleted = 0 " +
            "AND (#{keyword} IS NULL OR c.content LIKE CONCAT('%', #{keyword}, '%') OR cu.title LIKE CONCAT('%', #{keyword}, '%')) " +
            "AND (#{score} IS NULL OR c.score = #{score}) " +
            "AND (#{courseId} IS NULL OR c.course_id = #{courseId}) " +
            "ORDER BY c.create_time DESC " +
            "LIMIT #{offset}, #{size}")
    List<Comment> selectCommentPageListWithJoin(@Param("keyword") String keyword, @Param("score") Integer score, @Param("courseId") Long courseId, @Param("offset") Long offset, @Param("size") Long size);

    @Select("SELECT COUNT(*) " +
            "FROM edu_comment c " +
            "LEFT JOIN edu_course cu ON c.course_id = cu.id " +
            "WHERE c.is_deleted = 0 " +
            "AND (#{keyword} IS NULL OR c.content LIKE CONCAT('%', #{keyword}, '%') OR cu.title LIKE CONCAT('%', #{keyword}, '%')) " +
            "AND (#{score} IS NULL OR c.score = #{score}) " +
            "AND (#{courseId} IS NULL OR c.course_id = #{courseId})")
    long selectCommentPageCountWithJoin(@Param("keyword") String keyword, @Param("score") Integer score, @Param("courseId") Long courseId);
}
