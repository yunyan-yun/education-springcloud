package com.edu.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.Course;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface CourseMapper extends BaseMapper<Course> {
    
    /**
     * 物理删除课程（绕过 @TableLogic）
     */
    @Delete("DELETE FROM edu_course WHERE id = #{id}")
    int physicalDeleteById(@Param("id") Long id);
}
