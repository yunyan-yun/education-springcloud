package com.edu.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface FavoriteMapper extends BaseMapper<Favorite> {

    /**
     * 查询收藏记录（包含已软删除的）
     */
    @Select("SELECT * FROM edu_favorite WHERE member_id = #{memberId} AND course_id = #{courseId} LIMIT 1")
    Favorite selectWithDeleted(@Param("memberId") Long memberId, @Param("courseId") Long courseId);

    /**
     * 恢复已软删除的收藏（重新收藏）
     */
    @Update("UPDATE edu_favorite SET is_deleted = 0 WHERE member_id = #{memberId} AND course_id = #{courseId}")
    int restoreFavorite(@Param("memberId") Long memberId, @Param("courseId") Long courseId);

    /**
     * 物理删除收藏记录（真正删除，避免唯一键重复插入问题）
     */
    @Update("UPDATE edu_favorite SET is_deleted = 1 WHERE member_id = #{memberId} AND course_id = #{courseId}")
    int softDeleteFavorite(@Param("memberId") Long memberId, @Param("courseId") Long courseId);
}
