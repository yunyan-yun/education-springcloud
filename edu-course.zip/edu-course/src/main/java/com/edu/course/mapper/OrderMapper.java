package com.edu.course.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.Order;
import org.apache.ibatis.annotations.Mapper;

/**
 * 课程服务专用的订单Mapper（只读，用于查询已购课程）
 * 连接到 edu_order 数据库
 */
@Mapper
@DS("order")
public interface OrderMapper extends BaseMapper<Order> {
}
