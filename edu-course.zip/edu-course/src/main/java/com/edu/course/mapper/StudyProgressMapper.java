package com.edu.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.course.entity.StudyProgress;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface StudyProgressMapper extends BaseMapper<StudyProgress> {
}
