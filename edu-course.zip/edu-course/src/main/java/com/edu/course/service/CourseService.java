package com.edu.course.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.edu.course.entity.*;
import com.edu.course.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CourseService extends ServiceImpl<CourseMapper, Course> {

    @Autowired private CourseMapper courseMapper;
    @Autowired private ChapterMapper chapterMapper;
    @Autowired private VideoMapper videoMapper;
    @Autowired private CategoryMapper categoryMapper;
    @Autowired private TeacherMapper teacherMapper;
    @Autowired private BannerMapper bannerMapper;
    @Autowired private OrderMapper orderMapper;
    @Autowired private CommentMapper commentMapper;
    @Autowired private StudyProgressMapper studyProgressMapper;
    @Autowired private FavoriteMapper favoriteMapper;
    @Autowired private RestTemplate restTemplate;

    public List<Banner> getBanners() {
        LambdaQueryWrapper<Banner> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Banner::getStatus, 1).orderByAsc(Banner::getSort);
        return bannerMapper.selectList(wrapper);
    }

    public List<Category> getCategories() {
        LambdaQueryWrapper<Category> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByAsc(Category::getSort);
        return categoryMapper.selectList(wrapper);
    }

    public List<Course> getRecommendCourses() {
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Course::getStatus, 1).eq(Course::getIsRecommend, 1)
               .orderByDesc(Course::getCreateTime).last("LIMIT 8");
        List<Course> courses = courseMapper.selectList(wrapper);
        enrichCoursesWithStats(courses);
        return courses;
    }

    public List<Course> getHotCourses() {
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Course::getStatus, 1).eq(Course::getIsHot, 1)
               .orderByDesc(Course::getCreateTime).last("LIMIT 8");
        List<Course> courses = courseMapper.selectList(wrapper);
        enrichCoursesWithStats(courses);
        return courses;
    }

    public List<Course> getLatestCourses() {
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Course::getStatus, 1).orderByDesc(Course::getCreateTime).last("LIMIT 8");
        List<Course> courses = courseMapper.selectList(wrapper);
        enrichCoursesWithStats(courses);
        return courses;
    }

    public Map<String, Object> searchCourses(String keyword, Long categoryId, Integer isFree,
                                             String sortBy, Integer current, Integer size) {
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Course::getStatus, 1);

        if (keyword != null && !keyword.isEmpty()) {
            wrapper.and(w -> w.like(Course::getTitle, keyword)
                           .or().like(Course::getDescription, keyword));
        }
        if (categoryId != null) {
            // 判断传入的分类ID是一级分类还是二级分类
            Category parentCategory = categoryMapper.selectById(categoryId);
            if (parentCategory != null && parentCategory.getParentId() != null && parentCategory.getParentId() == 0) {
                // 是一级分类：查询所有子分类的ID
                LambdaQueryWrapper<Category> catWrapper = new LambdaQueryWrapper<>();
                catWrapper.eq(Category::getParentId, categoryId);
                List<Category> childCategories = categoryMapper.selectList(catWrapper);
                if (!childCategories.isEmpty()) {
                    List<Long> childIds = childCategories.stream()
                            .map(Category::getId)
                            .collect(Collectors.toList());
                    wrapper.in(Course::getCategoryId, childIds);
                } else {
                    // 一级分类下没有子分类，返回空结果
                    Map<String, Object> emptyResult = new HashMap<>();
                    emptyResult.put("records", Collections.emptyList());
                    emptyResult.put("total", 0L);
                    return emptyResult;
                }
            } else {
                // 是二级分类：直接按categoryId精确查询
                wrapper.eq(Course::getCategoryId, categoryId);
            }
        }
        if (isFree != null) {
            wrapper.eq(Course::getIsFree, isFree);
        }

        switch (sortBy != null ? sortBy : "") {
            case "latest", "newest" -> wrapper.orderByDesc(Course::getCreateTime);
            case "hot", "hottest" -> wrapper.orderByDesc(Course::getStudyCount);
            case "price_asc" -> wrapper.orderByAsc(Course::getPrice);
            case "price_desc" -> wrapper.orderByDesc(Course::getPrice);
            default -> wrapper.orderByDesc(Course::getSort, Course::getCreateTime);
        }

        Page<Course> page = new Page<>(current != null ? current : 1, size != null ? size : 12);
        Page<Course> result = courseMapper.selectPage(page, wrapper);

        // 实时统计每个课程的实际学习人数和评分
        enrichCoursesWithStats(result.getRecords());

        Map<String, Object> data = new HashMap<>();
        data.put("records", result.getRecords());
        data.put("total", result.getTotal());
        return data;
    }

    /**
     * 获取课程的真实学习人数（基于学习记录）
     */
    public Long getRealStudyCount(Long courseId) {
        LambdaQueryWrapper<StudyProgress> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StudyProgress::getCourseId, courseId);
        // 统计去重的学习用户数
        List<StudyProgress> progressList = studyProgressMapper.selectList(wrapper);
        return progressList.stream()
                .map(StudyProgress::getMemberId)
                .filter(Objects::nonNull)
                .distinct()
                .count();
    }

    /**
     * 获取课程的真实评分和评论数
     */
    public Map<String, Object> getRealScoreInfo(Long courseId) {
        Map<String, Object> result = new HashMap<>();
        LambdaQueryWrapper<Comment> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Comment::getCourseId, courseId);
        List<Comment> comments = commentMapper.selectList(wrapper);

        if (comments.isEmpty()) {
            result.put("avgScore", 0.0); // 默认0分
            result.put("count", 0);
        } else {
            double avgScore = comments.stream()
                    .mapToInt(Comment::getScore)
                    .average()
                    .orElse(5.0);
            result.put("avgScore", avgScore);
            result.put("count", comments.size());
        }
        return result;
    }

    /**
     * 批量更新课程列表的学习人数和评分（实时统计）
     */
    public void enrichCoursesWithStats(List<Course> courses) {
        if (courses == null || courses.isEmpty()) return;
        for (Course course : courses) {
            // 实时获取真实学习人数
            Long realCount = getRealStudyCount(course.getId());
            course.setStudyCount(realCount != null ? realCount.intValue() : 0);
            // 实时获取评分和评论数
            Map<String, Object> scoreInfo = getRealScoreInfo(course.getId());
            course.setScore(new BigDecimal(scoreInfo.get("avgScore").toString()).setScale(1, java.math.RoundingMode.HALF_UP));
            course.setCommentCount(((Number) scoreInfo.get("count")).intValue());
            // 实时获取讲师名称（避免课程表冗余字段过期）
            Teacher teacher = teacherMapper.selectById(course.getTeacherId());
            if (teacher != null) {
                course.setTeacherName(teacher.getName());
            }
        }
    }

    public Map<String, Object> getCourseDetail(Long id, Long userId) {
        Course course = courseMapper.selectById(id);
        if (course == null || course.getStatus() != 1) {
            throw new RuntimeException("课程不存在");
        }

        // 实时获取真实学习人数
        Long realCount = getRealStudyCount(id);
        course.setStudyCount(realCount != null ? realCount.intValue() : 0);

        // 实时获取评分和评论数
        Map<String, Object> scoreInfo = getRealScoreInfo(id);
        course.setScore(new BigDecimal(scoreInfo.get("avgScore").toString()).setScale(1, java.math.RoundingMode.HALF_UP));
        course.setCommentCount(((Number) scoreInfo.get("count")).intValue());

        // 获取讲师
        Teacher teacher = teacherMapper.selectById(course.getTeacherId());

        // 实时更新课程的讲师名称（避免课程表冗余字段过期）
        if (teacher != null) {
            course.setTeacherName(teacher.getName());
        }

        // 获取章节和视频
        LambdaQueryWrapper<Chapter> cw = new LambdaQueryWrapper<>();
        cw.eq(Chapter::getCourseId, id).orderByAsc(Chapter::getSort);
        List<Chapter> chapters = chapterMapper.selectList(cw);

        // 实时计算章节数和总课时
        int chapterCount = chapters.size();
        int totalDuration = 0;
        for (Chapter chapter : chapters) {
            LambdaQueryWrapper<Video> vw = new LambdaQueryWrapper<>();
            vw.eq(Video::getChapterId, chapter.getId()).orderByAsc(Video::getSort);
            List<Video> videos = videoMapper.selectList(vw);
            chapter.setVideos(videos);
            // 累加课时时长
            for (Video video : videos) {
                if (video.getDuration() != null) {
                    totalDuration += video.getDuration();
                }
            }
        }

        // 更新课程对象的章节数和课时时长
        course.setChapterCount(chapterCount);
        course.setDuration(totalDuration);

        // 判断是否已购买
        boolean isPurchased = false;
        if (userId != null) {
            LambdaQueryWrapper<Order> ow = new LambdaQueryWrapper<>();
            ow.eq(Order::getMemberId, userId)
              .eq(Order::getCourseId, id)
              .eq(Order::getStatus, 1);
            long count = orderMapper.selectCount(ow);
            isPurchased = count > 0;
            System.out.println("=== isPurchased check ===");
            System.out.println("userId: " + userId);
            System.out.println("courseId: " + id);
            System.out.println("order count: " + count);
            System.out.println("========================");
        }

        Map<String, Object> data = new HashMap<>();
        course.setIsPurchased(isPurchased);
        data.put("course", course);
        data.put("teacher", teacher);
        data.put("chapters", chapters);
        return data;
    }

    public String getPlayUrl(Long videoId, Long userId) {
        Video video = videoMapper.selectById(videoId);
        if (video == null) {
            throw new RuntimeException("视频不存在");
        }

        // 如果该视频不是免费的，需要校验用户是否已购买课程
        if (video.getIsFree() == null || video.getIsFree() != 1) {
            // 用户未登录，直接拒绝
            if (userId == null) {
                throw new RuntimeException("请先登录后购买课程才能观看付费视频");
            }
            // 查询用户是否已购买该视频所属的课程
            LambdaQueryWrapper<Order> ow = new LambdaQueryWrapper<>();
            ow.eq(Order::getMemberId, userId)
              .eq(Order::getCourseId, video.getCourseId())
              .eq(Order::getStatus, 1); // 1 = 已支付
            long count = orderMapper.selectCount(ow);
            if (count == 0) {
                throw new RuntimeException("请先购买该课程才能观看付费视频");
            }
        }

        // 检查视频URL是否为空
        if (video.getVideoUrl() == null || video.getVideoUrl().trim().isEmpty()) {
            throw new RuntimeException("视频尚未上传，请联系管理员");
        }
        return video.getVideoUrl();
    }

    /**
     * 获取用户已购课程
     */
    public List<Map<String, Object>> getPurchasedCourses(Long userId) {
        // 查询用户已支付订单中的课程ID
        LambdaQueryWrapper<Order> ow = new LambdaQueryWrapper<>();
        ow.eq(Order::getMemberId, userId)
          .eq(Order::getStatus, 1) // 已支付
          .select(Order::getCourseId);
        List<Order> orders = orderMapper.selectList(ow);
        
        if (orders.isEmpty()) {
            return new ArrayList<>();
        }
        
        // 获取课程ID列表
        List<Long> courseIds = orders.stream()
            .map(Order::getCourseId)
            .distinct()
            .collect(Collectors.toList());
        
        // 查询课程详情
        LambdaQueryWrapper<Course> cw = new LambdaQueryWrapper<>();
        cw.in(Course::getId, courseIds).eq(Course::getStatus, 1);
        List<Course> courses = courseMapper.selectList(cw);

        // 实时更新学习人数和评分
        enrichCoursesWithStats(courses);

        // 封装结果
        List<Map<String, Object>> result = new ArrayList<>();
        for (Course course : courses) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", course.getId());
            item.put("title", course.getTitle());
            item.put("cover", course.getCover());
            item.put("price", course.getPrice());
            item.put("teacherName", course.getTeacherName());
            item.put("description", course.getDescription());
            item.put("studyCount", course.getStudyCount());
            item.put("score", course.getScore());
            // 查找对应的订单信息
            Order order = orders.stream()
                .filter(o -> o.getCourseId().equals(course.getId()))
                .findFirst()
                .orElse(null);
            if (order != null) {
                item.put("payTime", order.getPayTime());
            }
            result.add(item);
        }
        return result;
    }

    /**
     * 获取课程评论列表
     */
    public Map<String, Object> getComments(Long courseId, Integer current, Integer size) {
        LambdaQueryWrapper<Comment> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Comment::getCourseId, courseId)
               .orderByDesc(Comment::getCreateTime);

        Page<Comment> page = new Page<>(current != null ? current : 1, size != null ? size : 10);
        Page<Comment> result = commentMapper.selectPage(page, wrapper);

        // 同步用户最新头像
        List<Comment> records = result.getRecords();
        if (!records.isEmpty()) {
            // 获取所有评论者的ID
            Set<Long> memberIds = records.stream()
                    .map(Comment::getMemberId)
                    .filter(id -> id != null)
                    .collect(Collectors.toSet());

            // 从用户服务获取最新头像（通过Feign调用）
            if (!memberIds.isEmpty()) {
                for (Comment comment : records) {
                    if (comment.getMemberId() != null) {
                        String latestAvatar = getMemberAvatar(comment.getMemberId());
                        if (latestAvatar != null && !latestAvatar.isEmpty()) {
                            comment.setMemberAvatar(latestAvatar);
                        }
                    }
                }
            }
        }

        Map<String, Object> data = new HashMap<>();
        data.put("records", records);
        data.put("total", result.getTotal());
        return data;
    }

    /**
     * 从用户服务获取会员头像
     */
    private String getMemberAvatar(Long memberId) {
        try {
            // 通过 RestTemplate 调用用户服务
            String url = "http://edu-user/user/member/avatar/" + memberId;
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> body = response.getBody();
                // code 可能是 Integer 或 String，需要兼容处理
                Object codeObj = body.get("code");
                boolean success = (codeObj != null && (codeObj.toString().equals("200") || codeObj.toString().equals("0")))
                              || Boolean.TRUE.equals(body.get("success"));
                if (success) {
                    Object data = body.get("data");
                    if (data != null && !data.toString().isEmpty()) {
                        return data.toString();
                    }
                }
            }
        } catch (Exception e) {
            // 忽略错误，使用评论表中的头像
        }
        return null;
    }

    /**
     * 添加评论
     */
    public Comment addComment(Long courseId, Long memberId, String memberNickname,
                             String memberAvatar, String content, Integer score) {
        Comment comment = new Comment();
        comment.setCourseId(courseId);
        comment.setMemberId(memberId);
        comment.setMemberNickname(memberNickname);
        // 头像只存URL，不存Base64（Base64太大会导致数据库截断错误）
        // 如果是有效URL则存储，否则生成基于昵称的默认头像
        if (memberAvatar != null && !memberAvatar.isEmpty() && !memberAvatar.startsWith("data:")) {
            comment.setMemberAvatar(memberAvatar);
        } else {
            // 生成默认头像（基于昵称）
            String nicknameForAvatar = (memberNickname != null && !memberNickname.isEmpty()) ? memberNickname : "用户";
            comment.setMemberAvatar("https://api.dicebear.com/7.x/initials/svg?seed=" + nicknameForAvatar);
        }
        comment.setContent(content);
        comment.setScore(score);

        // 保存课程名称（冗余存储，方便后台查询）
        Course course = courseMapper.selectById(courseId);
        if (course != null) {
            comment.setCourseName(course.getTitle());
        }

        commentMapper.insert(comment);

        // 注意：评分现在是实时计算的，无需更新数据库中的冗余字段
        return comment;
    }

    /**
     * 记录学习进度
     */
    public void recordProgress(Long userId, Long videoId, Integer watchTime, boolean forceFinished) {
        // 获取视频信息
        Video video = videoMapper.selectById(videoId);
        if (video == null) {
            throw new RuntimeException("视频不存在");
        }

        // 查询是否已有进度记录
        LambdaQueryWrapper<StudyProgress> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StudyProgress::getMemberId, userId)
               .eq(StudyProgress::getVideoId, videoId);
        StudyProgress progress = studyProgressMapper.selectOne(wrapper);

        int totalTime = video.getDuration() != null ? video.getDuration().intValue() : 0;

        // 判断是否应该标记为已完成
        boolean shouldFinish = forceFinished
                || (totalTime <= 0 && watchTime > 0)
                || (totalTime > 0 && watchTime >= totalTime * 0.8);

        if (progress == null) {
            // 新增记录
            progress = new StudyProgress();
            progress.setMemberId(userId);
            progress.setCourseId(video.getCourseId());
            progress.setVideoId(videoId);
            progress.setWatchTime(watchTime);
            progress.setTotalTime(totalTime);
            progress.setFinished(shouldFinish ? 1 : 0);
            studyProgressMapper.insert(progress);
        } else {
            // 更新记录：watchTime取最大值，但每次都更新update_time以触发打卡
            progress.setWatchTime(Math.max(watchTime, progress.getWatchTime() != null ? progress.getWatchTime() : 0));
            // 已完成不会撤回
            if (shouldFinish) {
                progress.setFinished(1);
            }
            studyProgressMapper.updateById(progress);
        }
    }

    /**
     * 获取学习进度
     */
    public StudyProgress getProgress(Long userId, Long videoId) {
        LambdaQueryWrapper<StudyProgress> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StudyProgress::getMemberId, userId)
               .eq(StudyProgress::getVideoId, videoId);
        return studyProgressMapper.selectOne(wrapper);
    }

    /**
     * 收藏/取消收藏课程
     * @return true 已收藏 false 未收藏
     */
    public boolean toggleFavorite(Long userId, Long courseId) {
        // 查询包含已软删除的收藏记录（避免唯一键冲突）
        Favorite favorite = favoriteMapper.selectWithDeleted(userId, courseId);

        if (favorite != null) {
            if (favorite.getIsDeleted() != null && favorite.getIsDeleted() == 1) {
                // 已软删除（之前取消过），重新收藏：恢复记录
                favoriteMapper.restoreFavorite(userId, courseId);
                return true;
            } else {
                // 正常收藏状态，执行取消收藏（软删除）
                favoriteMapper.softDeleteFavorite(userId, courseId);
                return false;
            }
        } else {
            // 没有记录，第一次收藏：插入新记录
            favorite = new Favorite();
            favorite.setMemberId(userId);
            favorite.setCourseId(courseId);
            favoriteMapper.insert(favorite);
            return true;
        }
    }

    /**
     * 获取用户收藏的课程列表
     */
    public List<Map<String, Object>> getFavorites(Long userId) {
        LambdaQueryWrapper<Favorite> fw = new LambdaQueryWrapper<>();
        fw.eq(Favorite::getMemberId, userId)
          .orderByDesc(Favorite::getCreateTime);
        List<Favorite> favorites = favoriteMapper.selectList(fw);

        if (favorites.isEmpty()) {
            return new ArrayList<>();
        }

        List<Long> courseIds = favorites.stream()
            .map(Favorite::getCourseId)
            .collect(Collectors.toList());

        LambdaQueryWrapper<Course> cw = new LambdaQueryWrapper<>();
        cw.in(Course::getId, courseIds).eq(Course::getStatus, 1);
        List<Course> courses = courseMapper.selectList(cw);

        // 实时更新学习人数和评分
        enrichCoursesWithStats(courses);

        // 封装结果
        List<Map<String, Object>> result = new ArrayList<>();
        for (Course course : courses) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", course.getId());
            item.put("title", course.getTitle());
            item.put("cover", course.getCover());
            item.put("price", course.getPrice());
            item.put("teacherName", course.getTeacherName());
            item.put("description", course.getDescription());
            item.put("studyCount", course.getStudyCount());
            item.put("score", course.getScore());
            // 查找收藏时间
            Favorite fav = favorites.stream()
                .filter(f -> f.getCourseId().equals(course.getId()))
                .findFirst()
                .orElse(null);
            if (fav != null) {
                item.put("favoriteTime", fav.getCreateTime());
            }
            result.add(item);
        }
        return result;
    }

    /**
     * 获取用户最近学习的课程（按最新学习时间排序）
     */
    public List<Map<String, Object>> getRecentStudyCourses(Long userId, int limit) {
        // 查询用户所有学习进度记录，按更新时间倒序
        LambdaQueryWrapper<StudyProgress> pw = new LambdaQueryWrapper<>();
        pw.eq(StudyProgress::getMemberId, userId)
          .orderByDesc(StudyProgress::getUpdateTime);
        List<StudyProgress> allProgress = studyProgressMapper.selectList(pw);

        if (allProgress.isEmpty()) {
            return new ArrayList<>();
        }

        // 按课程ID去重，保留每个课程最新的一条记录
        Map<Long, StudyProgress> courseProgressMap = new LinkedHashMap<>();
        for (StudyProgress p : allProgress) {
            if (!courseProgressMap.containsKey(p.getCourseId())) {
                courseProgressMap.put(p.getCourseId(), p);
            }
        }

        List<Long> courseIds = new ArrayList<>(courseProgressMap.keySet());

        // 查询课程详情
        LambdaQueryWrapper<Course> cw = new LambdaQueryWrapper<>();
        cw.in(Course::getId, courseIds).eq(Course::getStatus, 1);
        List<Course> courses = courseMapper.selectList(cw);

        // 实时更新学习人数和评分
        enrichCoursesWithStats(courses);

        // 按原始顺序（最近学习排前面）封装结果
        List<Map<String, Object>> result = new ArrayList<>();
        int count = 0;
        for (Long courseId : courseIds) {
            if (count >= limit) break;
            Course course = courses.stream()
                .filter(c -> c.getId().equals(courseId))
                .findFirst()
                .orElse(null);
            if (course == null) continue;

            StudyProgress sp = courseProgressMap.get(courseId);

            Map<String, Object> item = new HashMap<>();
            item.put("id", course.getId());
            item.put("title", course.getTitle());
            item.put("cover", course.getCover());
            item.put("teacherName", course.getTeacherName());

            // 计算课程整体完成进度：已完成视频数 / 课程总视频数
            LambdaQueryWrapper<Video> vw = new LambdaQueryWrapper<>();
            vw.eq(Video::getCourseId, courseId);
            long totalVideos = videoMapper.selectCount(vw);

            LambdaQueryWrapper<StudyProgress> vp = new LambdaQueryWrapper<>();
            vp.eq(StudyProgress::getMemberId, userId)
              .eq(StudyProgress::getCourseId, courseId)
              .eq(StudyProgress::getFinished, 1);
            long finishedVideos = studyProgressMapper.selectCount(vp);

            int progressPercent = totalVideos > 0 ? (int) (finishedVideos * 100 / totalVideos) : 0;
            item.put("progress", progressPercent);

            // 最近学习时间（最新一条学习记录的时间）
            item.put("lastStudyTime", sp.getUpdateTime());
            item.put("lastStudyVideoId", sp.getVideoId());

            result.add(item);
            count++;
        }
        return result;
    }

    /**
     * 获取用户学习统计数据
     * @param userId 用户ID
     * @return 统计数据
     */
    public Map<String, Object> getUserStudyStats(Long userId) {
        Map<String, Object> stats = new HashMap<>();

        // 查询用户所有学习进度
        LambdaQueryWrapper<StudyProgress> pw = new LambdaQueryWrapper<>();
        pw.eq(StudyProgress::getMemberId, userId);
        List<StudyProgress> allProgress = studyProgressMapper.selectList(pw);

        // 1. 已学课程数（学习过的不同课程数量）
        long studiedCourseCount = allProgress.stream()
            .map(StudyProgress::getCourseId)
            .distinct()
            .count();

        // 2. 学习分钟数（累计观看时长，秒转分钟）
        long totalWatchSeconds = allProgress.stream()
            .mapToLong(p -> p.getWatchTime() != null ? p.getWatchTime() : 0)
            .sum();
        long studyMinutes = totalWatchSeconds / 60;

        // 3. 完成课程数（课程下所有视频都看完的课程数量）
        // 先获取用户已购课程
        LambdaQueryWrapper<Order> ow = new LambdaQueryWrapper<>();
        ow.eq(Order::getMemberId, userId).eq(Order::getStatus, 1); // 已支付订单
        List<Order> purchasedOrders = orderMapper.selectList(ow);
        List<Long> purchasedCourseIds = purchasedOrders.stream()
            .map(Order::getCourseId)
            .collect(Collectors.toList());

        int finishedCourseCount = 0;
        for (Long courseId : purchasedCourseIds) {
            // 查询课程总视频数
            LambdaQueryWrapper<Video> vw = new LambdaQueryWrapper<>();
            vw.eq(Video::getCourseId, courseId);
            long totalVideos = videoMapper.selectCount(vw);
            if (totalVideos == 0) continue;

            // 查询用户完成的视频数
            LambdaQueryWrapper<StudyProgress> vp = new LambdaQueryWrapper<>();
            vp.eq(StudyProgress::getMemberId, userId)
              .eq(StudyProgress::getCourseId, courseId)
              .eq(StudyProgress::getFinished, 1);
            long finishedVideos = studyProgressMapper.selectCount(vp);

            // 如果课程所有视频都完成，则计入完成课程数
            if (finishedVideos >= totalVideos) {
                finishedCourseCount++;
            }
        }

        stats.put("courseCount", studiedCourseCount);
        stats.put("studyMinutes", studyMinutes);
        stats.put("finishedCount", finishedCourseCount);

        return stats;
    }

    /**
     * 获取用户打卡统计数据（基于study_progress表的update_time）
     * @param userId 用户ID
     * @return 打卡统计：累计打卡天数、连续打卡天数、今日是否已打卡
     */
    public Map<String, Object> getCheckinStats(Long userId) {
        Map<String, Object> result = new HashMap<>();

        // 查询用户所有学习进度记录的更新时间
        LambdaQueryWrapper<StudyProgress> pw = new LambdaQueryWrapper<>();
        pw.eq(StudyProgress::getMemberId, userId)
          .select(StudyProgress::getUpdateTime);
        List<StudyProgress> allProgress = studyProgressMapper.selectList(pw);

        if (allProgress.isEmpty()) {
            result.put("totalDays", 0);
            result.put("continuousDays", 0);
            result.put("todayCheckedIn", false);
            return result;
        }

        // 提取所有有学习记录的日期（去重）
        Set<LocalDate> studyDates = new TreeSet<>();
        for (StudyProgress p : allProgress) {
            if (p.getUpdateTime() != null) {
                studyDates.add(p.getUpdateTime().toLocalDate());
            }
        }

        // 累计打卡天数
        int totalDays = studyDates.size();

        // 计算连续打卡天数：从今天往前数
        LocalDate today = LocalDate.now();
        int continuousDays = 0;
        LocalDate checkDate = today;

        // 如果今天还没打卡，从昨天开始算连续
        if (!studyDates.contains(today)) {
            checkDate = today.minusDays(1);
        }

        while (studyDates.contains(checkDate)) {
            continuousDays++;
            checkDate = checkDate.minusDays(1);
        }

        result.put("totalDays", totalDays);
        result.put("continuousDays", continuousDays);
        result.put("todayCheckedIn", studyDates.contains(today));

        return result;
    }

    /**
     * 获取用户某月的打卡日期列表（基于study_progress表的update_time）
     * @param userId 用户ID
     * @param year 年
     * @param month 月（1-12）
     * @return 该月打卡的日期列表 ["2026-05-01", "2026-05-03", ...]
     */
    public List<String> getCheckinCalendar(Long userId, int year, int month) {
        LambdaQueryWrapper<StudyProgress> pw = new LambdaQueryWrapper<>();
        pw.eq(StudyProgress::getMemberId, userId)
          .select(StudyProgress::getUpdateTime);
        List<StudyProgress> allProgress = studyProgressMapper.selectList(pw);

        if (allProgress.isEmpty()) {
            return new ArrayList<>();
        }

        // 筛选指定年月的学习日期
        Set<String> dateSet = new TreeSet<>();
        for (StudyProgress p : allProgress) {
            if (p.getUpdateTime() != null) {
                LocalDate date = p.getUpdateTime().toLocalDate();
                if (date.getYear() == year && date.getMonthValue() == month) {
                    dateSet.add(date.toString());
                }
            }
        }

        return new ArrayList<>(dateSet);
    }

    /**
     * 获取课程完成数据（用于证书）
     * @param userId 用户ID
     * @param courseId 课程ID
     * @return 证书数据：课程名、学员名、完成日期、总学时等
     */
    public Map<String, Object> getCertificateData(Long userId, Long courseId) {
        Map<String, Object> cert = new HashMap<>();

        // 查询课程信息
        Course course = courseMapper.selectById(courseId);
        if (course == null) {
            throw new RuntimeException("课程不存在");
        }

        // 查询课程总视频数
        LambdaQueryWrapper<Video> vw = new LambdaQueryWrapper<>();
        vw.eq(Video::getCourseId, courseId);
        long totalVideos = videoMapper.selectCount(vw);

        if (totalVideos == 0) {
            throw new RuntimeException("该课程暂无视频");
        }

        // 查询用户完成的视频数
        LambdaQueryWrapper<StudyProgress> vp = new LambdaQueryWrapper<>();
        vp.eq(StudyProgress::getMemberId, userId)
          .eq(StudyProgress::getCourseId, courseId)
          .eq(StudyProgress::getFinished, 1);
        long finishedVideos = studyProgressMapper.selectCount(vp);

        // 判断是否学完所有视频
        if (finishedVideos < totalVideos) {
            throw new RuntimeException("您还未学完该课程的所有视频，无法获取证书");
        }

        // 计算总学时
        LambdaQueryWrapper<StudyProgress> allPw = new LambdaQueryWrapper<>();
        allPw.eq(StudyProgress::getMemberId, userId)
             .eq(StudyProgress::getCourseId, courseId);
        List<StudyProgress> progressList = studyProgressMapper.selectList(allPw);
        long totalSeconds = progressList.stream()
            .mapToLong(p -> p.getWatchTime() != null ? p.getWatchTime() : 0)
            .sum();
        long totalHours = totalSeconds / 3600;
        long remainMinutes = (totalSeconds % 3600) / 60;

        // 获取最新完成时间
        LocalDateTime latestFinish = progressList.stream()
            .filter(p -> p.getUpdateTime() != null)
            .map(StudyProgress::getUpdateTime)
            .max(LocalDateTime::compareTo)
            .orElse(LocalDateTime.now());

        // 获取讲师名
        Teacher teacher = teacherMapper.selectById(course.getTeacherId());

        // 生成证书编号（课程ID + 用户ID + 时间戳后6位）
        String certNo = "ZX" + courseId + "U" + userId + "T" +
            String.valueOf(System.currentTimeMillis()).substring(7);

        cert.put("courseTitle", course.getTitle());
        cert.put("teacherName", teacher != null ? teacher.getName() : "");
        cert.put("totalVideos", totalVideos);
        cert.put("studyHours", totalHours > 0 ? totalHours + "小时" + remainMinutes + "分钟" : remainMinutes + "分钟");
        cert.put("completeDate", latestFinish.toLocalDate().toString());
        cert.put("certNo", certNo);

        return cert;
    }
}
