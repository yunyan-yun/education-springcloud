package com.edu.gateway.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/**
 * JWT 全局过滤器
 * - 白名单路径直接放行
 * - 其余路径校验 Token，并将用户信息透传到下游服务
 */
@Component
public class AuthGlobalFilter implements GlobalFilter, Ordered {

    @Value("${jwt.secret}")
    private String jwtSecret;

    /**
     * 不需要登录的路径白名单
     */
    private static final List<String> WHITE_LIST = Arrays.asList(
            // 用户服务 - 认证相关（不需要Token）
            "/user/auth/login",
            "/user/auth/register",
            "/user/auth/send-code",
            // 用户服务 - 获取用户头像（评论等公开场景需要）
            "/user/member/avatar",
            // 课程服务 - 公开只读接口（不涉及用户信息）
            "/course/banner",
            "/course/category",
            "/course/list",
            "/course/recommend",
            "/course/hot",
            "/course/latest",
            "/course/" + "\\d+/comments",  // 评论列表（公开）
            // 订单服务 - 支付回调（第三方平台异步通知，不需要用户认证）
            "/order/order/notify"
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();

        // 1. 白名单放行
        if (isWhitePath(path)) {
            return chain.filter(exchange);
        }

        // 2. 课程详情、视频等只读接口放行（支持未登录访问）
        // 支持: /course/123, /course/123/comments, /course/detail/123, /course/video/123/play
        if (path.matches("/course/\\d+($|/.*)") || path.startsWith("/course/detail/") || path.startsWith("/course/video/")) {
            // 有 Token 就解析，没有也放行
            String token = getToken(request);
            if (token != null) {
                try {
                    ServerHttpRequest mutatedRequest = addUserHeaders(request, token);
                    return chain.filter(exchange.mutate().request(mutatedRequest).build());
                } catch (Exception ignored) {
                    // Token 无效时不阻断，作为游客访问
                }
            }
            return chain.filter(exchange);
        }

        // 3. 其余路径必须登录
        String token = getToken(request);
        if (token == null || token.isEmpty()) {
            return unauthorized(exchange.getResponse());
        }

        try {
            ServerHttpRequest mutatedRequest = addUserHeaders(request, token);
            return chain.filter(exchange.mutate().request(mutatedRequest).build());
        } catch (Exception e) {
            return unauthorized(exchange.getResponse());
        }
    }

    /** 从请求头或请求参数中获取 Token */
    private String getToken(ServerHttpRequest request) {
        String auth = request.getHeaders().getFirst("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            return auth.substring(7);
        }
        return null;
    }

    /** 解析 Token 并把用户信息追加到请求头，透传给下游服务 */
    private ServerHttpRequest addUserHeaders(ServerHttpRequest request, String token) {
        byte[] keyBytes = jwtSecret.getBytes(StandardCharsets.UTF_8);
        Claims claims = Jwts.parser()
                .verifyWith(Keys.hmacShaKeyFor(keyBytes))
                .build()
                .parseSignedClaims(token)
                .getPayload();

        // userId 可能是 Long 或 String，需要兼容处理
        Object userIdObj = claims.get("userId");
        String userId = userIdObj != null ? userIdObj.toString() : null;
        String username = claims.get("username", String.class);
        String role = claims.get("role", String.class);

        if (userId == null || userId.isEmpty()) {
            userId = claims.getSubject();
        }

        return request.mutate()
                .header("Authorization", "Bearer " + token)
                .header("X-User-Id",   userId   != null ? userId   : "")
                .header("X-Username",  username != null ? username : "")
                .header("X-User-Role", role     != null ? role     : "")
                .build();
    }

    /** 返回 401 */
    private Mono<Void> unauthorized(ServerHttpResponse response) {
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        return response.setComplete();
    }

    /** 判断是否白名单路径 */
    private boolean isWhitePath(String path) {
        return WHITE_LIST.stream().anyMatch(path::startsWith)
                || path.startsWith("/actuator");
    }

    @Override
    public int getOrder() {
        return -100;
    }
}
