package com.edu.order.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 支付宝沙箱配置
 * 配置信息从 application.yml 中读取
 */
@Data
@Component
@ConfigurationProperties(prefix = "alipay")
public class AlipayConfig {

    /** 沙箱应用ID */
    private String appId;

    /** 应用私钥（RSA2） */
    private String privateKey;

    /** 支付宝公钥 */
    private String alipayPublicKey;

    /** 支付宝网关（沙箱地址） */
    private String gateway;

    /** 异步通知地址（支付宝服务器回调，需要公网可访问） */
    private String notifyUrl;

    /** 支付成功后跳转的前端地址 */
    private String returnUrl;

    /** 响应格式 */
    private String format = "json";

    /** 字符编码 */
    private String charset = "UTF-8";

    /** 签名类型 */
    private String signType = "RSA2";
}
