package com.edu.order.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.result.R;
import com.edu.order.entity.Order;
import com.edu.order.mapper.OrderMapper;
import com.edu.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/order/admin/order")
@RequiredArgsConstructor
public class AdminOrderController {

    private final OrderMapper orderMapper;
    private final OrderService orderService;

    @GetMapping("/page")
    public R<?> page(
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {

        Page<Order> page = new Page<>(current, size);
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);

        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w.like("order_no", keyword).or().like("course_title", keyword));
        }
        if (status != null) {
            wrapper.eq("status", status);
        }
        wrapper.orderByDesc("create_time");

        Page<Order> result = orderMapper.selectPage(page, wrapper);
        return R.ok(result);
    }

    @GetMapping("/detail/{orderNo}")
    public R<?> detail(@PathVariable String orderNo) {
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.eq("order_no", orderNo);
        Order order = orderMapper.selectOne(wrapper);
        return R.ok(order);
    }

    /**
     * 获取今日订单统计
     */
    @GetMapping("/today-stats")
    public R<Map<String, Object>> getTodayStats() {
        // 今日开始时间
        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        LocalDateTime todayEnd = todayStart.plusDays(1);

        // 今日订单数量（所有状态）
        QueryWrapper<Order> countWrapper = new QueryWrapper<>();
        countWrapper.eq("is_deleted", 0)
                   .ge("create_time", todayStart)
                   .lt("create_time", todayEnd);
        long todayOrders = orderMapper.selectCount(countWrapper);

        // 今日收入（仅已支付订单）
        QueryWrapper<Order> incomeWrapper = new QueryWrapper<>();
        incomeWrapper.eq("is_deleted", 0)
                    .eq("status", 1)  // 已支付
                    .ge("create_time", todayStart)
                    .lt("create_time", todayEnd);
        BigDecimal todayIncome = BigDecimal.ZERO;
        var orders = orderMapper.selectList(incomeWrapper);
        for (Order order : orders) {
            if (order.getTotalAmount() != null) {
                todayIncome = todayIncome.add(order.getTotalAmount());
            }
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("todayOrders", todayOrders);
        stats.put("todayIncome", todayIncome);
        return R.ok(stats);
    }

    /**
     * 获取近7天订单和收入统计
     */
    @GetMapping("/stats/7days")
    public R<Map<String, Object>> getStats7Days() {
        Map<String, Object> result = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d");

        List<String> dates = new ArrayList<>();
        List<Long> orderCounts = new ArrayList<>();
        List<Long> incomes = new ArrayList<>();

        for (int i = 6; i >= 0; i--) {
            LocalDate date = LocalDate.now().minusDays(i);
            dates.add(date.format(formatter));

            LocalDateTime dayStart = date.atStartOfDay();
            LocalDateTime dayEnd = dayStart.plusDays(1);

            // 当日订单数
            QueryWrapper<Order> countWrapper = new QueryWrapper<>();
            countWrapper.eq("is_deleted", 0)
                       .ge("create_time", dayStart)
                       .lt("create_time", dayEnd);
            long orderCount = orderMapper.selectCount(countWrapper);
            orderCounts.add(orderCount);

            // 当日收入（已支付订单）
            QueryWrapper<Order> incomeWrapper = new QueryWrapper<>();
            incomeWrapper.eq("is_deleted", 0)
                        .eq("status", 1)
                        .ge("create_time", dayStart)
                        .lt("create_time", dayEnd);
            BigDecimal income = BigDecimal.ZERO;
            var orders = orderMapper.selectList(incomeWrapper);
            for (Order order : orders) {
                if (order.getTotalAmount() != null) {
                    income = income.add(order.getTotalAmount());
                }
            }
            incomes.add(income.longValue() / 100); // 转换为"百元"单位
        }

        result.put("dates", dates);
        result.put("orderCounts", orderCounts);
        result.put("incomes", incomes);
        return R.ok(result);
    }

    /**
     * 删除用户的所有订单（级联）
     */
    @DeleteMapping("/member/{memberId}")
    public R<?> deleteByMember(@PathVariable Long memberId) {
        orderMapper.delete(new QueryWrapper<Order>().eq("member_id", memberId));
        return R.ok();
    }

    /**
     * 按课程ID同步该课程所有订单的冗余字段（课程名称、封面、讲师名称）
     * 供课程服务在课程更新后调用
     * @param courseId 课程ID
     * @return 更新的订单数量
     */
    @PostMapping("/sync-by-course/{courseId}")
    public R<Map<String, Object>> syncByCourseId(@PathVariable Long courseId) {
        int count = orderService.syncByCourseId(courseId);
        Map<String, Object> data = new HashMap<>();
        data.put("updatedCount", count);
        return R.ok(data);
    }
}
