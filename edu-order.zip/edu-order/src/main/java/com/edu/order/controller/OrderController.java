package com.edu.order.controller;

import com.alipay.api.AlipayApiException;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.result.R;
import com.edu.order.entity.Order;
import com.edu.order.service.AlipayService;
import com.edu.order.service.OrderService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/order/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private AlipayService alipayService;

    @PostMapping("/create")
    @SentinelResource(value = "order-create", blockHandler = "createBlockHandler")
    public R<Map<String, Object>> createOrder(
            HttpServletRequest request,
            @RequestParam Long courseId) {
        Long userId = getUserId(request);
        return R.ok(orderService.createOrder(userId, courseId));
    }

    /**
     * 创建订单接口流控降级处理
     * 触发条件：QPS超过阈值
     */
    public R<Map<String, Object>> createBlockHandler(HttpServletRequest request, Long courseId, BlockException ex) {
        return R.fail(429, "下单请求过于频繁，请稍后再试");
    }

    @GetMapping("/list")
    public R<Page<Order>> getOrders(
            HttpServletRequest request,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer status) {
        Long userId = getUserId(request);
        return R.ok(orderService.getUserOrders(userId, current, size, status));
    }

    /**
     * 我的订单（个人中心）
     */
    @GetMapping("/my")
    public R<Page<Order>> getMyOrders(
            HttpServletRequest request,
            @RequestParam(defaultValue = "1") Integer current,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) Integer status) {
        Long userId = getUserId(request);
        return R.ok(orderService.getUserOrders(userId, current, size, status));
    }

    @GetMapping("/detail/{orderNo}")
    public R<Order> getOrderDetail(@PathVariable String orderNo) {
        return R.ok(orderService.getOrderByNo(orderNo));
    }

    /**
     * 获取订单详情（简化路径）
     */
    @GetMapping("/{orderNo}")
    public R<Order> getOrder(@PathVariable String orderNo) {
        return R.ok(orderService.getOrderByNo(orderNo));
    }

    /**
     * 查询订单状态
     */
    @GetMapping("/{orderNo}/status")
    public R<Map<String, Object>> getOrderStatus(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        Map<String, Object> data = new java.util.HashMap<>();
        data.put("orderNo", order.getOrderNo());
        data.put("status", order.getStatus());
        data.put("statusText", order.getStatus() == 1 ? "已支付" : "待支付");
        return R.ok(data);
    }
    
    // ==================== 简化路径接口（供前端直接调用）====================
    
    /**
     * 获取订单详情 - 简化路径
     */
    @GetMapping("/info/{orderNo}")
    public R<Order> getOrderInfo(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        return R.ok(order);
    }

    /**
     * 查询订单状态 - 简化路径
     */
    @GetMapping("/status/{orderNo}")
    public R<Map<String, Object>> getOrderStatusSimple(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        Map<String, Object> data = new java.util.HashMap<>();
        data.put("orderNo", order.getOrderNo());
        data.put("status", order.getStatus());
        data.put("statusText", order.getStatus() == 1 ? "已支付" : "待支付");
        return R.ok(data);
    }

    /**
     * 支付宝异步通知回调（由支付宝服务器主动调用，需要公网地址）
     * 重要：必须返回 "success"（纯文本）才算通知接收成功
     */
    @PostMapping("/notify")
    public void alipayNotify(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Map<String, String[]> paramMap = request.getParameterMap();
        Map<String, String> params = alipayService.convertParams(paramMap);

        try {
            // 1. 验证签名，防止伪造通知
            boolean verified = alipayService.verifyNotify(params);
            if (!verified) {
                response.setContentType("text/plain;charset=UTF-8");
                response.getWriter().write("fail");
                return;
            }

            // 2. 解析回调参数
            String orderNo = params.get("out_trade_no");        // 商户订单号
            String tradeStatus = params.get("trade_status");    // 交易状态
            String tradeNo = params.get("trade_no");            // 支付宝交易号

            System.out.println("[Alipay] 收到异步通知：orderNo=" + orderNo + ", tradeStatus=" + tradeStatus + ", tradeNo=" + tradeNo);

            // 3. 只有交易成功才更新订单状态
            if ("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus)) {
                Order order = orderService.getOrderByNo(orderNo);
                if (order != null && order.getStatus() == 0) {
                    order.setStatus(1);           // 已支付
                    order.setPayType("alipay");    // 支付宝支付
                    order.setTradeNo(tradeNo);     // 记录支付宝交易号
                    order.setPayTime(java.time.LocalDateTime.now());
                    orderService.updateById(order);
                    System.out.println("[Alipay] 订单 " + orderNo + " 已更新为已支付");
                }
            }

            // 4. 返回 success 告知支付宝已收到通知
            response.setContentType("text/plain;charset=UTF-8");
            response.getWriter().write("success");

        } catch (Exception e) {
            System.err.println("[Alipay] 回调处理异常：" + e.getMessage());
            response.setContentType("text/plain;charset=UTF-8");
            response.getWriter().write("fail");
        }
    }

    /**
     * 模拟支付接口（用于测试）
     */
    @PostMapping("/mock-pay")
    public R<Void> mockPay(@RequestParam String orderNo) {
        orderService.paySuccess(orderNo, "mock");
        return R.ok();
    }

    /**
     * 取消订单
     */
    @PostMapping("/cancel/{orderNo}")
    public R<Void> cancelOrder(
            HttpServletRequest request,
            @PathVariable String orderNo) {
        Long userId = getUserId(request);
        orderService.cancelOrder(userId, orderNo);
        return R.ok();
    }

    /**
     * 用户申请退款
     */
    @PostMapping("/refund/{orderNo}")
    public R<Void> applyRefund(
            HttpServletRequest request,
            @PathVariable String orderNo,
            @RequestParam String reason) {
        Long userId = getUserId(request);
        orderService.applyRefund(userId, orderNo, reason);
        return R.ok();
    }

    /**
     * 管理员 - 同意退款
     */
    @PostMapping("/admin/refund/approve/{orderNo}")
    public R<Void> approveRefund(@PathVariable String orderNo) {
        orderService.approveRefund(orderNo);
        return R.ok();
    }

    /**
     * 管理员 - 拒绝退款
     */
    @PostMapping("/admin/refund/reject/{orderNo}")
    public R<Void> rejectRefund(
            @PathVariable String orderNo,
            @RequestParam(required = false) String remark) {
        orderService.rejectRefund(orderNo, remark);
        return R.ok();
    }

    /**
     * 管理员 - 同步订单中的课程名称
     * 将所有订单的 courseTitle 更新为课程表中的最新课程名称
     */
    @PostMapping("/admin/sync-course-titles")
    public R<Map<String, Object>> syncCourseTitles() {
        int count = orderService.syncCourseTitles();
        Map<String, Object> data = new HashMap<>();
        data.put("updatedCount", count);
        return R.ok(data);
    }

    /**
     * 获取支付宝支付表单
     * 返回格式与前端 getAlipayForm 的处理逻辑一致：{ code: 200, data: { html: '...' } }
     */
    @GetMapping("/{orderNo}/pay")
    public R<Map<String, Object>> getAlipayForm(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        if (order.getStatus() != 0) {
            return R.fail("订单已支付或已关闭");
        }

        try {
            String form = alipayService.createPayForm(
                    orderNo,
                    order.getTotalAmount(),
                    order.getCourseTitle()
            );
            Map<String, Object> data = new HashMap<>();
            data.put("html", form);
            data.put("orderNo", orderNo);
            return R.ok(data);
        } catch (AlipayApiException e) {
            System.err.println("[Alipay] 生成支付表单失败：" + e.getMessage());
            return R.fail("支付表单生成失败：" + e.getMessage());
        }
    }
    
    private Long getUserId(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId != null && !userId.isEmpty()) {
            return Long.parseLong(userId);
        }
        throw new RuntimeException("请先登录");
    }
}
