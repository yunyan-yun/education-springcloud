package com.edu.order.controller;

import com.edu.common.result.R;
import com.edu.order.entity.Order;
import com.edu.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 订单前端控制器（简化路径）
 * 用于处理前端直接调用的接口，前端代理后路径为 /order/xxx
 */
@RestController
@RequestMapping("/order")
public class OrderFrontendController {

    @Autowired
    private OrderService orderService;

    /**
     * 获取订单详情 - 简化路径
     * 前端: /order/{orderNo} -> 代理后: /order/{orderNo}
     */
    @GetMapping("/{orderNo}")
    public R<Order> getOrder(@PathVariable String orderNo) {
        return R.ok(orderService.getOrderByNo(orderNo));
    }

    /**
     * 查询订单状态 - 简化路径
     * 前端: /order/status/{orderNo} -> 代理后: /order/status/{orderNo}
     */
    @GetMapping("/status/{orderNo}")
    public R<Map<String, Object>> getOrderStatus(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        Map<String, Object> data = new HashMap<>();
        data.put("orderNo", order.getOrderNo());
        data.put("status", order.getStatus());
        data.put("statusText", order.getStatus() == 1 ? "已支付" : "待支付");
        return R.ok(data);
    }

    /**
     * 查询订单状态 - 备选路径
     * 前端: /order/{orderNo}/status -> 代理后: /order/{orderNo}/status
     */
    @GetMapping("/{orderNo}/status")
    public R<Map<String, Object>> getOrderStatusAlt(@PathVariable String orderNo) {
        return getOrderStatus(orderNo);
    }

    /**
     * 获取支付宝支付表单（模拟）
     * 由于是毕业设计，这里返回模拟的支付表单
     */
    @GetMapping("/{orderNo}/pay")
    public R<Map<String, Object>> getAlipayForm(@PathVariable String orderNo) {
        Order order = orderService.getOrderByNo(orderNo);
        if (order == null) {
            return R.fail("订单不存在");
        }
        // 构建模拟支付页面HTML
        String amount = String.format("%.2f", order.getTotalAmount());
        String resultUrl = "/pay/result?orderNo=" + orderNo + "&success=true";
        String html = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\">" +
            "<title>模拟支付 - 知学在线</title>" +
            "<style>" +
            "body{font-family:Arial,sans-serif;max-width:500px;margin:50px auto;padding:20px;}" +
            ".pay-box{border:1px solid #ddd;border-radius:8px;padding:30px;text-align:center;}" +
            ".order-info{margin:20px 0;padding:15px;background:#f5f5f5;border-radius:4px;}" +
            ".btn{background:#1677ff;color:white;border:none;padding:12px 40px;border-radius:4px;cursor:pointer;font-size:16px;}" +
            ".btn:hover{background:#4096ff;}" +
            ".mock-badge{background:#fff7e6;color:#ad6800;padding:4px 8px;border-radius:4px;font-size:12px;display:inline-block;margin-bottom:10px;}" +
            "</style></head><body>" +
            "<div class=\"pay-box\">" +
            "<div class=\"mock-badge\">模拟支付环境</div>" +
            "<h2>订单支付</h2>" +
            "<div class=\"order-info\">" +
            "<div>订单号：" + orderNo + "</div>" +
            "<div style=\"font-size:20px;font-weight:bold;margin-top:10px;\">应付金额：¥" + amount + "</div>" +
            "</div>" +
            "<p>当前为毕业设计模拟环境，请点击下方按钮模拟支付完成</p>" +
            "<form action=\"/api/order/order/notify\" method=\"POST\" id=\"payForm\">" +
            "<input type=\"hidden\" name=\"orderNo\" value=\"" + orderNo + "\">" +
            "<input type=\"hidden\" name=\"payType\" value=\"mock\">" +
            "<button type=\"submit\" class=\"btn\">确认支付（模拟）</button>" +
            "</form>" +
            "</div>" +
            "<script>document.getElementById('payForm').onsubmit=function(){setTimeout(function(){window.opener&&window.opener.location.assign('" + resultUrl + "');window.close();},500);};</script>" +
            "</body></html>";
        
        Map<String, Object> data = new HashMap<>();
        data.put("html", html);
        data.put("orderNo", orderNo);
        return R.ok(data);
    }
}
