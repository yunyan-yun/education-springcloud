package com.edu.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("edu_order")
public class Order {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String orderNo;
    private Long memberId;
    private Long courseId;
    private String courseTitle;
    private String courseCover;
    private String teacherName;
    private BigDecimal totalAmount;
    private Integer status;
    private String payType;
    private String tradeNo;
    private LocalDateTime payTime;
    
    // 退款相关字段
    private String refundReason;       // 退款原因
    private LocalDateTime refundTime; // 退款时间
    private String refundRemark;      // 管理员退款备注
    private Integer refundRejectCount; // 退款被拒绝次数
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    private Integer isDeleted;
}
