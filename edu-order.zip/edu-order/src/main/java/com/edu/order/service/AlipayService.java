package com.edu.order.service;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.edu.order.config.AlipayConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

/**
 * 支付宝支付服务
 * 接入支付宝沙箱环境，支持电脑网站支付
 */
@Service
public class AlipayService {

    @Autowired
    private AlipayConfig alipayConfig;

    /**
     * 获取 AlipayClient 实例（单例）
     */
    private AlipayClient getAlipayClient() {
        return new DefaultAlipayClient(
                alipayConfig.getGateway(),
                alipayConfig.getAppId(),
                alipayConfig.getPrivateKey(),
                alipayConfig.getFormat(),
                alipayConfig.getCharset(),
                alipayConfig.getAlipayPublicKey(),
                alipayConfig.getSignType()
        );
    }

    /**
     * 生成支付宝电脑网站支付表单
     * @param orderNo   商户订单号（唯一）
     * @param amount    订单金额
     * @param subject   订单标题
     * @return 支付宝支付表单 HTML（自动提交到支付宝）
     */
    public String createPayForm(String orderNo, BigDecimal amount, String subject) throws AlipayApiException {
        AlipayClient client = getAlipayClient();

        AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();
        // 异步通知地址：支付宝服务器主动通知我们更新订单状态
        request.setNotifyUrl(alipayConfig.getNotifyUrl());
        // 同步跳转地址：用户支付完成后浏览器跳转回前端
        request.setReturnUrl(alipayConfig.getReturnUrl() + "?orderNo=" + orderNo);

        // 业务参数
        String bizContent = String.format(
                "{\"out_trade_no\":\"%s\",\"product_code\":\"FAST_INSTANT_TRADE_PAY\","
                        + "\"total_amount\":\"%s\",\"subject\":\"%s\"}",
                orderNo,
                amount.setScale(2, RoundingMode.HALF_UP).toPlainString(), // BigDecimal转字符串并保留2位小数
                subject
        );
        request.setBizContent(bizContent);

        // 执行请求，获取自动提交的支付表单 HTML
        AlipayTradePagePayResponse response = client.pageExecute(request);
        if (response.isSuccess()) {
            return response.getBody(); // 完整的 HTML form，可直接输出到页面
        } else {
            throw new AlipayApiException("生成支付宝表单失败：" + response.getMsg());
        }
    }

    /**
     * 验证支付宝异步通知的签名
     * @param params 通知参数（Map<参数名, 值>）
     * @return 签名是否合法
     */
    public boolean verifyNotify(Map<String, String> params) {
        try {
            return AlipaySignature.rsaCheckV1(
                    params,
                    alipayConfig.getAlipayPublicKey(),
                    alipayConfig.getCharset(),
                    alipayConfig.getSignType()
            );
        } catch (AlipayApiException e) {
            return false;
        }
    }

    /**
     * 解析异步通知参数为 Map
     * @param paramMap HttpServletRequest 的参数 Map
     * @return 统一转换为 String -> String 的 Map
     */
    public Map<String, String> convertParams(Map<String, String[]> paramMap) {
        Map<String, String> params = new HashMap<>();
        paramMap.forEach((key, values) -> {
            if (values != null && values.length > 0) {
                params.put(key, String.join(",", values));
            }
        });
        return params;
    }

    /**
     * 调用支付宝退款接口
     * @param orderNo 商户订单号
     * @param amount 退款金额
     * @param refundNo 退款请求号（同一笔交易多次退款需唯一）
     * @return 是否退款成功
     */
    public boolean refund(String orderNo, BigDecimal amount, String refundNo) throws AlipayApiException {
        AlipayClient client = getAlipayClient();

        AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
        String bizContent = String.format(
                "{\"out_trade_no\":\"%s\",\"refund_amount\":\"%s\",\"out_request_no\":\"%s\"}",
                orderNo,
                amount.setScale(2, RoundingMode.HALF_UP).toPlainString(),
                refundNo
        );
        request.setBizContent(bizContent);

        AlipayTradeRefundResponse response = client.execute(request);
        if (response.isSuccess() && "Y".equals(response.getFundChange())) {
            return true;
        }
        if (response.isSuccess() && "10000".equals(response.getCode())) {
            return true;
        }
        throw new AlipayApiException("支付宝退款失败：" + response.getMsg());
    }
}
