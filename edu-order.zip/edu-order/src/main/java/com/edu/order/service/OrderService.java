package com.edu.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.edu.order.entity.Order;
import com.edu.order.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class OrderService extends ServiceImpl<OrderMapper, Order> {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AlipayService alipayService;

    @SuppressWarnings("unchecked")
    public Map<String, Object> createOrder(Long userId, Long courseId) {
        try {
            // 从课程服务获取课程信息
            Map<String, Object> courseData = restTemplate.getForObject(
                "http://edu-course/course/detail/" + courseId,
                Map.class
            );
            
            if (courseData == null || !courseData.containsKey("data")) {
                throw new RuntimeException("获取课程信息失败");
            }
            
            Map<String, Object> courseDataOuter = (Map<String, Object>) courseData.get("data");
            // 课程详情返回的是 {course: {...}, teacher: {...}, chapters: [...]}
            Map<String, Object> course = (Map<String, Object>) courseDataOuter.get("course");
            String courseTitle = (String) course.get("title");
            
            // 处理价格，可能是 Double 或 BigDecimal
            Object priceObj = course.get("price");
            BigDecimal price;
            if (priceObj instanceof BigDecimal) {
                price = (BigDecimal) priceObj;
            } else if (priceObj instanceof Double) {
                price = BigDecimal.valueOf((Double) priceObj);
            } else if (priceObj instanceof Number) {
                price = BigDecimal.valueOf(((Number) priceObj).doubleValue());
            } else {
                price = new BigDecimal(priceObj.toString());
            }
            
            String cover = course.get("cover") != null ? course.get("cover").toString() : "";
            String teacherName = course.get("teacherName") != null ? course.get("teacherName").toString() : "";
            
            // 生成订单号
            String orderNo = "ORD" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
            
            // 创建订单
            Order order = new Order();
            order.setOrderNo(orderNo);
            order.setMemberId(userId);
            order.setCourseId(courseId);
            order.setCourseTitle(courseTitle);
            order.setCourseCover(cover);
            order.setTeacherName(teacherName);
            order.setTotalAmount(price);
            order.setStatus(0); // 待支付
            order.setCreateTime(LocalDateTime.now());
            
            save(order);
            
            Map<String, Object> data = new HashMap<>();
            data.put("orderId", order.getId());
            data.put("orderNo", orderNo);
            data.put("amount", price);
            
            return data;
        } catch (Exception e) {
            throw new RuntimeException("创建订单失败: " + e.getMessage());
        }
    }

    public Order getOrderByNo(String orderNo) {
        Order order = getOne(new LambdaQueryWrapper<Order>().eq(Order::getOrderNo, orderNo));
        if (order != null) {
            enrichOrderWithCourseInfo(order);
        }
        return order;
    }

    /**
     * 实时从课程服务获取最新课程信息，更新单个订单数据
     */
    @SuppressWarnings("unchecked")
    private void enrichOrderWithCourseInfo(Order order) {
        if (order == null || order.getCourseId() == null) return;
        
        try {
            Map<String, Object> response = restTemplate.getForObject(
                "http://edu-course/course/detail/" + order.getCourseId(),
                Map.class
            );
            
            if (response == null || !response.containsKey("data")) return;
            
            Map<String, Object> data = (Map<String, Object>) response.get("data");
            Map<String, Object> courseData = (Map<String, Object>) data.get("course");
            if (courseData == null) return;
            
            // 更新课程名称
            if (courseData.get("title") != null) {
                order.setCourseTitle(courseData.get("title").toString());
            }
            // 更新课程封面
            if (courseData.get("cover") != null) {
                order.setCourseCover(courseData.get("cover").toString());
            }
            // 更新讲师名称
            if (courseData.get("teacherName") != null) {
                order.setTeacherName(courseData.get("teacherName").toString());
            }
        } catch (Exception e) {
            // 如果获取课程信息失败，不影响订单详情返回
            System.err.println("实时获取课程信息失败: " + e.getMessage());
        }
    }

    public void paySuccess(String orderNo, String payType) {
        Order order = getOrderByNo(orderNo);
        if (order != null && order.getStatus() == 0) {
            order.setStatus(1); // 已支付
            order.setPayType(payType);
            order.setPayTime(LocalDateTime.now());
            updateById(order);
        }
    }

    public Page<Order> getUserOrders(Long userId, Integer current, Integer size, Integer status) {
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Order::getMemberId, userId);
        // 添加状态筛选
        if (status != null) {
            wrapper.eq(Order::getStatus, status);
        }
        wrapper.orderByDesc(Order::getCreateTime);
        Page<Order> page = new Page<>(current, size);
        Page<Order> result = page(page, wrapper);
        // 实时更新课程信息
        enrichOrdersWithCourseInfo(result.getRecords());
        return result;
    }

    public Page<Order> getAllOrders(Integer current, Integer size) {
        LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(Order::getCreateTime);
        Page<Order> page = new Page<>(current, size);
        Page<Order> result = page(page, wrapper);
        // 实时更新课程信息
        enrichOrdersWithCourseInfo(result.getRecords());
        return result;
    }

    /**
     * 实时从课程服务获取最新课程信息，更新订单数据
     */
    @SuppressWarnings("unchecked")
    private void enrichOrdersWithCourseInfo(List<Order> orders) {
        if (orders == null || orders.isEmpty()) return;
        
        try {
            // 获取所有课程列表
            Map<String, Object> response = restTemplate.getForObject(
                "http://edu-course/course/list?current=1&size=1000",
                Map.class
            );
            
            if (response == null || !response.containsKey("data")) return;
            
            Map<String, Object> data = (Map<String, Object>) response.get("data");
            List<Map<String, Object>> courses = (List<Map<String, Object>>) data.get("records");
            if (courses == null) return;
            
            // 构建 courseId -> courseInfo 的映射
            Map<Long, Map<String, Object>> courseMap = new HashMap<>();
            for (Map<String, Object> course : courses) {
                Number idNum = (Number) course.get("id");
                if (idNum != null) {
                    courseMap.put(idNum.longValue(), course);
                }
            }
            
            // 更新每个订单的课程信息
            for (Order order : orders) {
                Map<String, Object> course = courseMap.get(order.getCourseId());
                if (course != null) {
                    // 更新课程名称
                    if (course.get("title") != null) {
                        order.setCourseTitle(course.get("title").toString());
                    }
                    // 更新课程封面
                    if (course.get("cover") != null) {
                        order.setCourseCover(course.get("cover").toString());
                    }
                    // 更新讲师名称
                    if (course.get("teacherName") != null) {
                        order.setTeacherName(course.get("teacherName").toString());
                    }
                }
            }
        } catch (Exception e) {
            // 如果获取课程信息失败，不影响订单列表返回
            System.err.println("实时获取课程信息失败: " + e.getMessage());
        }
    }

    /**
     * 取消订单
     * @param userId 用户ID
     * @param orderNo 订单号
     * @return 是否取消成功
     */
    public boolean cancelOrder(Long userId, String orderNo) {
        Order order = getOrderByNo(orderNo);
        if (order == null) {
            throw new RuntimeException("订单不存在");
        }
        // 验证订单所属用户
        if (!order.getMemberId().equals(userId)) {
            throw new RuntimeException("无权操作此订单");
        }
        // 只有待支付状态才能取消
        if (order.getStatus() != 0) {
            throw new RuntimeException("只能取消待支付的订单");
        }
        order.setStatus(2); // 已取消
        order.setUpdateTime(LocalDateTime.now());
        return updateById(order);
    }

    /**
     * 用户申请退款
     * @param userId 用户ID
     * @param orderNo 订单号
     * @param reason 退款原因
     */
    public void applyRefund(Long userId, String orderNo, String reason) {
        Order order = getOrderByNo(orderNo);
        if (order == null) {
            throw new RuntimeException("订单不存在");
        }
        // 验证订单所属用户
        if (!order.getMemberId().equals(userId)) {
            throw new RuntimeException("无权操作此订单");
        }
        // 只有已支付状态才能申请退款
        if (order.getStatus() != 1) {
            throw new RuntimeException("只有已支付的订单才能申请退款");
        }
        // 检查退款被拒绝次数，超过2次不能申请
        Integer rejectCount = order.getRefundRejectCount();
        if (rejectCount != null && rejectCount >= 2) {
            throw new RuntimeException("退款申请已达上限（2次），无法再次申请");
        }
        order.setStatus(4); // 退款中
        order.setRefundReason(reason);
        order.setUpdateTime(LocalDateTime.now());
        updateById(order);
    }

    /**
     * 管理员同意退款
     * @param orderNo 订单号
     */
    public void approveRefund(String orderNo) {
        Order order = getOrderByNo(orderNo);
        if (order == null) {
            throw new RuntimeException("订单不存在");
        }
        if (order.getStatus() != 4) {
            throw new RuntimeException("该订单不在退款申请中");
        }
        // 调用支付宝退款接口
        try {
            boolean refundSuccess = alipayService.refund(
                    orderNo,
                    order.getTotalAmount(),
                    orderNo + "_REFUND"
            );
            if (!refundSuccess) {
                throw new RuntimeException("支付宝退款失败");
            }
        } catch (Exception e) {
            throw new RuntimeException("退款处理失败：" + e.getMessage());
        }
        order.setStatus(5); // 已退款
        order.setRefundTime(LocalDateTime.now());
        order.setUpdateTime(LocalDateTime.now());
        updateById(order);
    }

    /**
     * 管理员拒绝退款
     * @param orderNo 订单号
     * @param remark 拒绝原因备注
     */
    public void rejectRefund(String orderNo, String remark) {
        Order order = getOrderByNo(orderNo);
        if (order == null) {
            throw new RuntimeException("订单不存在");
        }
        if (order.getStatus() != 4) {
            throw new RuntimeException("该订单不在退款申请中");
        }
        // 拒绝次数+1
        Integer rejectCount = order.getRefundRejectCount();
        if (rejectCount == null) {
            rejectCount = 0;
        }
        order.setRefundRejectCount(rejectCount + 1);
        order.setStatus(1); // 恢复为已支付
        order.setRefundReason(null); // 清空退款原因
        order.setRefundRemark(remark);
        order.setUpdateTime(LocalDateTime.now());
        updateById(order);
    }

    /**
     * 同步订单中的课程名称为最新课程名称
     * 用于课程名称更新后，将历史订单中的课程名称也更新
     * @return 更新的订单数量
     */
    @SuppressWarnings("unchecked")
    public int syncCourseTitles() {
        try {
            // 从课程服务获取所有课程
            Map<String, Object> response = restTemplate.getForObject(
                "http://edu-course/course/list?current=1&size=1000",
                Map.class
            );
            
            if (response == null || !response.containsKey("data")) {
                throw new RuntimeException("获取课程列表失败");
            }
            
            Map<String, Object> data = (Map<String, Object>) response.get("data");
            List<Map<String, Object>> courses = (List<Map<String, Object>>) data.get("records");
            
            if (courses == null || courses.isEmpty()) {
                return 0;
            }
            
            // 构建 courseId -> title 的映射
            Map<Long, String> courseTitleMap = new HashMap<>();
            for (Map<String, Object> course : courses) {
                Long courseId = course.get("id") instanceof Number 
                    ? ((Number) course.get("id")).longValue() 
                    : Long.parseLong(course.get("id").toString());
                String title = (String) course.get("title");
                courseTitleMap.put(courseId, title);
            }
            
            // 查询所有订单并更新课程名称
            List<Order> allOrders = list();
            int updatedCount = 0;
            
            for (Order order : allOrders) {
                String newTitle = courseTitleMap.get(order.getCourseId());
                if (newTitle != null && !newTitle.equals(order.getCourseTitle())) {
                    order.setCourseTitle(newTitle);
                    order.setUpdateTime(LocalDateTime.now());
                    updateById(order);
                    updatedCount++;
                }
            }
            
            return updatedCount;
        } catch (Exception e) {
            throw new RuntimeException("同步课程名称失败: " + e.getMessage());
        }
    }

    /**
     * 按课程ID同步该课程的所有订单冗余字段（课程名称、封面、讲师名称）
     * 课程服务在更新课程后调用此方法
     * @param courseId 课程ID
     * @return 更新的订单数量
     */
    @SuppressWarnings("unchecked")
    public int syncByCourseId(Long courseId) {
        if (courseId == null) return 0;

        try {
            // 从课程服务获取该课程的最新信息
            Map<String, Object> response = restTemplate.getForObject(
                "http://edu-course/course/detail/" + courseId,
                Map.class
            );

            if (response == null || !response.containsKey("data")) {
                System.err.println("同步订单失败：无法获取课程 " + courseId + " 的信息");
                return 0;
            }

            Map<String, Object> data = (Map<String, Object>) response.get("data");
            Map<String, Object> courseData = (Map<String, Object>) data.get("course");
            if (courseData == null) {
                return 0;
            }

            String newTitle = courseData.get("title") != null ? courseData.get("title").toString() : null;
            String newCover = courseData.get("cover") != null ? courseData.get("cover").toString() : null;
            String newTeacherName = courseData.get("teacherName") != null ? courseData.get("teacherName").toString() : null;

            // 查询所有该课程的订单
            List<Order> orders = list(new LambdaQueryWrapper<Order>()
                .eq(Order::getCourseId, courseId));

            if (orders.isEmpty()) {
                return 0;
            }

            int updatedCount = 0;
            for (Order order : orders) {
                boolean changed = false;
                if (newTitle != null && !newTitle.equals(order.getCourseTitle())) {
                    order.setCourseTitle(newTitle);
                    changed = true;
                }
                if (newCover != null && !newCover.equals(order.getCourseCover())) {
                    order.setCourseCover(newCover);
                    changed = true;
                }
                if (newTeacherName != null && !newTeacherName.equals(order.getTeacherName())) {
                    order.setTeacherName(newTeacherName);
                    changed = true;
                }
                if (changed) {
                    order.setUpdateTime(LocalDateTime.now());
                    updateById(order);
                    updatedCount++;
                }
            }

            return updatedCount;
        } catch (Exception e) {
            System.err.println("同步订单失败: " + e.getMessage());
            return 0;
        }
    }
}
