package com.edu.user.config;

import com.edu.common.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 网关已将用户信息透传到请求头，直接读取即可
        String userId   = request.getHeader("X-User-Id");
        String username = request.getHeader("X-Username");
        String role     = request.getHeader("X-User-Role");

        if (userId != null && !userId.isEmpty()) {
            request.setAttribute("X-User-Id",     userId);
            request.setAttribute("X-Username",    username);
            request.setAttribute("X-User-Role",  role);
        }
        // 没登录也放行，让业务层决定是否需要登录
        return true;
    }
}
