package com.edu.user.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.edu.common.result.R;
import com.edu.user.entity.Member;
import com.edu.user.mapper.MemberMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user/admin/member")
@RequiredArgsConstructor
public class AdminMemberController {

    private final MemberMapper memberMapper;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/page")
    public R<?> page(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "15") Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {

        Page<Member> p = new Page<>(page, size);
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);

        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w.like("mobile", keyword).or().like("nickname", keyword));
        }
        if (status != null) {
            wrapper.eq("status", status);
        }
        wrapper.orderByDesc("create_time");

        Page<Member> result = memberMapper.selectPage(p, wrapper);
        return R.ok(result);
    }

    @PutMapping("/{id}/status")
    public R<?> toggleStatus(@PathVariable Long id, @RequestBody java.util.Map<String, Integer> body) {
        Member member = new Member();
        member.setId(id);
        member.setStatus(body.get("status"));
        memberMapper.updateById(member);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    public R<?> deleteMember(@PathVariable Long id) {
        // 1. 级联删除各服务关联数据（物理删除）
        try {
            restTemplate.delete("http://edu-course/course/admin/comment/member/" + id + "/physical");
        } catch (Exception ignored) {}
        try {
            restTemplate.delete("http://edu-course/course/admin/favorite/member/" + id + "/physical");
        } catch (Exception ignored) {}
        try {
            restTemplate.delete("http://edu-course/course/admin/progress/member/" + id + "/physical");
        } catch (Exception ignored) {}
        try {
            restTemplate.delete("http://edu-order/order/admin/order/member/" + id + "/physical");
        } catch (Exception ignored) {}
        try {
            restTemplate.delete("http://edu-ai/ai/admin/ai/member/" + id + "/physical");
        } catch (Exception ignored) {}


        // 2. 物理删除用户本身（强制执行 DELETE SQL，绕过逻辑删除）
        memberMapper.physicalDeleteById(id);
        return R.ok();
    }

    /**
     * 获取用户总数
     */
    @GetMapping("/count")
    public R<Long> getUserCount() {
        QueryWrapper<Member> wrapper = new QueryWrapper<>();
        wrapper.eq("is_deleted", 0);
        long count = memberMapper.selectCount(wrapper);
        return R.ok(count);
    }

    /**
     * 获取近7天每日新增用户数
     */
    @GetMapping("/stats/7days")
    public R<Map<String, Object>> getStats7Days() {
        Map<String, Object> result = new HashMap<>();

        // 计算近7天的日期
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d");
        List<String> dates = new ArrayList<>();
        List<Long> userCounts = new ArrayList<>();

        for (int i = 6; i >= 0; i--) {
            LocalDate date = LocalDate.now().minusDays(i);
            dates.add(date.format(formatter));

            // 统计当天新增用户数
            LocalDateTime dayStart = date.atStartOfDay();
            LocalDateTime dayEnd = dayStart.plusDays(1);

            QueryWrapper<Member> wrapper = new QueryWrapper<>();
            wrapper.eq("is_deleted", 0)
                   .ge("create_time", dayStart)
                   .lt("create_time", dayEnd);
            long count = memberMapper.selectCount(wrapper);
            userCounts.add(count);
        }

        result.put("dates", dates);
        result.put("userCounts", userCounts);
        return R.ok(result);
    }
}
