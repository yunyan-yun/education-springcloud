package com.edu.user.controller;

import com.edu.common.result.R;
import com.edu.user.entity.Member;
import com.edu.user.service.MemberService;
import com.edu.common.util.JwtUtil;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/user/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private MemberService memberService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @SentinelResource(value = "user-login", blockHandler = "loginBlockHandler")
    @PostMapping("/login")
    public R<Map<String, Object>> login(@RequestBody Map<String, String> params) {
        String account = params.get("account");
        String type = params.get("type");

        Map<String, Object> data;

        if ("sms".equals(type)) {
            // 验证码登录
            String code = params.get("code");
            if (!verifyCode(account, code)) {
                return R.fail(400, "验证码错误或已过期");
            }
            data = memberService.loginByMobile(account);
        } else {
            // 密码登录
            String password = params.get("password");
            data = memberService.login(account, password);
        }

        String token = JwtUtil.generateToken(
            (Long) data.get("userId"),
            (String) data.get("username"),
            (String) data.get("role")
        );
        data.put("token", token);

        return R.ok(data);
    }

    /**
     * 登录接口流控降级处理
     * 触发条件：QPS超过阈值（规则在 SentinelRuleConfig 中定义）
     */
    public R<Map<String, Object>> loginBlockHandler(Map<String, String> params, BlockException ex) {
        Map<String, Object> data = new HashMap<>();
        data.put("code", 429);
        data.put("message", "登录请求过于频繁，请稍后再试");
        return R.fail(429, "登录请求过于频繁，请稍后再试");
    }

    @PostMapping("/register")
    public R<Map<String, Object>> register(@RequestBody Map<String, String> params) {
        String mobile = params.get("mobile");
        String password = params.get("password");
        String nickname = params.get("nickname");
        String code = params.get("code");

        // 验证验证码（开发模式下可以使用默认验证码 123456）
        if (code != null && !code.equals("123456")) {
            if (!verifyCode(mobile, code)) {
                return R.fail(400, "验证码错误或已过期");
            }
        }

        // 注册后自动登录
        Map<String, Object> data = memberService.registerAndLogin(mobile, password, nickname);
        String token = JwtUtil.generateToken(
            (Long) data.get("userId"),
            (String) data.get("username"),
            (String) data.get("role")
        );
        data.put("token", token);

        return R.ok(data);
    }

    @PostMapping("/send-code")
    public R<Void> sendCode(@RequestParam String mobile) {
        // 生成6位随机验证码
        String code = String.format("%06d", (int) (Math.random() * 1000000));
        String key = "sms:code:" + mobile;

        // 存储到Redis，5分钟过期
        redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);

        // 打印验证码到日志（开发模式）
        log.info("【验证码发送】手机号：{}，验证码：{}", mobile, code);

        return R.ok();
    }

    /**
     * 验证验证码（内部使用）
     */
    public boolean verifyCode(String mobile, String code) {
        String key = "sms:code:" + mobile;
        String cachedCode = redisTemplate.opsForValue().get(key);
        if (cachedCode != null && cachedCode.equals(code)) {
            // 验证成功后删除验证码
            redisTemplate.delete(key);
            return true;
        }
        return false;
    }

    @GetMapping("/info")
    public R<Map<String, Object>> getInfo(HttpServletRequest request) {
        Long userId = getUserId(request);
        Member member = memberService.getInfo(userId);

        // 用户已被删除，返回未授权让前端跳转登录页
        if (member == null) {
            return R.fail(401, "用户不存在，请重新登录");
        }

        Map<String, Object> data = new HashMap<>();
        data.put("id", member.getId());
        data.put("nickname", member.getNickname());
        data.put("avatar", member.getAvatar());
        data.put("role", member.getRole());
        data.put("mobile", member.getMobile());
        data.put("gender", member.getGender());
        data.put("email", member.getEmail());
        data.put("intro", member.getIntro());

        return R.ok(data);
    }

    private Long getUserId(HttpServletRequest request) {
        // 直接从网关透传的请求头获取
        String userId = request.getHeader("X-User-Id");
        if (userId != null && !userId.isEmpty()) {
            return Long.parseLong(userId);
        }
        throw new RuntimeException("请先登录");
    }
}
