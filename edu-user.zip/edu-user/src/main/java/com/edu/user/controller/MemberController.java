package com.edu.user.controller;

import com.edu.common.result.R;
import com.edu.user.entity.Member;
import com.edu.user.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/user/member")
public class MemberController {

    @Autowired
    private MemberService memberService;

    /**
     * 根据ID获取用户头像（供其他服务调用）
     */
    @GetMapping("/avatar/{id}")
    public R<String> getAvatar(@PathVariable("id") Long id) {
        Member member = memberService.getById(id);
        if (member != null && member.getAvatar() != null) {
            return R.ok(member.getAvatar());
        }
        return R.ok("");
    }

    @GetMapping("/info")
    public R<Member> getInfo(HttpServletRequest request) {
        try {
            Long userId = getUserId(request);
            if (userId == null) {
                return R.fail(401, "请先登录");
            }
            return R.ok(memberService.getInfo(userId));
        } catch (RuntimeException e) {
            return R.fail(400, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail(500, "系统错误，请稍后重试");
        }
    }

    @PutMapping("/info")
    public R<Void> updateInfo(HttpServletRequest request, @RequestBody Member member) {
        try {
            Long userId = getUserId(request);
            if (userId == null) {
                return R.fail(401, "请先登录");
            }
            memberService.updateInfo(userId, member);
            return R.ok();
        } catch (RuntimeException e) {
            return R.fail(400, e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return R.fail(500, "系统错误，请稍后重试");
        }
    }

    @PutMapping("/password")
    public R<Void> updatePassword(
            HttpServletRequest request,
            @RequestBody Map<String, String> params) {
        try {
            Long userId = getUserId(request);
            if (userId == null) {
                return R.fail(401, "请先登录");
            }
            String oldPassword = params.get("oldPassword");
            String newPassword = params.get("newPassword");
            
            if (oldPassword == null || oldPassword.trim().isEmpty()) {
                return R.fail(400, "原密码不能为空");
            }
            if (newPassword == null || newPassword.trim().isEmpty()) {
                return R.fail(400, "新密码不能为空");
            }
            if (newPassword.length() < 6 || newPassword.length() > 20) {
                return R.fail(400, "新密码长度需在6-20位之间");
            }
            
            memberService.updatePassword(userId, oldPassword, newPassword);
            return R.ok();
        } catch (RuntimeException e) {
            // 业务异常直接返回
            return R.fail(400, e.getMessage());
        } catch (Exception e) {
            // 记录其他异常
            e.printStackTrace();
            return R.fail(500, "系统错误，请稍后重试");
        }
    }
    
    private Long getUserId(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId == null || userId.isEmpty()) {
            return null;
        }
        try {
            return Long.parseLong(userId);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
