package com.edu.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("edu_member")
public class Member {
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String mobile;
    
    private String username;
    
    private String password;
    
    private String nickname;
    
    private String avatar;
    
    private String email;
    
    private Integer gender;
    
    private String intro;
    
    private Integer status;
    
    private String role;
    
    private String openId;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    
    private Integer isDeleted;
}
