package com.edu.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.edu.user.entity.Member;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberMapper extends BaseMapper<Member> {

    /**
     * 物理删除用户（绕过逻辑删除机制）
     */
    @Delete("DELETE FROM edu_member WHERE id = #{id}")
    int physicalDeleteById(Long id);
}
