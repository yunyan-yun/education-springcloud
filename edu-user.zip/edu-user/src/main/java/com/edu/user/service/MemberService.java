package com.edu.user.service;

import cn.hutool.crypto.digest.BCrypt;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.edu.user.entity.Member;
import com.edu.user.mapper.MemberMapper;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class MemberService extends ServiceImpl<MemberMapper, Member> {

    /**
     * 验证码登录（已在 Controller 层验证验证码，此处直接按手机号查用户）
     */
    public Map<String, Object> loginByMobile(String mobile) {
        LambdaQueryWrapper<Member> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Member::getMobile, mobile);
        Member member = getOne(wrapper);

        if (member == null) {
            throw new RuntimeException("用户不存在");
        }
        if (member.getStatus() == null || member.getStatus() != 1) {
            throw new RuntimeException("账号已被禁用");
        }

        Map<String, Object> result = new HashMap<>();
        result.put("userId", member.getId());
        result.put("username", member.getNickname());
        result.put("role", member.getRole());

        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", member.getId());
        userInfo.put("nickname", member.getNickname());
        userInfo.put("avatar", member.getAvatar());
        userInfo.put("role", member.getRole());
        userInfo.put("mobile", member.getMobile());
        userInfo.put("gender", member.getGender());
        userInfo.put("email", member.getEmail());
        userInfo.put("intro", member.getIntro());
        result.put("userInfo", userInfo);

        return result;
    }

    public Map<String, Object> login(String account, String password) {
        LambdaQueryWrapper<Member> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Member::getMobile, account).or().eq(Member::getUsername, account);
        Member member = getOne(wrapper);

        if (member == null) {
            throw new RuntimeException("用户不存在");
        }

        if (!BCrypt.checkpw(password, member.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        if (member.getStatus() == null || member.getStatus() != 1) {
            throw new RuntimeException("账号已被禁用");
        }

        Map<String, Object> result = new HashMap<>();
        result.put("userId", member.getId());
        result.put("username", member.getNickname());
        result.put("role", member.getRole());

        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", member.getId());
        userInfo.put("nickname", member.getNickname());
        userInfo.put("avatar", member.getAvatar());
        userInfo.put("role", member.getRole());
        userInfo.put("mobile", member.getMobile());
        userInfo.put("gender", member.getGender());
        userInfo.put("email", member.getEmail());
        userInfo.put("intro", member.getIntro());
        result.put("userInfo", userInfo);

        return result;
    }

    public Member register(String mobile, String password, String nickname) {
        if (count(new LambdaQueryWrapper<Member>().eq(Member::getMobile, mobile)) > 0) {
            throw new RuntimeException("手机号已被注册");
        }

        Member member = new Member();
        member.setMobile(mobile);
        member.setPassword(BCrypt.hashpw(password, BCrypt.gensalt()));
        member.setNickname(nickname != null ? nickname : "用户" + mobile.substring(mobile.length() - 4));
        member.setRole("user");
        member.setStatus(1);
        member.setCreateTime(java.time.LocalDateTime.now());
        member.setUpdateTime(java.time.LocalDateTime.now());

        save(member);
        return member;
    }

    public Map<String, Object> registerAndLogin(String mobile, String password, String nickname) {
        Member member = register(mobile, password, nickname);
        
        Map<String, Object> result = new HashMap<>();
        result.put("userId", member.getId());
        result.put("username", member.getNickname());
        result.put("role", member.getRole());
        
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", member.getId());
        userInfo.put("nickname", member.getNickname());
        userInfo.put("avatar", member.getAvatar());
        userInfo.put("role", member.getRole());
        userInfo.put("mobile", member.getMobile());
        userInfo.put("gender", member.getGender());
        userInfo.put("email", member.getEmail());
        userInfo.put("intro", member.getIntro());
        result.put("userInfo", userInfo);
        
        return result;
    }

    public Member getInfo(Long userId) {
        return getById(userId);
    }

    public void updateInfo(Long userId, Member member) {
        System.out.println("========== updateInfo 开始 ==========");
        System.out.println("userId: " + userId);
        System.out.println("接收到的 nickname: " + member.getNickname());
        System.out.println("接收到的 intro: [" + member.getIntro() + "]");
        System.out.println("接收到的 avatar: " + (member.getAvatar() != null ? member.getAvatar().substring(0, Math.min(50, member.getAvatar().length())) + "..." : "null"));
        System.out.println("===================================");
        
        Member existing = getById(userId);
        if (existing == null) {
            throw new RuntimeException("用户不存在");
        }
        if (member.getNickname() != null) {
            existing.setNickname(member.getNickname());
        }
        if (member.getAvatar() != null) {
            existing.setAvatar(member.getAvatar());
        }
        if (member.getGender() != null) {
            existing.setGender(member.getGender());
        }
        if (member.getEmail() != null) {
            existing.setEmail(member.getEmail());
        }
        if (member.getIntro() != null) {
            existing.setIntro(member.getIntro());
        }
        System.out.println("即将保存的 intro: [" + existing.getIntro() + "]");
        updateById(existing);
        System.out.println("========== updateInfo 结束 ==========");
    }

    public void updatePassword(Long userId, String oldPassword, String newPassword) {
        Member member = getById(userId);
        if (member == null) {
            throw new RuntimeException("用户不存在");
        }
        if (!BCrypt.checkpw(oldPassword, member.getPassword())) {
            throw new RuntimeException("原密码错误");
        }
        member.setPassword(BCrypt.hashpw(newPassword, BCrypt.gensalt()));
        updateById(member);
    }
}
