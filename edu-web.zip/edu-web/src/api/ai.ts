import request from '@/utils/request'

// 普通对话
export const chat = (message: string, sessionId?: string) =>
  request.post<any, any>('/ai/ai/chat', null, { params: { message, sessionId } })

// 课程推荐
export const recommendCourses = (interests: string) =>
  request.post<any, any>('/ai/ai/recommend', null, { params: { interests } })

// 生成学习计划
export const generateStudyPlan = (courseName: string, targetTime: string, hoursPerDay: string) =>
  request.post<any, any>('/ai/ai/plan', null, {
    params: { courseName, targetTime, hoursPerDay },
  })

// 章节总结
export const summarizeChapter = (content: string) =>
  request.post<any, any>('/ai/ai/summarize', null, { params: { content } })

// 获取历史
export const getChatHistory = (sessionId: string) =>
  request.get<any, any>('/ai/ai/history', { params: { sessionId } })

// 清除历史
export const clearHistory = (sessionId: string) =>
  request.delete<any, any>('/ai/ai/history', { params: { sessionId } })
