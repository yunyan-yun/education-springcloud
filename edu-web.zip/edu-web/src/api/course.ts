import request from '@/utils/request'

// 首页轮播图
export const getBanners = () => request.get<any, any>('/course/banner')

// 课程分类
export const getCategories = () => request.get<any, any>('/course/category')

// 推荐课程
export const getRecommendCourses = () => request.get<any, any>('/course/recommend')

// 热门课程
export const getHotCourses = () => request.get<any, any>('/course/hot')

// 最新课程
export const getLatestCourses = () => request.get<any, any>('/course/latest')

// 搜索课程
export const searchCourses = (params: {
  keyword?: string
  categoryId?: number
  sortBy?: string
  isFree?: number
  current?: number
  size?: number
}) => request.get<any, any>('/course/list', { params })

// 课程详情
export const getCourseDetail = (id: number) =>
  request.get<any, any>(`/course/detail/${id}`)

// 获取视频播放地址
export const getPlayUrl = (videoId: number) =>
  request.get<any, any>(`/course/video/${videoId}/play`)

// 记录学习进度
export const recordProgress = (videoId: number, watchTime: number, finished = false) =>
  request.post<any, any>('/course/progress', {
    videoId,
    watchTime,
    finished,
  })

// 获取学习进度
export const getProgress = (videoId: number) =>
  request.get<any, any>(`/course/progress/${videoId}`)

// 收藏/取消收藏
export const toggleFavorite = (courseId: number) =>
  request.post<any, any>(`/course/${courseId}/favorite`)

// 获取收藏课程列表
export const getFavorites = () =>
  request.get<any, any>('/course/favorites')

// 已购课程
export const getPurchasedCourses = () =>
  request.get<any, any>('/course/purchased')

// 提交评论
export const addComment = (courseId: number, content: string, score: number, nickname?: string, avatar?: string) =>
  request.post<any, any>(`/course/${courseId}/comment`, {
    content,
    score,
    nickname,
    avatar,
  })

// 获取评论
export const getComments = (courseId: number, current = 1, size = 10) =>
  request.get<any, any>(`/course/${courseId}/comments`, {
    params: { current, size },
  })

// 获取最近学习的课程
export const getRecentCourses = (limit = 3) =>
  request.get<any, any>('/course/recent-courses', {
    params: { limit },
  })

// 获取用户学习统计（个人中心用）
export const getCourseStats = () =>
  request.get<any, any>('/course/stats')

// ============ 学习笔记 ============

// 获取视频笔记列表
export const getVideoNotes = (videoId: number) =>
  request.get<any, any>(`/course/note/video/${videoId}`)

// 新增笔记
export const addNote = (data: { videoId: number; courseId?: number; chapterId?: number; content: string }) =>
  request.post<any, any>('/course/note', data)

// 编辑笔记
export const updateNote = (id: number, content: string) =>
  request.put<any, any>(`/course/note/${id}`, { content })

// 删除笔记
export const deleteNote = (id: number) =>
  request.delete<any, any>(`/course/note/${id}`)

// ============ 章节测验 ============

// 获取视频测验题
export const getVideoQuestions = (videoId: number) =>
  request.get<any, any>(`/course/question/video/${videoId}`)

// 提交答案
export const submitAnswer = (questionId: number, userAnswer: string) =>
  request.post<any, any>('/course/question/submit', { questionId, userAnswer })

// 获取课程测验统计
export const getQuizStats = (courseId: number) =>
  request.get<any, any>(`/course/question/stats/${courseId}`)

// 批量获取各视频的测验通过状态 { videoId: boolean }
export const getQuizPassedStatus = (courseId: number) =>
  request.get<any, any>(`/course/question/quiz-passed/${courseId}`)

// ============ 学习打卡 ============

// 获取打卡统计（累计天数、连续天数、今日是否打卡）
export const getCheckinStats = () =>
  request.get<any, any>('/course/checkin/stats')

// 获取某月打卡日历
export const getCheckinCalendar = (year: number, month: number) =>
  request.get<any, any>('/course/checkin/calendar', { params: { year, month } })

// ============ 学习证书 ============

// 获取课程证书数据
export const getCertificateData = (courseId: number) =>
  request.get<any, any>(`/course/certificate/${courseId}`)
