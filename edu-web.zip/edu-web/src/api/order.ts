import request from '@/utils/request'

// 创建订单
export const createOrder = (courseId: number) =>
  request.post<any, any>('/order/order/create', null, { params: { courseId } })

// 获取支付宝表单
export const getAlipayForm = (orderNo: string) =>
  request.get<any, any>(`/order/order/${orderNo}/pay`)

// 查询订单状态
export const getOrderStatus = (orderNo: string) =>
  request.get<any, any>(`/order/order/${orderNo}/status`)

// 我的订单
export const getMyOrders = (params: { current?: number; size?: number; status?: number } = {}) =>
  request.get<any, any>('/order/order/my', { params })

// 取消订单
export const cancelOrder = (orderNo: string) =>
  request.post<any, any>(`/order/order/cancel/${orderNo}`)

// 申请退款
export const applyRefund = (orderNo: string, reason: string) =>
  request.post<any, any>(`/order/order/refund/${orderNo}`, null, { params: { reason } })

// 获取订单详情
export const getOrderDetail = (orderNo: string) =>
  request.get<any, any>(`/order/order/info/${orderNo}`)
