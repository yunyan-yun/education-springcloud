import request from '@/utils/request'

export interface LoginParams {
  account: string
  password?: string
  code?: string
  type?: string
}

export interface RegisterParams {
  mobile: string
  password: string
  nickname: string
  code?: string
}

// 登录
export const login = (data: LoginParams) =>
  request.post<any, any>('/user/auth/login', data)

// 注册
export const register = (data: RegisterParams) =>
  request.post<any, any>('/user/auth/register', data)

// 发送验证码
export const sendCode = (mobile: string) =>
  request.post<any, any>('/user/auth/send-code', null, { params: { mobile } })

// 获取当前用户信息
export const getUserInfo = () =>
  request.get<any, any>('/user/auth/info')

// 更新个人信息
export const updateProfile = (data: any) =>
  request.put<any, any>('/user/member/info', data)

// 修改密码
export const changePassword = (data: { oldPassword: string; newPassword: string }) =>
  request.put<any, any>('/user/member/password', data)
