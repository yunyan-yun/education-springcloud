<template>
  <div class="course-card" @click="goDetail">
    <div class="card-cover">
      <img :src="course.cover || '/default-course.png'" :alt="course.title" />
      <span v-if="course.isFree" class="tag free">免费</span>
      <span v-else class="tag price">¥{{ course.price }}</span>
    </div>
    <div class="card-body">
      <h3 class="title">{{ course.title }}</h3>
      <p class="desc">{{ course.description }}</p>
      <div class="meta">
        <span class="teacher">
          <el-icon><User /></el-icon>
          {{ course.teacherName || '讲师' }}
        </span>
        <span class="students">
          <el-icon><View /></el-icon>
          {{ formatNumber(course.viewCount) }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { User, View } from '@element-plus/icons-vue'

const props = defineProps<{
  course: {
    id: number
    title: string
    cover?: string
    description?: string
    price: number
    isFree: number
    teacherName?: string
    viewCount?: number
  }
}>()

const router = useRouter()

const goDetail = () => {
  router.push(`/course/${props.course.id}`)
}

const formatNumber = (num?: number) => {
  if (!num) return '0'
  if (num >= 10000) return (num / 10000).toFixed(1) + '万'
  return num.toString()
}
</script>

<style scoped lang="scss">
.course-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  }
}

.card-cover {
  position: relative;
  aspect-ratio: 16/9;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
  }
  
  &:hover img {
    transform: scale(1.05);
  }
  
  .tag {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    
    &.free {
      background: #52c41a;
      color: white;
    }
    
    &.price {
      background: #ff4d4f;
      color: white;
    }
  }
}

.card-body {
  padding: 16px;
  
  .title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a1a;
    margin-bottom: 8px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  .desc {
    font-size: 13px;
    color: #666;
    margin-bottom: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    line-height: 1.5;
    min-height: 39px;
  }
  
  .meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: #999;
    
    span {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .el-icon {
      font-size: 14px;
    }
  }
}
</style>
