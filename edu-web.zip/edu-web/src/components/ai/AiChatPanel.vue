<template>
  <div class="ai-chat-panel">
    <!-- 头部 -->
    <div class="chat-header">
      <div class="ai-avatar">
        <el-avatar :size="40" style="background: #0891b2">
          AI
        </el-avatar>
        <div class="ai-info">
          <div class="ai-name">知学 AI 助手</div>
          <div class="ai-status">
            <span class="dot"></span> 在线服务中
          </div>
        </div>
      </div>
      <div class="chat-actions">
        <el-tooltip content="清空对话">
          <el-button circle size="small" @click="clearChat">
            <el-icon><Delete /></el-icon>
          </el-button>
        </el-tooltip>
        <el-button v-if="$props.onClose" circle size="small" @click="$emit('close')">
          <el-icon><Close /></el-icon>
        </el-button>
      </div>
    </div>

    <!-- 快捷功能 -->
    <div class="quick-actions">
      <el-button size="small" round @click="recommendCoursesAction" :loading="recommending" :disabled="recommending">
        📚 课程推荐
      </el-button>
      <el-button size="small" round @click="generateStudyPlanAction" :loading="planning" :disabled="planning">
        📅 学习计划
      </el-button>
      <el-button size="small" round @click="summarizeCurrentChapter" :loading="summarizing" :disabled="summarizing">
        📝 章节摘要
      </el-button>
      <el-button size="small" round @click="setQuickMsg('我有问题想请教你')">
        💬 答疑解惑
      </el-button>
    </div>

    <!-- 消息列表 -->
    <div ref="messagesRef" class="messages-container">
      <!-- 欢迎消息 -->
      <div class="message ai-message" v-if="messages.length === 0">
        <el-avatar :size="32" style="background: #0891b2; flex-shrink: 0">AI</el-avatar>
        <div class="bubble">
          👋 你好！我是知学AI助手，可以帮你推荐课程、制定学习计划、解答学习问题，以及总结章节要点。
          <br/><br/>请问有什么我可以帮助你的？
        </div>
      </div>

      <template v-for="(msg, idx) in messages" :key="idx">
        <!-- AI消息 -->
        <div v-if="msg.role === 'assistant'" class="message ai-message">
          <el-avatar :size="32" style="background: #0891b2; flex-shrink: 0">AI</el-avatar>
          <div class="bubble ai-bubble" v-html="renderMarkdown(msg.content)"></div>
        </div>
        <!-- 用户消息 -->
        <div v-else class="message user-message">
          <div class="bubble user-bubble">{{ msg.content }}</div>
          <el-avatar :size="32" :src="userStore.userInfo?.avatar" style="flex-shrink: 0">
            {{ userStore.userInfo?.nickname?.[0] }}
          </el-avatar>
        </div>
      </template>

      <!-- 加载中 -->
      <div v-if="loading" class="message ai-message">
        <el-avatar :size="32" style="background: #0891b2; flex-shrink: 0">AI</el-avatar>
        <div class="bubble ai-bubble typing">
          <span></span><span></span><span></span>
        </div>
      </div>
    </div>

    <!-- 输入框 -->
    <div class="chat-input">
      <el-input
        v-model="inputMsg"
        type="textarea"
        :autosize="{ minRows: 1, maxRows: 4 }"
        placeholder="输入你的问题，按 Enter 发送..."
        resize="none"
        @keydown.enter.exact.prevent="sendMessage"
      />
      <el-button
        type="primary"
        :disabled="!inputMsg.trim() || loading"
        :loading="loading"
        @click="sendMessage"
        circle
      >
        <el-icon><Promotion /></el-icon>
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick, onMounted } from 'vue'
import { marked } from 'marked'
import { chat, getChatHistory, clearHistory as clearHistoryApi, summarizeChapter, recommendCourses, generateStudyPlan } from '@/api/ai'
import { useUserStore } from '@/stores/user'
import { Delete, Close, Promotion } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { v4 as uuidv4 } from 'uuid'

const SESSION_ID_KEY = 'ai_chat_session_id'

const props = defineProps<{
  sessionId?: string
  onClose?: () => void
  currentVideoTitle?: string
  currentChapterTitle?: string
  currentVideoDescription?: string
  currentChapterDescription?: string
  currentCourseName?: string  // 当前课程名称，用于学习计划
}>()
const emit = defineEmits(['close'])

const userStore = useUserStore()
const messages = ref<any[]>([])
const inputMsg = ref('')
const loading = ref(false)
const summarizing = ref(false)
const recommending = ref(false)
const planning = ref(false)
const messagesRef = ref<HTMLElement>()

// 优先使用 props，其次 localStorage，最后生成新的
const getOrCreateSessionId = () => {
  if (props.sessionId) return props.sessionId
  const stored = localStorage.getItem(SESSION_ID_KEY)
  if (stored) return stored
  const newId = uuidv4()
  localStorage.setItem(SESSION_ID_KEY, newId)
  return newId
}
const sessionId = ref(getOrCreateSessionId())

onMounted(async () => {
  // 登录后才加载历史记录
  if (!userStore.isLoggedIn) return
  try {
    const res = await getChatHistory(sessionId.value)
    messages.value = res.data || []
    scrollToBottom()
  } catch {}
})

const sendMessage = async () => {
  const msg = inputMsg.value.trim()
  if (!msg || loading.value) return
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录后再使用AI助手')
    return
  }

  messages.value.push({ role: 'user', content: msg })
  inputMsg.value = ''
  loading.value = true
  scrollToBottom()

  try {
    const res = await chat(msg, sessionId.value)
    // 后端返回 { answer: "...", type: "text" }，需要取 answer 字段
    const answer = res.data?.answer || res.data || '抱歉，暂未收到回复'
    messages.value.push({ role: 'assistant', content: answer })
  } catch (e) {
    messages.value.push({ role: 'assistant', content: '抱歉，我暂时无法回答，请稍后再试。' })
  } finally {
    loading.value = false
    scrollToBottom()
  }
}

const setQuickMsg = (msg: string) => {
  inputMsg.value = msg
}

// 课程推荐：调用真实API获取平台课程数据
const recommendCoursesAction = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录后再使用AI助手')
    return
  }

  recommending.value = true

  // 用户视角追加提示
  const userPrompt = '帮我推荐适合初学者的课程'
  messages.value.push({ role: 'user', content: userPrompt })
  scrollToBottom()

  try {
    const res = await recommendCourses('初学者')
    const courses = res.data || []

    // 渲染推荐结果
    let replyText = '🎯 根据您的需求，为您推荐以下课程：\n\n'
    
    if (courses.length > 0) {
      courses.forEach((course: any, idx: number) => {
        const title = course.title || '课程'
        const teacherName = course.teacherName || '未知讲师'
        const studyCount = course.studyCount || 0
        const score = course.score ? Number(course.score).toFixed(1) : '暂无'
        const price = course.price ? Number(course.price).toFixed(2) : '免费'
        const reason = course.reason || '内容优质，值得学习'
        const cover = course.cover || ''
        
        replyText += `**${idx + 1}. ${title}**\n`
        replyText += `   👨‍🏫 ${teacherName} | 📖 ${studyCount}人学习 | ⭐ ${score}分 | 💰 ¥${price}\n`
        replyText += `   💡 ${reason}\n`
        if (cover) {
          replyText += `   🖼️ ${cover}\n`
        }
        replyText += '\n'
      })
      replyText += '👉 点击课程卡片即可查看详情并开始学习！'
    } else {
      replyText = '抱歉，暂未找到适合您的课程，请稍后再试。'
    }

    messages.value.push({ role: 'assistant', content: replyText })
  } catch (e) {
    messages.value.push({ role: 'assistant', content: '抱歉，暂未获取到推荐课程，请稍后再试。' })
  } finally {
    recommending.value = false
    scrollToBottom()
  }
}

// 学习计划：调用真实API（当前课程或通用课程）
const generateStudyPlanAction = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录后再使用AI助手')
    return
  }

  planning.value = true

  // 使用当前课程名称（如果有的话）
  const courseName = props.currentCourseName || props.currentVideoTitle || 'Java编程'
  
  // 用户视角追加提示
  const userPrompt = `帮我制定一个${courseName}的学习计划，目标一个月，每天2小时`
  messages.value.push({ role: 'user', content: userPrompt })
  scrollToBottom()

  try {
    const res = await generateStudyPlan(courseName, '1个月', '2')
    const plan = res.data || {}

    // 渲染学习计划
    let replyText = `📅 **${courseName} 学习计划**（目标：1个月，每天2小时）\n\n`
    
    let hasPlan = false
    const weeks = ['week1', 'week2', 'week3', 'week4', 'week5', 'week6', 'week7', 'week8']
    const weekNames = ['第一周', '第二周', '第三周', '第四周', '第五周', '第六周', '第七周', '第八周']
    
    for (let i = 0; i < weeks.length; i++) {
      const weekKey = weeks[i]
      const weekName = weekNames[i]
      if (plan[weekKey]) {
        hasPlan = true
        replyText += `**${weekName}：** ${plan[weekKey]}\n\n`
      }
    }
    
    if (!hasPlan) {
      // 降级显示
      replyText += '**第一周：** 了解课程大纲，学习基础知识\n\n'
      replyText += '**第二周：** 深入核心概念，完成基础练习\n\n'
      replyText += '**第三周：** 进阶内容学习，做综合项目\n\n'
      replyText += '**第四周：** 复习巩固，实战应用\n\n'
    }
    
    replyText += '💪 坚持就是胜利，祝您学习愉快！'

    messages.value.push({ role: 'assistant', content: replyText })
  } catch (e) {
    messages.value.push({ role: 'assistant', content: '抱歉，暂未生成学习计划，请稍后再试。' })
  } finally {
    planning.value = false
    scrollToBottom()
  }
}

// 章节摘要：获取当前视频信息后调用AI接口
const summarizeCurrentChapter = async () => {
  if (!userStore.isLoggedIn) {
    ElMessage.warning('请先登录后再使用AI助手')
    return
  }
  if (!props.currentVideoTitle) {
    ElMessage.warning('当前没有正在播放的视频')
    return
  }

  summarizing.value = true

  // 优先用描述字段，兜底用标题
  const content = props.currentVideoDescription
    || props.currentChapterDescription
    || props.currentVideoTitle

  // 用户视角追加一条"正在生成摘要"的提示
  const userPrompt = `请帮我总结"${props.currentChapterTitle || ''} - ${props.currentVideoTitle}"这节课程的要点`
  messages.value.push({ role: 'user', content: userPrompt })
  scrollToBottom()

  try {
    const res = await summarizeChapter(content)
    const data = res.data

    // 解析返回的 JSON 结构，渲染为友好的文字
    let replyText = ''
    if (data && typeof data === 'object') {
      const title = data.title || props.currentVideoTitle
      const content = data.content || ''
      const keyPoints: string[] = data.keyPoints || []

      replyText = `**${title}**\n\n${content}\n\n**核心知识点：**\n`
      if (keyPoints.length > 0) {
        keyPoints.forEach((point, idx) => {
          replyText += `${idx + 1}. ${point}\n`
        })
      } else {
        replyText += '暂无'
      }
    } else {
      replyText = String(data || '抱歉，暂未生成摘要')
    }

    messages.value.push({ role: 'assistant', content: replyText })
  } catch (e) {
    messages.value.push({ role: 'assistant', content: '抱歉，暂未生成摘要，请稍后再试。' })
  } finally {
    summarizing.value = false
    scrollToBottom()
  }
}

const clearChat = async () => {
  try {
    await clearHistoryApi(sessionId.value)
    messages.value = []
    // 生成新的 sessionId 并保存
    const newId = uuidv4()
    sessionId.value = newId
    localStorage.setItem(SESSION_ID_KEY, newId)
    ElMessage.success('对话已清空')
  } catch {}
}

const scrollToBottom = async () => {
  await nextTick()
  if (messagesRef.value) {
    messagesRef.value.scrollTop = messagesRef.value.scrollHeight
  }
}

const renderMarkdown = (content: string) => {
  return marked(content, { breaks: true })
}
</script>

<style lang="scss" scoped>
.ai-chat-panel {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #fff;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #f0f0f0;
  background: linear-gradient(135deg, #f0fdfa, #ecfeff);
}

.ai-avatar {
  display: flex;
  align-items: center;
  gap: 10px;
}

.ai-name {
  font-weight: 600;
  color: #333;
  font-size: 15px;
}

.ai-status {
  font-size: 12px;
  color: #52c41a;
  display: flex;
  align-items: center;
  gap: 4px;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #52c41a;
}

.chat-actions {
  display: flex;
  gap: 6px;
}

.quick-actions {
  padding: 8px 12px;
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  border-bottom: 1px solid #f5f5f5;
  background: #fafafa;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message {
  display: flex;
  gap: 10px;
  align-items: flex-start;

  &.user-message {
    flex-direction: row-reverse;
  }
}

.bubble {
  max-width: 75%;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.6;
  word-break: break-word;
}

.ai-bubble {
  background: #f0f4ff;
  border-radius: 0 12px 12px 12px;
  color: #333;

  :deep(p) { margin: 0 0 8px; &:last-child { margin: 0; } }
  :deep(ul, ol) { padding-left: 16px; margin: 4px 0; }
  :deep(code) { background: #e8edf8; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
  :deep(pre) { background: #2d2d2d; color: #ccc; padding: 12px; border-radius: 8px; overflow-x: auto; }
  :deep(strong) { color: #4267e8; }
}

.user-bubble {
  background: #0891b2;
  color: #fff;
  border-radius: 12px 0 12px 12px;
}

.typing {
  display: flex;
  gap: 4px;
  align-items: center;
  padding: 12px 16px;

  span {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #0891b2;
    animation: bounce 1.4s infinite both;

    &:nth-child(2) { animation-delay: 0.2s; }
    &:nth-child(3) { animation-delay: 0.4s; }
  }
}

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0.6); opacity: 0.5; }
  40% { transform: scale(1); opacity: 1; }
}

.chat-input {
  padding: 12px 16px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 10px;
  align-items: flex-end;
  background: #fafafa;
}
</style>
