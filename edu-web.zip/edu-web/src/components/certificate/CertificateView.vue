<template>
  <el-dialog
    v-model="visible"
    title="学习证书"
    width="800px"
    :close-on-click-modal="false"
    destroy-on-close
  >
    <div class="cert-wrapper">
      <div class="cert" ref="certRef">
        <div class="cert-border">
          <div class="cert-inner">
            <!-- 顶部装饰 -->
            <div class="cert-header">
              <div class="cert-logo">知学在线</div>
              <div class="cert-title">学习证书</div>
              <div class="cert-subtitle">CERTIFICATE OF COMPLETION</div>
            </div>

            <!-- 分隔线 -->
            <div class="cert-divider">
              <span class="divider-left"></span>
              <span class="divider-icon">★</span>
              <span class="divider-right"></span>
            </div>

            <!-- 正文 -->
            <div class="cert-body">
              <p class="cert-text">此证明</p>
              <p class="cert-name">{{ certData.studentName }}</p>
              <p class="cert-text">已成功完成</p>
              <p class="cert-course">{{ certData.courseTitle }}</p>
              <p class="cert-text">课程的学习，该课程由 <span class="cert-teacher">{{ certData.teacherName }}</span> 主讲，</p>
              <p class="cert-text">共计 {{ certData.totalVideos }} 节课时，累计学习 {{ certData.studyHours }}。</p>
            </div>

            <!-- 底部信息 -->
            <div class="cert-footer">
              <div class="cert-date">
                <span class="footer-label">完成日期</span>
                <span class="footer-value">{{ certData.completeDate }}</span>
              </div>
              <div class="cert-seal">
                <div class="seal-circle">
                  <span>知学在线</span>
                  <span>EDUCATION</span>
                </div>
              </div>
              <div class="cert-no">
                <span class="footer-label">证书编号</span>
                <span class="footer-value">{{ certData.certNo }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <el-button @click="visible = false">关闭</el-button>
      <el-button type="primary" @click="downloadCert">下载证书</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import html2canvas from 'html2canvas-pro'
import { useUserStore } from '@/stores/user'
import { getCertificateData } from '@/api/course'
import { ElMessage } from 'element-plus'

const props = defineProps<{
  modelValue: boolean
  courseId: number
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
}>()

const visible = ref(false)
const certRef = ref<HTMLElement>()
const userStore = useUserStore()

const certData = ref({
  studentName: '',
  courseTitle: '',
  teacherName: '',
  totalVideos: 0,
  studyHours: '',
  completeDate: '',
  certNo: ''
})

watch(() => props.modelValue, async (val) => {
  visible.value = val
  if (val && props.courseId) {
    try {
      const res = await getCertificateData(props.courseId)
      if (res.data) {
        certData.value.studentName = userStore.userInfo?.nickname || '学员'
        certData.value.courseTitle = res.data.courseTitle || ''
        certData.value.teacherName = res.data.teacherName || ''
        certData.value.totalVideos = res.data.totalVideos || 0
        certData.value.studyHours = res.data.studyHours || ''
        certData.value.completeDate = res.data.completeDate || ''
        certData.value.certNo = res.data.certNo || ''
      }
    } catch (e: any) {
      ElMessage.warning(e.response?.data?.message || e.message || '获取证书失败')
      visible.value = false
    }
  }
})

watch(visible, (val) => {
  emit('update:modelValue', val)
})

async function downloadCert() {
  if (!certRef.value) return
  try {
    const canvas = await html2canvas(certRef.value, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
    })
    const link = document.createElement('a')
    link.download = `知学在线-学习证书-${certData.value.courseTitle}.png`
    link.href = canvas.toDataURL('image/png')
    link.click()
    ElMessage.success('证书下载成功')
  } catch (e) {
    ElMessage.error('证书下载失败，请重试')
  }
}
</script>

<style scoped lang="scss">
.cert-wrapper {
  display: flex;
  justify-content: center;
  padding: 10px;
}

.cert {
  width: 680px;
  font-family: 'SimSun', 'Songti SC', serif;
}

.cert-border {
  border: 3px solid #b8860b;
  padding: 8px;
  background: linear-gradient(135deg, #fdfcf5, #f9f3e3);
}

.cert-inner {
  border: 1px solid #d4a843;
  padding: 40px 50px;
  position: relative;
}

.cert-header {
  text-align: center;
  margin-bottom: 24px;

  .cert-logo {
    font-size: 14px;
    color: #b8860b;
    letter-spacing: 4px;
    margin-bottom: 12px;
    font-weight: 600;
  }

  .cert-title {
    font-size: 32px;
    font-weight: 700;
    color: #1a1a2e;
    letter-spacing: 12px;
    margin-bottom: 8px;
  }

  .cert-subtitle {
    font-size: 12px;
    color: #999;
    letter-spacing: 4px;
    font-family: 'Times New Roman', serif;
  }
}

.cert-divider {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 30px;
  gap: 12px;

  .divider-left, .divider-right {
    height: 1px;
    width: 120px;
    background: linear-gradient(90deg, transparent, #d4a843);
  }
  .divider-right {
    background: linear-gradient(90deg, #d4a843, transparent);
  }
  .divider-icon {
    color: #d4a843;
    font-size: 14px;
  }
}

.cert-body {
  text-align: center;
  line-height: 2.2;

  .cert-text {
    font-size: 15px;
    color: #444;
    margin: 0;
  }

  .cert-name {
    font-size: 28px;
    font-weight: 700;
    color: #1a1a2e;
    margin: 4px 0;
    letter-spacing: 6px;
  }

  .cert-course {
    font-size: 22px;
    font-weight: 600;
    color: #0891b2;
    margin: 4px 0;
  }

  .cert-teacher {
    color: #0891b2;
    font-weight: 500;
  }
}

.cert-footer {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-top: 36px;
  padding-top: 20px;
  border-top: 1px dashed #d4a843;
}

.cert-date, .cert-no {
  text-align: center;

  .footer-label {
    display: block;
    font-size: 11px;
    color: #999;
    margin-bottom: 4px;
  }

  .footer-value {
    font-size: 13px;
    color: #444;
    font-family: 'Times New Roman', serif;
  }
}

.cert-seal {
  .seal-circle {
    width: 80px;
    height: 80px;
    border: 2px solid #c0392b;
    border-radius: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #c0392b;
    transform: rotate(-15deg);

    span:first-child {
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 2px;
    }

    span:last-child {
      font-size: 9px;
      letter-spacing: 1px;
      font-family: 'Times New Roman', serif;
    }
  }
}
</style>
