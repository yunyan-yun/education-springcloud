<template>
  <div class="comment-list">
    <!-- 提交评论（已购或免费课程都可评价） -->
    <div v-if="canComment" class="submit-comment">
      <h4>写下你的评价</h4>
      <div class="comment-form">
        <el-rate v-model="newScore" :max="5" />
        <el-input
          v-model="newContent"
          type="textarea"
          :rows="3"
          placeholder="分享你的学习体验..."
          maxlength="500"
          show-word-limit
        />
        <el-button type="primary" @click="submitComment" :loading="submitting">
          提交评价
        </el-button>
      </div>
    </div>

    <!-- 评论列表 -->
    <div v-if="comments.length">
      <div v-for="comment in comments" :key="comment.id" class="comment-item">
        <el-avatar :src="getAvatarUrl(comment)" :size="40" :style="getAvatarStyle(comment.memberNickname)">
          {{ comment.memberNickname?.[0] }}
        </el-avatar>
        <div class="comment-body">
          <div class="comment-header">
            <span class="nickname">{{ comment.memberNickname }}</span>
            <el-rate :model-value="comment.score" disabled size="small" />
            <span class="time">{{ formatTime(comment.createTime) }}</span>
          </div>
          <p class="content">{{ comment.content }}</p>
        </div>
      </div>

      <el-pagination
        v-if="total > pageSize"
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        v-model:current-page="currentPage"
        @current-change="loadComments"
      />
    </div>
    <el-empty v-else description="暂无评价" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { getComments, addComment } from '@/api/course'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'
import dayjs from 'dayjs'

const props = defineProps<{ courseId: number; isPurchased: boolean; isFree?: boolean }>()
const emit = defineEmits(['comment-added'])
const userStore = useUserStore()

const canComment = computed(() => props.isPurchased || props.isFree)

const comments = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 10
const newScore = ref(5)
const newContent = ref('')
const submitting = ref(false)

onMounted(() => loadComments())

const loadComments = async () => {
  const res = await getComments(props.courseId, currentPage.value, pageSize)
  comments.value = res.data.records || []
  total.value = res.data.total || 0
}

const submitComment = async () => {
  if (!newContent.value.trim()) return ElMessage.warning('请输入评价内容')
  submitting.value = true
  try {
    const nickname = userStore.userInfo?.nickname || userStore.userInfo?.username || '匿名用户'
    const avatar = userStore.userInfo?.avatar || ''
    await addComment(props.courseId, newContent.value, newScore.value, nickname, avatar)
    ElMessage.success('评价提交成功')
    newContent.value = ''
    newScore.value = 5
    await loadComments()
    // 通知父组件刷新评论数
    emit('comment-added')
  } catch (e: any) {
    ElMessage.error(e.message || '提交失败，请重试')
  } finally {
    submitting.value = false
  }
}

const formatTime = (time: string) => dayjs(time).format('YYYY-MM-DD')

// 获取头像URL，无效时返回空
const getAvatarUrl = (comment: any) => {
  if (!comment.memberAvatar || comment.memberAvatar.startsWith('data:') || !comment.memberAvatar.includes('://')) {
    return ''
  }
  return comment.memberAvatar
}

// 根据昵称生成头像颜色
const getAvatarStyle = (nickname?: string) => {
  const colors = ['#0891b2', '#67C23A', '#E6A23C', '#F56C6C', '#909399', '#06b6d4']
  const index = nickname ? (nickname.charCodeAt(0) || 0) % colors.length : 0
  return { backgroundColor: colors[index], color: '#fff', fontSize: '16px', fontWeight: 600 }
}
</script>

<style lang="scss" scoped>
.comment-list { padding: 16px 0; }

.submit-comment {
  margin-bottom: 32px;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 8px;
  h4 { margin-bottom: 12px; }
}

.comment-form {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 600px;
}

.comment-item {
  display: flex;
  gap: 14px;
  padding: 16px 0;
  border-bottom: 1px solid #f0f0f0;
}

.comment-body { flex: 1; }

.comment-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 6px;
  .nickname { font-weight: 600; font-size: 14px; }
  .time { color: #999; font-size: 12px; margin-left: auto; }
}

.content { font-size: 14px; color: #555; line-height: 1.6; }
</style>
