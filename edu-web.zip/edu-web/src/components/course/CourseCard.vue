<template>
  <div class="course-card" @click="$router.push(`/course/${course.id}`)">
    <div class="card-cover">
      <img :src="course.cover || defaultCover" :alt="course.title" loading="lazy" @error="handleImgError" />
      <div v-if="course.isFree" class="free-badge">免费</div>
    </div>
    <div class="card-body">
      <h3 class="title">{{ course.title }}</h3>
      <p class="sub-title">{{ course.subTitle }}</p>
      <div class="meta">
        <span class="teacher">{{ course.teacherName }}</span>
        <span class="separator">·</span>
        <span class="study-count">{{ formatCount(course.studyCount) }}人学习</span>
      </div>
      <div class="footer">
        <div class="rating">
          <el-rate :model-value="course.score" disabled :max="5" size="small" />
          <span>{{ course.score?.toFixed(1) }}</span>
        </div>
        <div class="price">
          <span v-if="course.isFree" class="free">免费</span>
          <template v-else>
            <span class="current-price">¥{{ course.price }}</span>
            <span v-if="course.originalPrice > course.price" class="original-price">
              ¥{{ course.originalPrice }}
            </span>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { defaultCourseCover as defaultCover } from '@/utils/placeholder'
defineProps<{ course: any }>()

function formatCount(n: number): string {
  if (!n) return '0'
  if (n >= 10000) return (n / 10000).toFixed(1) + 'w'
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k'
  return String(n)
}

const handleImgError = (e: Event) => {
  const img = e.target as HTMLImageElement
  img.src = defaultCover
}
</script>

<style lang="scss" scoped>
.course-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
  }
}

.card-cover {
  position: relative;
  aspect-ratio: 16/9;
  overflow: hidden;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
  }

  &:hover img { transform: scale(1.05); }
}

.free-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  background: #ff6b35;
  color: #fff;
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 4px;
}

.card-body {
  padding: 12px 14px;
}

.title {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 4px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.4;
}

.sub-title {
  font-size: 12px;
  color: #888;
  margin-bottom: 8px;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.meta {
  font-size: 12px;
  color: #999;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.rating {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #f59e0b;
}

.price {
  display: flex;
  align-items: center;
  gap: 4px;
}

.free { color: #ff6b35; font-weight: 600; }
.current-price { color: #e53e3e; font-weight: 700; font-size: 16px; }
.original-price { color: #bbb; text-decoration: line-through; font-size: 12px; }
</style>
