<template>
  <div class="note-panel">
    <!-- 添加笔记 -->
    <div class="note-input-area">
      <el-input
        v-model="newContent"
        type="textarea"
        :rows="3"
        placeholder="记录学习笔记..."
        resize="none"
        maxlength="500"
      />
      <el-button type="primary" size="small" @click="handleAdd" :disabled="!newContent.trim()">
        添加笔记
      </el-button>
    </div>

    <!-- 笔记列表 -->
    <div class="note-list" v-if="notes.length > 0">
      <div class="note-item" v-for="note in notes" :key="note.id">
        <div class="note-content" v-if="editingId !== note.id">{{ note.content }}</div>
        <div class="note-edit" v-else>
          <el-input
            v-model="editContent"
            type="textarea"
            :rows="3"
            resize="none"
            maxlength="500"
          />
          <div class="edit-actions">
            <el-button size="small" @click="editingId = null">取消</el-button>
            <el-button type="primary" size="small" @click="handleUpdate(note.id)">保存</el-button>
          </div>
        </div>
        <div class="note-meta">
          <span class="note-time">{{ formatTime(note.createTime) }}</span>
          <div class="note-actions" v-if="editingId !== note.id">
            <el-button text size="small" @click="startEdit(note)">编辑</el-button>
            <el-button text size="small" type="danger" @click="handleDelete(note.id)">删除</el-button>
          </div>
        </div>
      </div>
    </div>

    <div class="note-empty" v-else>
      <el-icon :size="32" color="#555"><EditPen /></el-icon>
      <span>暂无笔记，开始记录吧</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { getVideoNotes, addNote, updateNote, deleteNote } from '@/api/course'
import { ElMessage } from 'element-plus'
import { EditPen } from '@element-plus/icons-vue'

const props = defineProps<{
  videoId: number
  courseId?: number
  chapterId?: number
}>()

const notes = ref<any[]>([])
const newContent = ref('')
const editingId = ref<number | null>(null)
const editContent = ref('')

const formatTime = (time: string) => {
  if (!time) return ''
  const d = new Date(time)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

const loadNotes = async () => {
  try {
    const res = await getVideoNotes(props.videoId)
    notes.value = res.data || []
  } catch {
    notes.value = []
  }
}

const handleAdd = async () => {
  if (!newContent.value.trim()) return
  try {
    await addNote({
      videoId: props.videoId,
      courseId: props.courseId,
      chapterId: props.chapterId,
      content: newContent.value.trim(),
    })
    newContent.value = ''
    ElMessage.success('笔记已保存')
    loadNotes()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.message || '保存失败')
  }
}

const startEdit = (note: any) => {
  editingId.value = note.id
  editContent.value = note.content
}

const handleUpdate = async (id: number) => {
  if (!editContent.value.trim()) return
  try {
    await updateNote(id, editContent.value.trim())
    editingId.value = null
    ElMessage.success('笔记已更新')
    loadNotes()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.message || '更新失败')
  }
}

const handleDelete = async (id: number) => {
  try {
    await deleteNote(id)
    ElMessage.success('笔记已删除')
    loadNotes()
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.message || '删除失败')
  }
}

watch(() => props.videoId, () => {
  editingId.value = null
  newContent.value = ''
  loadNotes()
}, { immediate: true })
</script>

<style lang="scss" scoped>
.note-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 16px;
}

.note-input-area {
  margin-bottom: 16px;
  :deep(.el-textarea__inner) {
    background: #2a2d3e;
    border-color: #3a3d4e;
    color: #e0e0e0;
    &:focus { border-color: var(--el-color-primary); }
  }
  .el-button {
    margin-top: 8px;
    width: 100%;
  }
}

.note-list {
  flex: 1;
  overflow-y: auto;
}

.note-item {
  background: #2a2d3e;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 10px;
}

.note-content {
  color: #d0d0d0;
  font-size: 13px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-all;
}

.note-edit {
  :deep(.el-textarea__inner) {
    background: #1a1d2e;
    border-color: #3a3d4e;
    color: #e0e0e0;
    &:focus { border-color: var(--el-color-primary); }
  }
  .edit-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 8px;
  }
}

.note-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 8px;
  .note-time {
    font-size: 11px;
    color: #666;
  }
  .note-actions {
    display: flex;
    gap: 0;
  }
}

.note-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #555;
  font-size: 13px;
}
</style>
