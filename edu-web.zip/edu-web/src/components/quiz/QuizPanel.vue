<template>
  <el-dialog
    v-model="visible"
    :title="`视频测验 - ${videoTitle}`"
    width="600px"
    @close="handleClose"
    class="quiz-dialog"
  >
    <div v-if="loading" style="text-align: center; padding: 40px;">
      <el-icon class="is-loading" :size="24"><Loading /></el-icon>
      <p style="margin-top: 12px; color: #888;">加载题目中...</p>
    </div>

    <div v-else-if="questions.length === 0" class="quiz-empty">
      <el-icon :size="48" color="#555"><Document /></el-icon>
      <p>该视频暂无测验题目</p>
    </div>

    <div v-else>
      <!-- 得分汇总 -->
      <div v-if="showResult" class="quiz-result">
        <div class="result-card" :class="accuracy >= 60 ? 'pass' : 'fail'">
          <span class="result-score">{{ correctCount }}/{{ questions.length }}</span>
          <span class="result-label">{{ accuracy >= 60 ? '通过' : '未通过' }}</span>
        </div>
        <p class="result-tip">正确率 {{ accuracy }}%，{{ accuracy >= 60 ? '继续加油！' : '建议重新学习本章节内容' }}</p>
      </div>

      <!-- 题目列表 -->
      <div class="question-list">
        <div
          v-for="(q, idx) in questions"
          :key="q.id"
          class="question-item"
          :class="{ 'is-correct': q._answered && q._isCorrect, 'is-wrong': q._answered && !q._isCorrect }"
        >
          <div class="q-header">
            <span class="q-index">{{ idx + 1 }}.</span>
            <span class="q-content">{{ q.content }}</span>
          </div>

          <div class="q-options">
            <div
              v-for="opt in options"
              :key="opt.key"
              class="q-option"
              :class="{
                selected: q._userAnswer === opt.key && !q._answered,
                correct: q._answered && q._isCorrect && opt.key === q._userAnswer,
                wrong: q._answered && !q._isCorrect && opt.key === q._userAnswer,
                'show-correct': q._answered && opt.key === q._correctAnswer && !q._isCorrect,
              }"
              @click="selectOption(q, opt.key)"
              style="cursor: pointer; user-select: none;"
            >
              <span class="opt-key">{{ opt.key }}</span>
              <span class="opt-text">{{ q[`option${opt.label}`] }}</span>
            </div>
          </div>

          <!-- 解析 -->
          <div v-if="q._answered" class="q-analysis">
            <p><strong>正确答案：{{ q._correctAnswer }}</strong></p>
            <p v-if="q.analysis">{{ q.analysis }}</p>
          </div>
        </div>
      </div>

      <!-- 提交按钮 -->
      <div class="quiz-footer" v-if="!showResult">
        <el-button type="primary" @click="submitAll" :disabled="answeredCount === 0">
          提交答案 ({{ answeredCount }}/{{ questions.length }})
        </el-button>
      </div>
      <div class="quiz-footer" v-else>
        <el-button @click="retryQuiz">重新答题</el-button>
        <el-button @click="handleClose">关闭</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { getVideoQuestions, submitAnswer } from '@/api/course'
import { ElMessage } from 'element-plus'
import { Loading, Document } from '@element-plus/icons-vue'

const props = defineProps<{
  modelValue: boolean
  videoId: number
  videoTitle: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', val: boolean): void
  (e: 'submitted'): void
}>()

const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
})

const loading = ref(false)
const questions = ref<any[]>([])
const showResult = ref(false)

const options = [
  { key: 'A', label: 'A' },
  { key: 'B', label: 'B' },
  { key: 'C', label: 'C' },
  { key: 'D', label: 'D' },
]

const answeredCount = computed(() => questions.value.filter(q => q._userAnswer).length)
const correctCount = computed(() => questions.value.filter(q => q._isCorrect).length)
const accuracy = computed(() => {
  if (answeredCount.value === 0) return 0
  return Math.round(correctCount.value / questions.value.length * 100)
})

const selectOption = (q: any, key: string) => {
  q._userAnswer = key
  if (q._answered) {
    q._answered = false
    q._isCorrect = false
    q._correctAnswer = null
  }
}

const submitAll = async () => {
  const toSubmit = questions.value.filter(q => q._userAnswer)
  for (const q of toSubmit) {
    try {
      const res = await submitAnswer(q.id, q._userAnswer)
      q._isCorrect = res.data.isCorrect
      q._correctAnswer = res.data.correctAnswer
      if (!q.analysis && res.data.analysis) {
        q.analysis = res.data.analysis
      }
      q._answered = true
    } catch {
      ElMessage.error('提交失败，请重试')
    }
  }
  showResult.value = true
  emit('submitted')
}

const retryQuiz = () => {
  questions.value.forEach(q => {
    q._answered = false
    q._isCorrect = false
    q._correctAnswer = null
  })
  showResult.value = false
}

const handleClose = () => {
  visible.value = false
  questions.value = []
  showResult.value = false
}

watch(() => props.modelValue, async (val) => {
  if (val) {
    loading.value = true
    showResult.value = false
    try {
      const res = await getVideoQuestions(props.videoId)
      questions.value = (res.data || []).map(q => ({
        ...q,
        _userAnswer: q.userAnswer || null,
        _isCorrect: q.isCorrect || false,
        _answered: q.answered || false,
        _correctAnswer: null,
      }))
    } catch {
      questions.value = []
    } finally {
      loading.value = false
    }
  }
})
</script>

<style lang="scss" scoped>
.quiz-dialog {
  :deep(.el-dialog__header) {
    background: #1a1d2e;
    padding: 16px 20px;
    margin-right: 0;
    .el-dialog__title { color: #fff; font-size: 16px; }
    .el-dialog__headerbtn .el-dialog__close { color: #aaa; }
  }
  :deep(.el-dialog__body) {
    background: #0f1117;
    padding: 20px;
    max-height: 65vh;
    overflow-y: auto;
  }
}

.quiz-empty {
  text-align: center;
  padding: 40px;
  color: #555;
}

.quiz-result {
  text-align: center;
  margin-bottom: 20px;
  .result-card {
    display: inline-flex;
    align-items: baseline;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 12px;
    &.pass { background: rgba(82, 196, 26, 0.15); }
    &.fail { background: rgba(245, 108, 108, 0.15); }
    .result-score {
      font-size: 28px;
      font-weight: 700;
    }
    .result-label {
      font-size: 16px;
      font-weight: 500;
    }
  }
  .result-tip { margin-top: 8px; color: #888; font-size: 13px; }
}

.question-item {
  background: #1a1d2e;
  border-radius: 10px;
  padding: 16px;
  margin-bottom: 12px;
  border: 1px solid #2a2d3e;
  &.is-correct { border-color: #52c41a; }
  &.is-wrong { border-color: #f56c6c; }

  .q-header {
    display: flex;
    gap: 8px;
    margin-bottom: 12px;
    .q-index { color: var(--el-color-primary); font-weight: 600; flex-shrink: 0; }
    .q-content { color: #e0e0e0; font-size: 14px; line-height: 1.5; }
  }

  .q-options { display: flex; flex-direction: column; gap: 8px; }
  .q-option {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    border-radius: 6px;
    cursor: pointer;
    border: 1px solid #333;
    transition: all 0.2s;
    &:hover:not(.correct):not(.wrong):not(.show-correct) {
      border-color: #555;
      background: rgba(255,255,255,0.05);
      transform: translateX(2px);
    }
    &:active:not(.correct):not(.wrong):not(.show-correct) {
      transform: scale(0.98);
    }
    &.selected {
      border-color: var(--el-color-primary);
      background: rgba(64,158,255,0.15);
      box-shadow: 0 0 0 1px rgba(64,158,255,0.3);
      .opt-key { background: var(--el-color-primary); color: #fff; }
      .opt-text { color: #fff; }
    }
    &.correct { border-color: #52c41a; background: rgba(82,196,26,0.1); .opt-key { background: #52c41a; color: #fff; } }
    &.wrong { border-color: #f56c6c; background: rgba(245,108,108,0.1); .opt-key { background: #f56c6c; color: #fff; } }
    &.show-correct { border-color: #52c41a; .opt-key { background: #52c41a; color: #fff; } }
    .opt-key {
      width: 24px; height: 24px;
      border-radius: 50%;
      background: #2a2d3e;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 600;
      flex-shrink: 0;
      color: #aaa;
    }
    .opt-text { color: #d0d0d0; font-size: 13px; }
  }

  .q-analysis {
    margin-top: 10px;
    padding: 10px 12px;
    background: rgba(255,255,255,0.03);
    border-radius: 6px;
    font-size: 12px;
    color: #8892b0;
    line-height: 1.6;
    p { margin: 4px 0; }
    strong { color: #52c41a; }
  }
}

.quiz-footer {
  text-align: center;
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #2a2d3e;
}
</style>
