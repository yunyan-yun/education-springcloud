<template>
  <div class="layout">
    <!-- 顶部导航 -->
    <header class="header">
      <div class="header-inner">
        <router-link to="/" class="logo">
          <img src="/logo.svg" alt="知学在线" />
          <span>知学在线</span>
        </router-link>

        <nav class="nav">
          <router-link to="/">首页</router-link>
          <router-link to="/courses">全部课程</router-link>
          <el-dropdown v-if="false" trigger="hover">
            <span class="nav-dropdown">课程分类 <el-icon><ArrowDown /></el-icon></span>
          </el-dropdown>
        </nav>

        <div class="header-search">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索课程、讲师..."
            :prefix-icon="Search"
            @keyup.enter="doSearch"
            clearable
          />
        </div>

        <div class="header-actions">
          <template v-if="userStore.isLoggedIn">
            <el-dropdown trigger="hover">
              <div class="user-avatar">
                <el-avatar :src="userStore.userInfo?.avatar" :size="36">
                  {{ userStore.userInfo?.nickname?.[0] }}
                </el-avatar>
                <span>{{ userStore.userInfo?.nickname }}</span>
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="$router.push('/user/center')">个人中心</el-dropdown-item>
                  <el-dropdown-item @click="$router.push('/user/courses')">我的课程</el-dropdown-item>
                  <el-dropdown-item @click="$router.push('/user/favorites')">我的收藏</el-dropdown-item>
                  <el-dropdown-item @click="$router.push('/user/orders')">我的订单</el-dropdown-item>
                  <el-dropdown-item divided @click="$router.push('/user/profile')">账号设置</el-dropdown-item>
                  <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>

            <el-button @click="showAiDrawer = true" type="primary" round size="small">
              <el-icon><ChatDotRound /></el-icon> AI助手
            </el-button>
          </template>
          <template v-else>
            <el-button @click="$router.push('/login')">登录</el-button>
            <el-button type="primary" @click="$router.push('/register')">免费注册</el-button>
            <el-button @click="showAiDrawer = true" type="primary" round size="small">
              <el-icon><ChatDotRound /></el-icon> AI助手
            </el-button>
          </template>
        </div>
      </div>
    </header>

    <!-- 主内容 -->
    <main class="main-content">
      <RouterView />
    </main>

    <!-- 页脚 -->
    <footer class="footer">
      <div class="footer-inner">
        <div class="footer-brand">
          <h3>知学在线</h3>
          <p>让学习更简单、更高效</p>
        </div>
        <div class="footer-links">
          <h4>关于我们</h4>
          <a href="#">关于平台</a>
          <a href="#">联系我们</a>
          <a href="#">用户协议</a>
        </div>
        <div class="footer-links">
          <h4>帮助中心</h4>
          <a href="#">常见问题</a>
          <a href="#">学习指南</a>
          <a href="#">意见反馈</a>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2026 知学在线 版权所有</p>
      </div>
    </footer>

    <!-- AI 助手抽屉 -->
    <el-drawer v-model="showAiDrawer" title="" size="420px" direction="rtl" :with-header="false">
      <AiChatPanel @close="showAiDrawer = false" />
    </el-drawer>

    <!-- 悬浮 AI 按钮（未登录时不显示） -->
    <div
      v-if="userStore.isLoggedIn && !showAiDrawer"
      class="ai-fab"
      @click="showAiDrawer = true"
    >
      <el-icon size="24"><ChatDotRound /></el-icon>
      <span>AI</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { Search, ArrowDown, ChatDotRound } from '@element-plus/icons-vue'
import AiChatPanel from '@/components/ai/AiChatPanel.vue'

const router = useRouter()
const userStore = useUserStore()
const searchKeyword = ref('')
const showAiDrawer = ref(false)

onMounted(() => {
  userStore.fetchUserInfo()
})

const doSearch = () => {
  if (searchKeyword.value.trim()) {
    router.push({ name: 'Search', query: { keyword: searchKeyword.value } })
  }
}

const logout = () => {
  userStore.logout()
  router.push('/')
}
</script>

<style lang="scss" scoped>
.layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  height: 64px;

  &-inner {
    max-width: 1280px;
    margin: 0 auto;
    height: 100%;
    display: flex;
    align-items: center;
    gap: 32px;
    padding: 0 24px;
  }
}

.logo {
  display: flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
  color: var(--el-color-primary);
  font-size: 20px;
  font-weight: 700;
  white-space: nowrap;

  img { width: 32px; height: 32px; }
}

.nav {
  display: flex;
  gap: 24px;

  a {
    color: #333;
    text-decoration: none;
    font-size: 15px;
    padding: 4px 0;
    border-bottom: 2px solid transparent;
    transition: all 0.2s;

    &:hover, &.router-link-active {
      color: var(--el-color-primary);
      border-bottom-color: var(--el-color-primary);
    }
  }
}

.header-search {
  flex: 1;
  max-width: 380px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  white-space: nowrap;
}

.user-avatar {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  color: #333;
  font-size: 14px;
}

.main-content {
  flex: 1;
}

.footer {
  background: #2c3e50;
  color: #aaa;
  padding: 40px 0 0;

  &-inner {
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 24px;
    display: flex;
    gap: 60px;
    padding-bottom: 32px;
  }

  &-brand {
    flex: 1;
    h3 { color: #fff; font-size: 20px; margin-bottom: 8px; }
    p { color: #aaa; }
  }

  &-links {
    display: flex;
    flex-direction: column;
    gap: 8px;
    h4 { color: #ddd; margin-bottom: 4px; }
    a { color: #aaa; text-decoration: none; &:hover { color: #fff; } }
  }

  &-bottom {
    border-top: 1px solid #444;
    padding: 16px 24px;
    text-align: center;
    font-size: 12px;
  }
}

.ai-fab {
  position: fixed;
  right: 24px;
  bottom: 80px;
  width: 56px;
  height: 56px;
  background: var(--el-color-primary);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #fff;
  cursor: pointer;
  box-shadow: 0 4px 16px rgba(64, 158, 255, 0.4);
  transition: transform 0.2s;
  font-size: 11px;
  gap: 2px;

  &:hover { transform: scale(1.1); }
}
</style>
