<template>
  <div class="user-layout">
    <!-- 顶部导航 -->
    <header class="user-header">
      <div class="header-inner">
        <router-link to="/" class="logo">
          <img src="/logo.svg" alt="知学在线" class="logo-img" />
          <span>知学在线</span>
        </router-link>
        <span class="header-title">个人中心</span>
        <div class="header-right">
          <router-link to="/">返回首页</router-link>
        </div>
      </div>
    </header>

    <div class="user-container">
      <!-- 左侧菜单 -->
      <aside class="user-sidebar">
        <div class="user-info-card">
          <el-avatar :size="72" :src="userStore.userInfo?.avatar" class="user-avatar">
            <el-icon :size="36"><UserFilled /></el-icon>
          </el-avatar>
          <div class="user-name">{{ userStore.userInfo?.nickname || userStore.userInfo?.username || '用户' }}</div>
          <div class="user-tag">{{ userStore.userInfo?.intro || '这个人很懒，什么都没留下' }}</div>
        </div>
        <el-menu
          :default-active="activeMenu"
          class="side-menu"
          router
        >
          <el-menu-item index="/user/center">
            <el-icon><House /></el-icon>
            <span>个人主页</span>
          </el-menu-item>
          <el-menu-item index="/user/courses">
            <el-icon><VideoPlay /></el-icon>
            <span>我的课程</span>
          </el-menu-item>
          <el-menu-item index="/user/orders">
            <el-icon><List /></el-icon>
            <span>我的订单</span>
          </el-menu-item>
          <el-menu-item index="/user/favorites">
            <el-icon><Star /></el-icon>
            <span>我的收藏</span>
          </el-menu-item>
          <el-menu-item index="/user/profile">
            <el-icon><Setting /></el-icon>
            <span>账号设置</span>
          </el-menu-item>
        </el-menu>
      </aside>

      <!-- 右侧内容区 -->
      <main class="user-main">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { UserFilled, House, VideoPlay, List, Star, Setting } from '@element-plus/icons-vue'

const route = useRoute()
const userStore = useUserStore()

const activeMenu = computed(() => route.path)
</script>

<style scoped lang="scss">
.user-layout {
  min-height: 100vh;
  background: #f5f7fa;
}

.user-header {
  background: #fff;
  border-bottom: 1px solid #e8e8e8;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);

  .header-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
    height: 60px;
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .logo {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: #333;
    font-size: 18px;
    font-weight: 700;

    .logo-img {
      height: 32px;
    }
  }

  .header-title {
    color: #999;
    font-size: 14px;
    &::before { content: '/'; margin-right: 16px; }
  }

  .header-right {
    margin-left: auto;
    a {
      color: #0891b2;
      text-decoration: none;
      font-size: 14px;
      &:hover { text-decoration: underline; }
    }
  }
}

.user-container {
  max-width: 1200px;
  margin: 24px auto;
  padding: 0 24px;
  display: flex;
  gap: 24px;
  align-items: flex-start;
}

.user-sidebar {
  width: 220px;
  flex-shrink: 0;
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);

  .user-info-card {
    padding: 28px 20px 20px;
    text-align: center;
    background: #0891b2;
    color: #fff;
  }

  .user-avatar {
    margin-bottom: 12px;
    border: 3px solid rgba(255,255,255,0.5);
  }

  .user-name {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 4px;
  }

  .user-tag {
    font-size: 12px;
    opacity: 0.8;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .side-menu {
    border-right: none;
    padding: 8px 0;

    :deep(.el-menu-item) {
      height: 48px;
      line-height: 48px;
      border-radius: 0;
      &.is-active {
        color: #0891b2;
        background: #ecfeff;
        font-weight: 600;
      }
      &:hover { background: #f0fdfa; color: #0891b2; }
    }
  }
}

.user-main {
  flex: 1;
  min-width: 0;
}
</style>
