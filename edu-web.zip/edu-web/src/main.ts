// 屏蔽 Element Plus 2.6.x 已知 accessibility 警告（框架 bug，非业务问题）
const originalWarn = console.warn
console.warn = (...args: any[]) => {
  const msg = args[0]
  if (typeof msg === 'string' && msg.includes('label.for') && msg.includes('does not match')) return
  originalWarn.apply(console, args)
}

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import './styles/index.scss'
import './styles/theme.scss'

const app = createApp(App)
const pinia = createPinia()

// 注册所有 Element Plus 图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(pinia)
app.use(router)
app.use(ElementPlus, { locale: zhCn })

app.mount('#app')
