import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

NProgress.configure({ showSpinner: false })

const routes = [
  {
    path: '/',
    component: () => import('@/layouts/MainLayout.vue'),
    children: [
      { path: '', name: 'Home', component: () => import('@/views/home/HomePage.vue'), meta: { title: '首页' } },
      { path: 'courses', name: 'CourseList', component: () => import('@/views/course/CourseListPage.vue'), meta: { title: '课程列表' } },
      { path: 'course/:id', name: 'CourseDetail', component: () => import('@/views/course/CourseDetailPage.vue'), meta: { title: '课程详情' } },
      { path: 'search', name: 'Search', component: () => import('@/views/course/SearchPage.vue'), meta: { title: '搜索' } },
    ],
  },
  {
    path: '/learn/:courseId/video/:videoId',
    name: 'VideoPlayer',
    component: () => import('@/views/learn/VideoPlayerPage.vue'),
    meta: { title: '视频学习', requiresAuth: true },
  },
  {
    path: '/user',
    component: () => import('@/layouts/UserLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: 'center', name: 'UserCenter', component: () => import('@/views/user/UserCenterPage.vue'), meta: { title: '个人中心' } },
      { path: 'courses', name: 'MyCourses', component: () => import('@/views/user/MyCoursesPage.vue'), meta: { title: '我的课程' } },
      { path: 'orders', name: 'MyOrders', component: () => import('@/views/user/MyOrdersPage.vue'), meta: { title: '我的订单' } },
      { path: 'favorites', name: 'MyFavorites', component: () => import('@/views/user/MyFavoritesPage.vue'), meta: { title: '我的收藏' } },
      { path: 'profile', name: 'EditProfile', component: () => import('@/views/user/EditProfilePage.vue'), meta: { title: '编辑资料' } },
    ],
  },
  {
    path: '/pay',
    meta: { requiresAuth: true },
    children: [
      { path: 'order/:courseId?', name: 'PayOrder', component: () => import('@/views/pay/PayOrderPage.vue'), meta: { title: '确认订单' } },
      { path: 'result', name: 'PayResult', component: () => import('@/views/pay/PayResultPage.vue'), meta: { title: '支付结果' } },
    ],
  },
  { path: '/login', name: 'Login', component: () => import('@/views/auth/LoginPage.vue'), meta: { title: '登录' } },
  { path: '/register', name: 'Register', component: () => import('@/views/auth/RegisterPage.vue'), meta: { title: '注册' } },
  { path: '/:pathMatch(.*)*', name: 'NotFound', component: () => import('@/views/NotFoundPage.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 }),
})

router.beforeEach(async (to, from, next) => {
  NProgress.start()
  document.title = `${to.meta.title || '知学在线'} - 在线教育平台`

  if (to.meta.requiresAuth) {
    const userStore = useUserStore()
    const token = localStorage.getItem('token')
    if (!token) {
      next({ name: 'Login', query: { redirect: to.fullPath } })
      return
    }
    // 如果有token但store里没有userInfo，则获取一次
    if (!userStore.userInfo) {
      await userStore.fetchUserInfo()
    }
  }
  next()
})

router.afterEach(() => {
  NProgress.done()
})

export default router
