import axios from 'axios'
import { ElMessage } from 'element-plus'
import router from '@/router'

const request = axios.create({
  baseURL: '/api',
  timeout: 30000,
})

// 请求拦截器
request.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

// 响应拦截器
request.interceptors.response.use(
  (response) => {
    const { data } = response
    if (data.code === 200) {
      return data
    }
    if (data.code === 401) {
      localStorage.removeItem('token')
      router.push('/login')
      ElMessage.error('请先登录')
      return Promise.reject(data)
    }
    ElMessage.error(data.message || '请求失败')
    return Promise.reject(data)
  },
  (error) => {
    // HTTP 层面的错误（如网关返回 401、404、500 等）
    const status = error.response?.status
    const data = error.response?.data

    if (status === 401) {
      // Token 失效或未登录，清除 token 并跳转登录
      localStorage.removeItem('token')
      router.push('/login')
      const msg = data?.message || '登录已过期，请重新登录'
      ElMessage.error(msg)
    } else {
      const msg = data?.message || error.message || '网络错误'
      ElMessage.error(msg)
    }
    return Promise.reject(error)
  },
)

export default request
