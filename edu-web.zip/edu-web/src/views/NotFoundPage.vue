<template>
  <div class="not-found-page">
    <div class="content">
      <div class="num">404</div>
      <h2 class="title">页面不见了</h2>
      <p class="desc">您访问的页面不存在或已被删除</p>
      <div class="actions">
        <el-button type="primary" size="large" @click="$router.push('/')">返回首页</el-button>
        <el-button size="large" @click="$router.go(-1)">返回上页</el-button>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.not-found-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ecfeff;
}

.content {
  text-align: center;
  .num {
    font-size: 140px;
    font-weight: 900;
    color: #0891b2;
    line-height: 1;
    margin-bottom: 16px;
  }
  .title { font-size: 28px; font-weight: 700; color: #1f2329; margin: 0 0 12px; }
  .desc { font-size: 15px; color: #999; margin: 0 0 32px; }
  .actions { display: flex; gap: 12px; justify-content: center; }
}
</style>
