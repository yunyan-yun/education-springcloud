<template>
  <div class="auth-page">
    <div class="auth-card">
      <div class="auth-left">
        <img src="/auth-bg.svg" alt="" />
        <h2>欢迎回来</h2>
        <p>开启你的学习之旅，让知识改变命运</p>
      </div>
      <div class="auth-right">
        <router-link to="/" class="brand">知学在线</router-link>
        <h3>登录账号</h3>

        <el-tabs v-model="loginType">
          <el-tab-pane label="密码登录" name="password">
            <el-form :model="form" :rules="rules" ref="formRef" @submit.prevent="doLogin">
              <el-form-item prop="account">
                <el-input v-model="form.account" placeholder="手机号/账号" :prefix-icon="User" size="large" />
              </el-form-item>
              <el-form-item prop="password">
                <el-input v-model="form.password" type="password" placeholder="密码" :prefix-icon="Lock" size="large" show-password />
              </el-form-item>
              <el-button type="primary" native-type="submit" block size="large" :loading="loading">
                登 录
              </el-button>
            </el-form>
          </el-tab-pane>
          <el-tab-pane label="验证码登录" name="sms">
            <el-form :model="smsForm" ref="smsFormRef" @submit.prevent="doSmsLogin">
              <el-form-item>
                <el-input v-model="smsForm.mobile" placeholder="手机号" :prefix-icon="Phone" size="large" />
              </el-form-item>
              <el-form-item>
                <div class="code-input">
                  <el-input v-model="smsForm.code" placeholder="验证码" size="large" />
                  <el-button :disabled="countdown > 0" @click="sendCode" size="large">
                    {{ countdown > 0 ? `${countdown}s后重发` : '获取验证码' }}
                  </el-button>
                </div>
              </el-form-item>
              <el-button type="primary" native-type="submit" block size="large" :loading="loading">
                登 录
              </el-button>
            </el-form>
          </el-tab-pane>
        </el-tabs>

        <div class="auth-footer">
          <router-link to="/" class="back-home">
            <el-icon><HomeFilled /></el-icon>
            返回首页
          </router-link>
          <span class="divider">|</span>
          <span>还没有账号？</span>
          <router-link to="/register">立即注册</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { sendCode as sendCodeApi } from '@/api/user'
import { ElMessage } from 'element-plus'
import { User, Lock, Phone, HomeFilled } from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const loginType = ref('password')
const loading = ref(false)
const countdown = ref(0)
const formRef = ref()
const smsFormRef = ref()

const form = ref({ account: '', password: '' })
const smsForm = ref({ mobile: '', code: '' })

const rules = {
  account: [{ required: true, message: '请输入账号', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
}

const doLogin = async () => {
  await formRef.value.validate()
  loading.value = true
  try {
    await userStore.login({ ...form.value, type: 'password' })
    const redirect = route.query.redirect as string
    router.push(redirect || '/')
    ElMessage.success('登录成功')
  } finally {
    loading.value = false
  }
}

const doSmsLogin = async () => {
  loading.value = true
  try {
    await userStore.login({ account: smsForm.value.mobile, code: smsForm.value.code, type: 'sms' })
    const redirect = route.query.redirect as string
    router.push(redirect || '/')
    ElMessage.success('登录成功')
  } finally {
    loading.value = false
  }
}

const sendCode = async () => {
  if (!smsForm.value.mobile) return ElMessage.warning('请输入手机号')
  await sendCodeApi(smsForm.value.mobile)
  ElMessage.success('验证码已发送，请查收手机短信')
  countdown.value = 60
  const timer = setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) clearInterval(timer)
  }, 1000)
}
</script>

<style lang="scss" scoped>
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #ecfeff 0%, #cffafe 100%);
}

.auth-card {
  display: flex;
  background: #fff;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(8, 145, 178, 0.15);
  width: 900px;
  max-width: 96vw;
}

.auth-left {
  flex: 1;
  background: #0891b2;
  padding: 60px 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  color: #fff;

  img { width: 260px; margin-bottom: 24px; opacity: 0.9; }
  h2 { font-size: 28px; margin-bottom: 12px; font-weight: 700; }
  p { opacity: 0.85; line-height: 1.6; font-size: 15px; }

  @media (max-width: 768px) { display: none; }
}

.auth-right {
  width: 400px;
  padding: 48px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.brand {
  font-size: 22px;
  font-weight: 700;
  color: #0891b2;
  text-decoration: none;
  margin-bottom: 24px;
}

h3 {
  font-size: 22px;
  margin-bottom: 24px;
  color: #1a1a1a;
  font-weight: 600;
}

.code-input {
  display: flex;
  gap: 8px;
}

.auth-footer {
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
  color: #646464;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;

  a { color: #0891b2; margin-left: 4px; font-weight: 500; }

  .back-home {
    display: flex;
    align-items: center;
    gap: 4px;
    color: #646464;
    text-decoration: none;
    transition: color 0.2s;

    &:hover { color: #0891b2; }
  }

  .divider { color: #d9d9d9; }
}
</style>
