<template>
  <div class="register-page">
    <div class="page-wrap">
      <!-- 左侧品牌区 -->
      <div class="brand-side">
        <router-link to="/" class="logo-wrap">
          <img src="/logo.svg" alt="" class="logo" />
        </router-link>
        <h1 class="brand-slogan">开启你的学习之旅</h1>
        <p class="brand-desc">注册即可免费学习数百门精品课程，获得AI智能学习助手的全程陪伴</p>
        <div class="feature-list">
          <div class="feature-item" v-for="item in features" :key="item.text">
            <el-icon color="#a78bfa"><CircleCheck /></el-icon>
            <span>{{ item.text }}</span>
          </div>
        </div>
        <img src="/auth-bg.svg" alt="" class="bg-img" />
      </div>

      <!-- 右侧注册表单 -->
      <div class="form-side">
        <div class="form-card">
          <h2 class="form-title">创建账号</h2>
          <p class="form-subtitle">已有账号？<router-link to="/login">立即登录</router-link></p>

          <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
            <el-form-item label="手机号" prop="mobile">
              <el-input
                v-model="form.mobile"
                placeholder="请输入手机号"
                size="large"
                prefix-icon="Phone"
              />
            </el-form-item>

            <el-form-item label="昵称" prop="nickname">
              <el-input
                v-model="form.nickname"
                placeholder="请输入昵称（2-10位）"
                size="large"
                prefix-icon="User"
              />
            </el-form-item>

            <el-form-item label="验证码" prop="code">
              <div class="code-wrap">
                <el-input
                  v-model="form.code"
                  placeholder="请输入验证码"
                  size="large"
                  maxlength="6"
                  autocomplete="one-time-code"
                />
                <el-button
                  size="large"
                  class="send-code-btn"
                  :disabled="countdown > 0"
                  @click="sendCode"
                >
                  {{ countdown > 0 ? `${countdown}s后重发` : '获取验证码' }}
                </el-button>
              </div>
            </el-form-item>

            <el-form-item label="密码" prop="password">
              <el-input
                v-model="form.password"
                type="password"
                show-password
                placeholder="请设置密码（6-20位）"
                size="large"
                prefix-icon="Lock"
                autocomplete="new-password"
              />
            </el-form-item>

            <el-form-item label="确认密码" prop="confirmPassword">
              <el-input
                v-model="form.confirmPassword"
                type="password"
                show-password
                placeholder="请再次输入密码"
                size="large"
                prefix-icon="Lock"
                autocomplete="new-password"
              />
            </el-form-item>

            <el-form-item>
              <el-checkbox v-model="agreed">
                我已阅读并同意
                <a href="#" @click.prevent class="link">《用户协议》</a>
                和
                <a href="#" @click.prevent class="link">《隐私政策》</a>
              </el-checkbox>
            </el-form-item>

            <el-button
              type="primary"
              size="large"
              class="submit-btn"
              :loading="loading"
              :disabled="!agreed"
              @click="handleRegister"
            >
              立即注册
            </el-button>

            <div class="form-footer">
              <router-link to="/" class="back-home">
                <el-icon><HomeFilled /></el-icon>
                返回首页
              </router-link>
            </div>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { CircleCheck, HomeFilled } from '@element-plus/icons-vue'
import { register, sendCode as sendCodeApi } from '@/api/user'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref<FormInstance>()
const loading = ref(false)
const countdown = ref(0)
const agreed = ref(false)

const features = [
  { text: '海量精品课程免费学习' },
  { text: 'AI智能学习助手随时答疑' },
  { text: '个性化学习路径规划' },
  { text: '随时随地移动端学习' }
]

const form = reactive({
  mobile: '',
  nickname: '',
  code: '',
  password: '',
  confirmPassword: ''
})

const validateConfirmPwd = (_rule: any, value: string, callback: Function) => {
  if (value !== form.password) callback(new Error('两次密码不一致'))
  else callback()
}

const rules = {
  mobile: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入有效的手机号', trigger: 'blur' }
  ],
  nickname: [
    { required: true, message: '请输入昵称', trigger: 'blur' },
    { min: 2, max: 10, message: '昵称2-10位', trigger: 'blur' }
  ],
  code: [
    { required: true, message: '请输入验证码', trigger: 'blur' },
    { len: 6, message: '验证码为6位', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码6-20位', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    { validator: validateConfirmPwd, trigger: 'blur' }
  ]
}

async function sendCode() {
  if (!/^1[3-9]\d{9}$/.test(form.mobile)) {
    ElMessage.warning('请输入有效手机号')
    return
  }
  try {
    await sendCodeApi(form.mobile)
    ElMessage.success('验证码已发送，请查看后端控制台日志！')
    countdown.value = 60
    const timer = setInterval(() => {
      countdown.value--
      if (countdown.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (e: any) {
    ElMessage.error(e.message || '发送失败')
  }
}

async function handleRegister() {
  // 先做表单校验，校验不通过直接返回，不弹额外提示
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  loading.value = true
  try {
    const res = await register({
      mobile: form.mobile,
      nickname: form.nickname,
      code: form.code,
      password: form.password
    })
    if (res.data?.token) {
      userStore.token = res.data.token
      userStore.userInfo = res.data.userInfo
      localStorage.setItem('token', res.data.token)
      ElMessage.success('注册成功，欢迎加入！')
      router.push('/')
    }
  } catch (e: any) {
    ElMessage.error(e.message || '注册失败，请重试')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.register-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ecfeff;
}

.page-wrap {
  display: flex;
  width: 100%;
  max-width: 960px;
  min-height: 600px;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 32px 80px rgba(8, 145, 178, 0.15);
}

.brand-side {
  flex: 1;
  background: #0891b2;
  padding: 48px 40px;
  color: #fff;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;

  .logo-wrap {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    margin-bottom: 32px;
    .logo { height: 40px; width: 40px; }
    .site-name { color: #fff; font-size: 20px; font-weight: 700; }
  }

  .brand-slogan { font-size: 28px; font-weight: 700; margin: 0 0 12px; line-height: 1.3; }
  .brand-desc { font-size: 14px; opacity: 0.85; margin: 0 0 32px; line-height: 1.7; }

  .feature-list { display: flex; flex-direction: column; gap: 12px; }
  .feature-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    opacity: 0.95;

    .el-icon {
      color: #cffafe;
    }
  }

  .bg-img {
    position: absolute;
    bottom: 0;
    right: -20px;
    width: 55%;
    opacity: 0.25;
  }
}

.form-side {
  width: 400px;
  background: #fff;
  padding: 40px 36px;
  overflow-y: auto;
}

.form-card {
  .form-title { font-size: 26px; font-weight: 700; color: #1f2329; margin: 0 0 8px; }
  .form-subtitle {
    font-size: 14px;
    color: #646464;
    margin: 0 0 28px;
    a { color: #0891b2; text-decoration: none; font-weight: 500; &:hover { text-decoration: underline; } }
  }
}

.code-wrap {
  display: flex;
  gap: 10px;
  .send-code-btn {
    white-space: nowrap;
    min-width: 120px;
    background: #f0fdfa;
    border-color: #0891b2;
    color: #0891b2;
    &:hover { background: #0891b2; color: #fff; }
    &.is-disabled { background: #f5f5f5; border-color: #d9d9d9; color: #999; }
  }
}

.link { color: #0891b2; text-decoration: none; font-weight: 500; &:hover { text-decoration: underline; } }

.submit-btn {
  width: 100%;
  height: 48px;
  font-size: 16px;
  font-weight: 600;
  background: #0891b2;
  border: none;
  border-radius: 10px;
  margin-top: 8px;
  transition: all 0.3s;
  &:hover { background: #0e7490; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(8, 145, 178, 0.4); }
  &:active { transform: translateY(0); }
}

.form-footer {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;

  .back-home {
    display: flex;
    align-items: center;
    gap: 4px;
    color: #646464;
    font-size: 14px;
    text-decoration: none;
    transition: color 0.2s;
    &:hover { color: #0891b2; }
  }
}
</style>
