<template>
  <div class="course-detail">
    <div v-if="loading" class="loading">
      <el-skeleton :rows="10" animated />
    </div>

    <template v-else-if="course">
      <!-- 课程头部 -->
      <div class="detail-header">
        <div class="container">
          <div class="header-content">
            <div class="course-info">
              <div class="breadcrumb">
                <router-link to="/">首页</router-link>
                <span> / </span>
                <router-link to="/courses">课程</router-link>
                <span> / </span>
                <span>{{ course.categoryName }}</span>
              </div>
              <h1>{{ course.title }}</h1>
              <p class="sub-title">{{ course.subTitle }}</p>
              <div class="meta-row">
                <el-rate :model-value="course.score" disabled size="small" />
                <span class="score">{{ course.score?.toFixed(1) }}</span>
                <span class="comment-count">({{ course.commentCount }}条评价)</span>
                <span class="study-count">{{ course.studyCount?.toLocaleString() }}人在学</span>
              </div>
              <div class="teacher-info">
                <el-avatar :src="teacher?.avatar" :size="40">
                  {{ teacher?.name?.[0] }}
                </el-avatar>
                <span>{{ teacher?.name }}</span>
              </div>
            </div>

            <div class="buy-card">
              <div class="cover">
                <img :src="course.cover || defaultCover" :alt="course.title" @error="handleImgError" />
              </div>
              <div class="price-area">
                <template v-if="course.isFree">
                  <span class="price free">免费</span>
                </template>
                <template v-else>
                  <span class="price">¥{{ course.price }}</span>
                  <span v-if="course.originalPrice > course.price" class="original">
                    ¥{{ course.originalPrice }}
                  </span>
                </template>
              </div>
              <div class="actions">
                <template v-if="course.isPurchased || course.isFree">
                  <el-button
                    :type="courseFinished ? 'info' : 'success'"
                    size="large"
                    block
                    @click="startLearn"
                  >
                    {{ courseFinished ? '已学完' : (recentVideoId ? '继续学习' : '开始学习') }}
                  </el-button>
                  <el-button
                    v-if="courseFinished"
                    type="warning"
                    size="large"
                    block
                    @click="showCert = true"
                  >
                    查看证书
                  </el-button>
                </template>
                <template v-else>
                  <el-button type="danger" size="large" block @click="toBuy">
                    立即购买
                  </el-button>
                </template>
                <el-button
                  :type="course.isFavorite ? 'warning' : 'default'"
                  size="large"
                  block
                  @click="toggleFav"
                >
                  {{ course.isFavorite ? '已收藏' : '收藏课程' }}
                </el-button>
              </div>
              <div class="course-stats">
                <div><el-icon><VideoCamera /></el-icon> {{ course.chapterCount }}章节</div>
                <div><el-icon><Clock /></el-icon> {{ Math.floor(course.duration / 60) }}小时</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 课程内容 -->
      <div class="container detail-body">
        <el-tabs>
          <el-tab-pane label="课程大纲">
            <div class="outline">
              <el-collapse>
                <el-collapse-item
                  v-for="chapter in chapters"
                  :key="chapter.id"
                  :title="`${chapter.title} (${chapter.videos?.length}节)`"
                  :name="chapter.id"
                >
                  <div
                    v-for="video in chapter.videos"
                    :key="video.id"
                    class="video-item"
                    @click="playVideo(video)"
                  >
                    <el-icon><VideoPlay /></el-icon>
                    <span class="video-title">{{ video.title }}</span>
                    <span class="duration">{{ formatDuration(video.duration) }}</span>
                    <el-tag v-if="video.isFree" size="small" type="success">免费</el-tag>
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </el-tab-pane>

          <el-tab-pane label="课程介绍">
            <div class="description">
              <p>{{ course.description }}</p>
              <div v-if="course.detail" v-html="course.detail" class="rich-text"></div>
            </div>
          </el-tab-pane>

          <el-tab-pane :label="`评价 (${course.commentCount})`">
            <CommentList :course-id="course.id" :is-purchased="course.isPurchased" :is-free="course.isFree" @comment-added="loadCourseDetail" />
          </el-tab-pane>
        </el-tabs>
      </div>
    </template>

    <!-- 学习证书弹窗 -->
    <CertificateView
      v-model="showCert"
      :course-id="Number(route.params.id)"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getCourseDetail, toggleFavorite, getRecentCourses, getCheckinStats, getFavorites } from '@/api/course'
import { useUserStore } from '@/stores/user'
import { defaultCourseCover as defaultCover } from '@/utils/placeholder'
import { ElMessage } from 'element-plus'
import { VideoCamera, Clock, VideoPlay } from '@element-plus/icons-vue'
import CommentList from '@/components/course/CommentList.vue'
import CertificateView from '@/components/certificate/CertificateView.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const course = ref<any>(null)
const teacher = ref<any>(null)
const chapters = ref<any[]>([])
const loading = ref(true)
const showCert = ref(false)
const courseFinished = ref(false)

// 处理图片加载失败
const handleImgError = (e: Event) => {
  const img = e.target as HTMLImageElement
  img.src = defaultCover
}

const recentVideoId = ref<number | null>(null)

onMounted(async () => {
  try {
    const courseId = Number(route.params.id)
    const res = await getCourseDetail(courseId)
    // 后端返回 { course: {...}, teacher: {...}, chapters: [...] }
    course.value = res.data.course || res.data
    teacher.value = res.data.teacher || null
    chapters.value = res.data.chapters || []

    // 查询当前课程是否已收藏
    try {
      const favRes = await getFavorites()
      const favList = favRes.data || []
      course.value.isFavorite = favList.some((c: any) => c.id === courseId)
    } catch (e) {
      console.log('获取收藏状态失败', e)
    }

    // 获取用户最近学习的视频（针对当前课程）
    try {
      const recentRes = await getRecentCourses(10)
      const recentCourses = recentRes.data || []
      // 找到当前课程最近学习的视频
      const recentCourse = recentCourses.find((c: any) => c.id === courseId)
      if (recentCourse?.lastStudyVideoId) {
        recentVideoId.value = recentCourse.lastStudyVideoId
        console.log('当前课程最近学习视频:', recentVideoId.value)
      }
      // 检查课程是否已完成
      if (recentCourse?.progress >= 100) {
        courseFinished.value = true
      }
    } catch (e) {
      console.log('获取最近学习记录失败:', e)
    }
  } catch (error: any) {
    // 课程不存在或已下架，自动跳转首页
    console.log('课程加载失败:', error)
    ElMessage.warning('课程不存在或已下架，即将返回首页')
    setTimeout(() => {
      router.push('/')
    }, 1500)
  } finally {
    loading.value = false
  }
})

const startLearn = () => {
  // 优先跳转到上次学习的视频，否则跳转到第一个视频
  let targetVideoId = recentVideoId.value
  if (!targetVideoId) {
    const firstVideo = chapters.value?.[0]?.videos?.[0]
    targetVideoId = firstVideo?.id
  }
  if (targetVideoId) {
    router.push(`/learn/${course.value.id}/video/${targetVideoId}`)
  } else {
    ElMessage.warning('暂无可学习的视频')
  }
}

const toBuy = () => {
  if (!userStore.isLoggedIn) {
    router.push({ name: 'Login', query: { redirect: route.fullPath } })
    return
  }
  // 使用 query 参数传递 courseId，与订单列表页保持一致
  router.push({ path: '/pay/order', query: { courseId: course.value.id } })
}

const toggleFav = async () => {
  if (!userStore.isLoggedIn) {
    router.push({ name: 'Login' })
    return
  }
  const res = await toggleFavorite(course.value.id)
  course.value.isFavorite = res.data
  ElMessage.success(res.data ? '收藏成功' : '已取消收藏')
}

const playVideo = (video: any) => {
  if (video.isFree || course.value.isPurchased || course.value.isFree) {
    router.push(`/learn/${course.value.id}/video/${video.id}`)
  } else {
    ElMessage.warning('请先购买课程')
    toBuy()
  }
}

const formatDuration = (seconds: number) => {
  if (!seconds) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${String(s).padStart(2, '0')}`
}
</script>

<style lang="scss" scoped>
.detail-header {
  background: linear-gradient(135deg, #0f172a, #164e63);
  color: #fff;
  padding: 40px 0;
}

.container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
}

.header-content {
  display: flex;
  gap: 40px;
  align-items: flex-start;
}

.course-info {
  flex: 1;
}

.breadcrumb {
  font-size: 13px;
  color: rgba(255,255,255,0.6);
  margin-bottom: 16px;

  a { color: rgba(255,255,255,0.7); text-decoration: none; &:hover { color: #fff; } }
}

h1 {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 12px;
  line-height: 1.3;
}

.sub-title {
  font-size: 16px;
  color: rgba(255,255,255,0.75);
  margin-bottom: 16px;
}

.meta-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  margin-bottom: 16px;
  .score { color: #f59e0b; }
  .comment-count, .study-count { color: rgba(255,255,255,0.65); }
}

.teacher-info {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;
  color: rgba(255,255,255,0.85);
}

.buy-card {
  width: 340px;
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(0,0,0,0.2);
  flex-shrink: 0;
  color: #333;

  .cover img { width: 100%; aspect-ratio: 16/9; object-fit: cover; }

  .price-area {
    padding: 16px 20px 8px;
    display: flex;
    align-items: baseline;
    gap: 8px;
  }

  .price { font-size: 28px; font-weight: 700; color: #e53e3e; }
  .price.free { color: #ff6b35; }
  .original { font-size: 16px; text-decoration: line-through; color: #bbb; }

  .actions {
    padding: 0 20px 16px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .course-stats {
    padding: 12px 20px;
    border-top: 1px solid #f0f0f0;
    display: flex;
    gap: 20px;
    font-size: 13px;
    color: #666;

    > div { display: flex; align-items: center; gap: 4px; }
  }
}

.detail-body {
  padding-top: 32px;
  padding-bottom: 48px;
}

.video-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  cursor: pointer;
  border-radius: 6px;
  font-size: 14px;
  transition: background 0.2s;

  &:hover { background: #f5f7fa; }

  .video-title { flex: 1; }
  .duration { color: #999; font-size: 12px; }
}

.loading { padding: 40px; }
</style>
