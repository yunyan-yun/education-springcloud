<template>
  <div class="course-list-page">
    <!-- 顶部Banner -->
    <div class="page-header">
      <div class="header-content">
        <h1>全部课程</h1>
        <p>发现适合自己的优质课程</p>
      </div>
    </div>

    <div class="container">
      <!-- 筛选栏 -->
      <div class="filter-bar">
        <div class="filter-left">
          <el-select v-model="categoryId" placeholder="全部分类" clearable @change="fetchCourses">
            <el-option label="全部分类" :value="undefined" />
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
          <el-select v-model="isFree" placeholder="课程类型" clearable @change="fetchCourses">
            <el-option label="全部" :value="undefined" />
            <el-option label="免费课程" :value="1" />
            <el-option label="付费课程" :value="0" />
          </el-select>
        </div>
        <div class="filter-right">
          <el-input v-model="keyword" placeholder="搜索课程..." clearable @keyup.enter="fetchCourses" style="width: 200px">
            <template #append>
              <el-button :icon="Search" @click="fetchCourses" />
            </template>
          </el-input>
        </div>
      </div>

      <!-- 排序 -->
      <div class="sort-bar">
        <span class="sort-label">排序：</span>
        <el-radio-group v-model="sortBy" @change="fetchCourses">
          <el-radio-button label="">综合</el-radio-button>
          <el-radio-button label="latest">最新</el-radio-button>
          <el-radio-button label="hot">热门</el-radio-button>
          <el-radio-button label="price_asc">价格从低到高</el-radio-button>
          <el-radio-button label="price_desc">价格从高到低</el-radio-button>
        </el-radio-group>
      </div>

      <!-- 课程列表 -->
      <div v-loading="loading" class="course-grid">
        <div v-if="!loading && courses.length === 0" class="empty-state">
          <el-empty description="暂无课程" />
        </div>
        <CourseCard v-for="course in courses" :key="course.id" :course="course" />
      </div>

      <!-- 分页 -->
      <div v-if="total > 0" class="pagination">
        <el-pagination
          v-model:current-page="current"
          :page-size="size"
          :total="total"
          layout="prev, pager, next"
          @current-change="handlePageChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { Search } from '@element-plus/icons-vue'
import { getCategories, searchCourses } from '@/api/course'
import CourseCard from '@/components/course/CourseCard.vue'

const route = useRoute()
const loading = ref(false)
const courses = ref<any[]>([])
const categories = ref<any[]>([])
const categoryId = ref<number>()
const isFree = ref<number>()
const keyword = ref('')
const sortBy = ref('')
const current = ref(1)
const size = ref(12)
const total = ref(0)

const fetchCourses = async () => {
  loading.value = true
  try {
    const res = await searchCourses({
      keyword: keyword.value || undefined,
      categoryId: categoryId.value,
      isFree: isFree.value,
      sortBy: sortBy.value || undefined,
      current: current.value,
      size: size.value,
    })
    courses.value = res.data.records || []
    total.value = res.data.total || 0
  } finally {
    loading.value = false
  }
}

const fetchCategories = async () => {
  const res = await getCategories()
  categories.value = res.data || []
}

const handlePageChange = (page: number) => {
  current.value = page
  fetchCourses()
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

onMounted(async () => {
  // 从 URL 参数读取分类 ID
  const cid = route.query.categoryId
  if (cid) {
    categoryId.value = Number(cid)
  }
  await fetchCategories()
  fetchCourses()
})
</script>

<style scoped lang="scss">
.page-header {
  background: #0891b2;
  color: white;
  padding: 60px 0;
  text-align: center;
  .header-content {
    h1 { font-size: 36px; margin-bottom: 10px; }
    p { font-size: 18px; opacity: 0.9; }
  }
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 30px 20px;
}

.filter-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  .filter-left { display: flex; gap: 10px; }
}

.sort-bar {
  margin-bottom: 30px;
  .sort-label { color: #666; margin-right: 10px; }
}

.course-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  min-height: 400px;
}

.empty-state {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 60px 0;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}

@media (max-width: 1024px) {
  .course-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 768px) {
  .course-grid { grid-template-columns: repeat(2, 1fr); }
  .filter-bar { flex-direction: column; gap: 10px; }
}
</style>
