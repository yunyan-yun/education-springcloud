<template>
  <div class="search-page">
    <div class="container">
      <!-- 搜索头部 -->
      <div class="search-header">
        <h2>
          <template v-if="keyword">搜索 "{{ keyword }}" 的结果</template>
          <template v-else>全部课程</template>
        </h2>
        <span class="total">共 {{ total }} 门课程</span>
      </div>

      <div class="search-body">
        <!-- 筛选侧边栏 -->
        <aside class="filters">
          <div class="filter-group">
            <div class="filter-title">课程类别</div>
            <div
              v-for="cat in categories"
              :key="cat.id"
              class="filter-item"
              :class="{ active: activeCategoryId == cat.id }"
              @click="selectCategory(cat.id)"
            >
              {{ cat.name }}
            </div>
          </div>
          <div class="filter-group">
            <div class="filter-title">价格</div>
            <div class="filter-item" :class="{ active: isFree === undefined }" @click="isFree = undefined; load()">全部</div>
            <div class="filter-item" :class="{ active: isFree === 1 }" @click="isFree = 1; load()">免费</div>
            <div class="filter-item" :class="{ active: isFree === 0 }" @click="isFree = 0; load()">付费</div>
          </div>
        </aside>

        <!-- 课程列表 -->
        <div class="results">
          <!-- 排序栏 -->
          <div class="sort-bar">
            <span
              v-for="s in sortOptions"
              :key="s.value"
              class="sort-item"
              :class="{ active: sortBy === s.value }"
              @click="sortBy = s.value; load()"
            >{{ s.label }}</span>
          </div>

          <div v-if="loading" class="courses-grid">
            <el-skeleton v-for="i in 8" :key="i" animated>
              <template #template>
                <el-skeleton-item variant="image" style="height: 160px; border-radius: 8px;" />
                <div style="padding: 12px 0;">
                  <el-skeleton-item variant="h3" style="width: 80%;" />
                  <el-skeleton-item variant="text" style="width: 50%;" />
                </div>
              </template>
            </el-skeleton>
          </div>

          <div v-else-if="courses.length" class="courses-grid">
            <CourseCard v-for="course in courses" :key="course.id" :course="course" />
          </div>
          <el-empty v-else description="没有找到相关课程" />

          <el-pagination
            v-if="total > 0"
            layout="prev, pager, next"
            :total="total"
            :page-size="pageSize"
            v-model:current-page="currentPage"
            @current-change="load"
            class="pagination"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { searchCourses, getCategories } from '@/api/course'
import CourseCard from '@/components/course/CourseCard.vue'

const route = useRoute()
const keyword = ref(route.query.keyword as string || '')
const courses = ref<any[]>([])
const categories = ref<any[]>([])
const total = ref(0)
const loading = ref(false)
const activeCategoryId = ref<number | undefined>()
const isFree = ref<number | undefined>()
const sortBy = ref('newest')
const currentPage = ref(1)
const pageSize = 12

const sortOptions = [
  { label: '最新', value: 'newest' },
  { label: '最热', value: 'hottest' },
  { label: '评分', value: 'score' },
]

onMounted(async () => {
  const res = await getCategories()
  categories.value = (res.data || []).filter((c: any) => c.parentId === 0)
  load()
})

watch(() => route.query.keyword, (v) => {
  keyword.value = v as string || ''
  load()
})

const selectCategory = (id: number) => {
  activeCategoryId.value = activeCategoryId.value === id ? undefined : id
  load()
}

const load = async () => {
  loading.value = true
  try {
    const res = await searchCourses({
      keyword: keyword.value || undefined,
      categoryId: activeCategoryId.value,
      sortBy: sortBy.value,
      isFree: isFree.value,
      current: currentPage.value,
      size: pageSize,
    })
    courses.value = res.data.records || []
    total.value = res.data.total || 0
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped>
.container { max-width: 1280px; margin: 0 auto; padding: 0 24px; }

.search-header {
  padding: 24px 0 16px;
  display: flex;
  align-items: center;
  gap: 16px;
  h2 { font-size: 22px; }
  .total { color: #888; font-size: 14px; }
}

.search-body { display: flex; gap: 24px; padding-bottom: 48px; }

.filters {
  width: 200px;
  flex-shrink: 0;
}

.filter-group { margin-bottom: 24px; }
.filter-title { font-weight: 600; margin-bottom: 8px; color: #333; }
.filter-item {
  padding: 6px 10px;
  cursor: pointer;
  border-radius: 6px;
  color: #555;
  font-size: 14px;
  transition: all 0.2s;

  &:hover { background: #f0f4ff; color: var(--el-color-primary); }
  &.active { background: #e6f0ff; color: var(--el-color-primary); font-weight: 600; }
}

.results { flex: 1; min-width: 0; }

.sort-bar {
  display: flex;
  gap: 4px;
  margin-bottom: 16px;
  border-bottom: 1px solid #eee;
  padding-bottom: 12px;
}

.sort-item {
  padding: 4px 16px;
  cursor: pointer;
  border-radius: 20px;
  font-size: 14px;
  color: #666;
  transition: all 0.2s;
  &:hover { color: var(--el-color-primary); }
  &.active { background: var(--el-color-primary); color: #fff; }
}

.courses-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  @media (max-width: 1100px) { grid-template-columns: repeat(3, 1fr); }
  @media (max-width: 800px) { grid-template-columns: repeat(2, 1fr); }
}

.pagination { margin-top: 32px; display: flex; justify-content: center; }
</style>
