<template>
  <div class="home">
    <!-- 轮播图 -->
    <section class="banner-section">
      <el-carousel height="400px" :interval="5000" arrow="always">
        <el-carousel-item v-for="banner in banners" :key="banner.id">
          <a :href="banner.linkUrl || '#'">
            <img :src="banner.imageUrl" :alt="banner.title" class="banner-img" @error="handleImgError" />
          </a>
        </el-carousel-item>
      </el-carousel>
    </section>

    <!-- 课程分类导航 -->
    <section class="category-section">
      <div class="container">
        <div class="category-grid">
          <router-link
            v-for="cat in rootCategories"
            :key="cat.id"
            :to="`/courses?categoryId=${cat.id}`"
            class="category-item"
          >
            <div class="cat-icon">{{ cat.icon || '📚' }}</div>
            <span>{{ cat.name }}</span>
          </router-link>
        </div>
      </div>
    </section>

    <!-- 推荐课程 -->
    <section class="courses-section">
      <div class="container">
        <div class="section-header">
          <h2>推荐课程</h2>
          <router-link to="/courses?sortBy=recommend" class="view-all">查看全部 →</router-link>
        </div>
        <div class="courses-grid">
          <CourseCard v-for="course in recommendCourses" :key="course.id" :course="course" />
        </div>
      </div>
    </section>

    <!-- 热门课程 -->
    <section class="courses-section bg-light">
      <div class="container">
        <div class="section-header">
          <h2>热门课程</h2>
          <router-link to="/courses?sortBy=hottest" class="view-all">查看全部 →</router-link>
        </div>
        <div class="courses-grid">
          <CourseCard v-for="course in hotCourses" :key="course.id" :course="course" />
        </div>
      </div>
    </section>

    <!-- 最新课程 -->
    <section class="courses-section">
      <div class="container">
        <div class="section-header">
          <h2>最新课程</h2>
          <router-link to="/courses?sortBy=newest" class="view-all">查看全部 →</router-link>
        </div>
        <div class="courses-grid">
          <CourseCard v-for="course in latestCourses" :key="course.id" :course="course" />
        </div>
      </div>
    </section>


  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { getBanners, getCategories, getRecommendCourses, getHotCourses, getLatestCourses } from '@/api/course'
import CourseCard from '@/components/course/CourseCard.vue'

import { defaultBanner, defaultCourseCover } from '@/utils/placeholder'

const banners = ref<any[]>([])
const categories = ref<any[]>([])
const recommendCourses = ref<any[]>([])
const hotCourses = ref<any[]>([])
const latestCourses = ref<any[]>([])

// 处理图片加载失败
const handleImgError = (e: Event) => {
  const img = e.target as HTMLImageElement
  if (img.src !== defaultBanner) {
    img.src = defaultBanner
  }
}

// 获取带默认值的课程封面
const getCourseCover = (course: any, index: number) => {
  return course.cover || `${defaultCourseCover}${course.id || index}`
}

// 确保课程有正确的封面
const ensureCourseCover = (course: any) => {
  if (!course.cover) {
    course.cover = `${defaultCourseCover}${course.id}`
  }
  return course
}

const rootCategories = computed(() =>
  categories.value.filter((c: any) => c.parentId === 0 || !c.parentId).slice(0, 10)
)

onMounted(async () => {
  const [b, c, r, h, l] = await Promise.allSettled([
    getBanners(),
    getCategories(),
    getRecommendCourses(),
    getHotCourses(),
    getLatestCourses(),
  ])
  if (b.status === 'fulfilled') banners.value = b.value.data || []
  if (c.status === 'fulfilled') categories.value = c.value.data || []
  if (r.status === 'fulfilled') recommendCourses.value = (r.value.data || []).map(ensureCourseCover)
  if (h.status === 'fulfilled') hotCourses.value = (h.value.data || []).map(ensureCourseCover)
  if (l.status === 'fulfilled') latestCourses.value = (l.value.data || []).map(ensureCourseCover)
})
</script>

<style lang="scss" scoped>
.home {
  background: #fff;
}

.banner-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
}

.category-section {
  padding: 32px 0;
  background: #f8f9fa;
}

.category-grid {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  justify-content: center;
}

.category-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px 20px;
  background: #fff;
  border-radius: 12px;
  text-decoration: none;
  color: #333;
  font-size: 14px;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  min-width: 90px;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(64,158,255,0.15);
    color: var(--el-color-primary);
  }

  .cat-icon { font-size: 28px; }
}

.courses-section {
  padding: 48px 0;

  &.bg-light { background: #f8f9fa; }
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;

  h2 {
    font-size: 24px;
    font-weight: 600;
    color: #1a1a1a;
  }

  .view-all {
    color: var(--el-color-primary);
    text-decoration: none;
    font-size: 14px;
    &:hover { text-decoration: underline; }
  }
}

.courses-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;

  @media (max-width: 1200px) { grid-template-columns: repeat(3, 1fr); }
  @media (max-width: 768px) { grid-template-columns: repeat(2, 1fr); }
  @media (max-width: 480px) { grid-template-columns: 1fr; }
}


</style>
