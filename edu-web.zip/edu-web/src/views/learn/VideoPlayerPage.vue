<template>
  <div class="player-page">
    <!-- 顶部导航栏 -->
    <header class="top-nav">
      <div class="nav-left">
        <el-button text @click="goBack">
          <el-icon><ArrowLeft /></el-icon>
          返回课程详情
        </el-button>
      </div>
      <div class="nav-center">
        <h1>{{ courseName }}</h1>
      </div>
      <div class="nav-right">
        <el-dropdown trigger="click">
          <div class="user-info">
            <el-avatar :size="32" :src="userStore.avatar || undefined">
              {{ userStore.nickname?.charAt(0) || '用' }}
            </el-avatar>
            <span class="username">{{ userStore.nickname || '用户' }}</span>
            <el-icon><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item @click="goToUserCenter">个人中心</el-dropdown-item>
              <el-dropdown-item @click="goToMyCourse">我的课程</el-dropdown-item>
              <el-dropdown-item @click="goToMyFavorites">我的收藏</el-dropdown-item>
              <el-dropdown-item @click="goToMyOrders">我的订单</el-dropdown-item>
              <el-dropdown-item @click="goToHome">返回首页</el-dropdown-item>
              <el-dropdown-item divided @click="goToProfile">账号设置</el-dropdown-item>
              <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </header>

    <!-- 主体内容 -->
    <div class="main-content">
      <!-- 左侧：视频播放器 -->
      <div class="player-container">
        <div class="video-wrapper">
          <video
            ref="videoRef"
            class="video-js vjs-default-skin"
            controls
            preload="auto"
            :poster="currentVideo?.cover"
          ></video>
        </div>

        <div class="video-info">
          <h2>{{ currentVideo?.title }}</h2>
          <div class="actions">
            <el-button size="small" @click="toggleFav">
              <el-icon><Star /></el-icon>
              {{ isFavorite ? '已收藏' : '收藏' }}
            </el-button>
            <el-button size="small" @click="showAiPanel = true">
              <el-icon><ChatDotRound /></el-icon> AI答疑
            </el-button>
            <el-button size="small" type="warning" @click="openQuiz">
              <el-icon><EditPen /></el-icon> 章节测验
            </el-button>
          </div>
        </div>
      </div>

      <!-- 右侧：课程大纲/学习笔记 -->
      <div class="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-tabs">
            <span :class="['tab', { active: sidebarTab === 'outline' }]" @click="sidebarTab = 'outline'">课程目录</span>
            <span :class="['tab', { active: sidebarTab === 'notes' }]" @click="sidebarTab = 'notes'">学习笔记</span>
            <span class="progress-text">{{ completedCount }}/{{ totalCount }}</span>
          </div>
        </div>
        <div class="outline-scroll" v-show="sidebarTab === 'outline'">
          <template v-for="chapter in chapters" :key="chapter.id">
            <div class="chapter-title">{{ chapter.title }}</div>
            <div
              v-for="video in chapter.videos"
              :key="video.id"
              class="video-item"
              :class="{
                active: video.id == Number(route.params.videoId),
                locked: (!video.isFree && !isPurchased) || isVideoLocked(video.id),
                'quiz-locked': isVideoLocked(video.id),
              }"
              @click="switchVideo(video.id, video)"
            >
              <el-icon v-if="progress[video.id]?.finished" color="#52c41a"><CircleCheckFilled /></el-icon>
              <el-icon v-else-if="isVideoLocked(video.id)" color="#e6a23c"><Edit /></el-icon>
              <el-icon v-else-if="!video.isFree && !isPurchased" color="#f0a020"><Lock /></el-icon>
              <el-icon v-else><VideoPlay /></el-icon>
              <span class="v-title">{{ video.title }}</span>
              <span v-if="video.isFree && !isVideoLocked(video.id)" class="free-tag">免费</span>
              <span v-else-if="isVideoLocked(video.id)" class="quiz-tag">待测验</span>
            </div>
          </template>
        </div>
        <div class="note-scroll" v-show="sidebarTab === 'notes'">
          <NotePanel
            :video-id="Number(route.params.videoId)"
            :course-id="Number(route.params.courseId)"
            :chapter-id="currentChapterId"
          />
        </div>
      </div>
    </div>

    <!-- 底部控制栏 -->
    <footer class="bottom-bar">
      <div class="prev-btn" @click="goPrev" :class="{ disabled: !prevVideo }">
        <el-icon><ArrowLeft /></el-icon>
        <span v-if="prevVideo">{{ prevVideo.title }}</span>
        <span v-else>没有上一节了</span>
      </div>
      <div class="progress-center">
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: progressPercent + '%' }"></div>
        </div>
        <span class="progress-label">学习进度 {{ currentIndex + 1 }}/{{ totalCount }}</span>
      </div>
      <div class="next-btn" @click="goNext" :class="{ disabled: !nextVideo }">
        <span v-if="nextVideo">{{ nextVideo.title }}</span>
        <span v-else>没有下一节了</span>
        <el-icon><ArrowRight /></el-icon>
      </div>
    </footer>

    <!-- AI 答疑抽屉 -->
    <el-drawer v-model="showAiPanel" title="AI答疑助手" size="400px" direction="rtl">
      <AiChatPanel
        :session-id="`course-${route.params.courseId}`"
        :current-video-title="currentVideo?.title || ''"
        :current-chapter-title="currentChapterTitle"
        :current-video-description="currentVideo?.description || ''"
        :current-chapter-description="currentChapterDescription"
        :current-course-name="courseName"
      />
    </el-drawer>

    <!-- 视频测验弹窗 -->
    <QuizPanel
      v-model="showQuiz"
      :video-id="Number(route.params.videoId)"
      :video-title="currentVideo?.title || ''"
      @submitted="onQuizSubmitted"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import videojs from 'video.js'
import 'video.js/dist/video-js.css'
import { getCourseDetail, getPlayUrl, recordProgress, getProgress, getCheckinStats, getQuizPassedStatus, toggleFavorite, getFavorites } from '@/api/course'
import { Star, ChatDotRound, VideoPlay, CircleCheckFilled, ArrowLeft, ArrowRight, ArrowDown, Lock, EditPen, Edit } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/stores/user'
import AiChatPanel from '@/components/ai/AiChatPanel.vue'
import NotePanel from '@/components/note/NotePanel.vue'
import QuizPanel from '@/components/quiz/QuizPanel.vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const videoRef = ref<HTMLVideoElement>()
let player: any = null

const chapters = ref<any[]>([])
const currentVideo = ref<any>(null)
const isFavorite = ref(false)
const showAiPanel = ref(false)
const showQuiz = ref(false)
const sidebarTab = ref('outline')
const progress = ref<Record<number, any>>({})
const courseName = ref('')
const isPurchased = ref(false)  // 用户是否已购买该课程
const hasNotifiedCheckin = ref(false) // 今日是否已弹出打卡提示
const quizPassed = ref<Record<number, boolean>>({}) // 各视频测验是否通过

let progressTimer: number | null = null

// 所有视频扁平化列表
const allVideos = computed(() => {
  const videos: any[] = []
  chapters.value.forEach(chapter => {
    if (chapter.videos) {
      videos.push(...chapter.videos)
    }
  })
  return videos
})

// 当前视频索引
const currentIndex = computed(() => {
  return allVideos.value.findIndex(v => v.id == Number(route.params.videoId))
})

// 上一节
const prevVideo = computed(() => {
  const idx = currentIndex.value
  return idx > 0 ? allVideos.value[idx - 1] : null
})

// 下一节
const nextVideo = computed(() => {
  const idx = currentIndex.value
  return idx < allVideos.value.length - 1 ? allVideos.value[idx + 1] : null
})

// 判断视频是否被锁定（需答完前置视频的测验才能解锁）
// 规则：第一个视频始终解锁；后续视频需要前置视频看完+（有测验则答完且通过）
const isVideoLocked = (videoId: number): boolean => {
  const idx = allVideos.value.findIndex(v => v.id === videoId)
  if (idx <= 0) return false // 第一个视频始终解锁

  // 付费且未购买
  const video = allVideos.value[idx]
  if (video && !video.isFree && !isPurchased.value) return false // 付费锁定由另一层逻辑处理

  // 检查前置视频：看完
  const prevVid = allVideos.value[idx - 1].id
  const prevFinished = progress.value[prevVid]?.finished === 1 || progress.value[prevVid]?.finished === true
  if (!prevFinished) return true

  // 前置视频有测验但未通过（undefined表示没有测验题，直接放行）
  if (quizPassed.value[prevVid] === false) return true

  return false
}

// 获取锁定原因提示文案
const getVideoLockReason = (videoId: number): string => {
  const idx = allVideos.value.findIndex(v => v.id === videoId)
  if (idx <= 0) return ''
  const prevVid = allVideos.value[idx - 1].id
  const prevFinished = progress.value[prevVid]?.finished === 1 || progress.value[prevVid]?.finished === true

  if (!prevFinished) {
    return `请先完成「${allVideos.value[idx - 1].title}」`
  }
  if (quizPassed.value[prevVid] === false) {
    return `请先通过「${allVideos.value[idx - 1].title}」的章节测验`
  }
  return ''
}

// 当前章节ID
const currentChapterId = computed(() => {
  for (const ch of chapters.value) {
    if (ch.videos?.some((v: any) => v.id == Number(route.params.videoId))) {
      return ch.id
    }
  }
  return 0
})

// 当前章节标题
const currentChapterTitle = computed(() => {
  for (const ch of chapters.value) {
    if (ch.videos?.some((v: any) => v.id == Number(route.params.videoId))) {
      return ch.title
    }
  }
  return ''
})

// 当前章节描述
const currentChapterDescription = computed(() => {
  for (const ch of chapters.value) {
    if (ch.videos?.some((v: any) => v.id == Number(route.params.videoId))) {
      return ch.description || ''
    }
  }
  return ''
})

// 视频总数
const totalCount = computed(() => allVideos.value.length)

// 已完成数量
const completedCount = computed(() => {
  return Object.values(progress.value).filter(p => p.finished).length
})

// 进度百分比
const progressPercent = computed(() => {
  if (totalCount.value === 0) return 0
  return Math.round((completedCount.value / totalCount.value) * 100)
})

// 返回课程详情
const goBack = () => {
  router.push(`/course/${route.params.courseId}`)
}

// 上一节
const goPrev = () => {
  if (prevVideo.value) {
    switchVideo(prevVideo.value.id, prevVideo.value)
  }
}

// 下一节
const goNext = () => {
  if (nextVideo.value) {
    switchVideo(nextVideo.value.id, nextVideo.value)
  }
}

// 跳转到我的课程
const goToMyCourse = () => {
  router.push('/user/courses')
}

// 返回首页
const goToHome = () => {
  router.push('/')
}

// 个人中心
const goToUserCenter = () => {
  router.push('/user/center')
}

// 我的收藏
const goToMyFavorites = () => {
  router.push('/user/favorites')
}

// 我的订单
const goToMyOrders = () => {
  router.push('/user/orders')
}

// 账号设置
const goToProfile = () => {
  router.push('/user/profile')
}

// 退出登录
const logout = () => {
  userStore.logout()
  router.push('/')
}

onMounted(async () => {
  // 获取课程大纲
  const res = await getCourseDetail(Number(route.params.courseId))
  const courseData = res.data.course || res.data
  chapters.value = res.data.chapters || []
  courseName.value = courseData.title || ''
  isPurchased.value = courseData.isPurchased || false  // 从课程详情中获取是否已购买

  // 加载所有视频的学习进度（等待 chapters 加载完成后）
  await loadAllProgress()

  // 加载各视频的测验通过状态
  try {
    const quizRes = await getQuizPassedStatus(Number(route.params.courseId))
    quizPassed.value = quizRes.data || {}
  } catch (e) {
    console.log('加载测验状态失败', e)
  }

  // 加载收藏状态
  try {
    const favRes = await getFavorites()
    const favList = favRes.data || []
    isFavorite.value = favList.some((c: any) => c.id === Number(route.params.courseId))
  } catch (e) {
    console.log('加载收藏状态失败', e)
  }

  await loadVideo(Number(route.params.videoId))
})

// 加载所有视频的学习进度
const loadAllProgress = async () => {
  console.log('=== loadAllProgress 开始 ===')
  // 扁平化所有视频
  const allVids: any[] = []
  for (const ch of chapters.value) {
    if (ch.videos) {
      allVids.push(...ch.videos)
    }
  }
  console.log('视频数量:', allVids.length, allVids.map(v => v.id))
  
  for (const v of allVids) {
    try {
      const res = await getProgress(v.id)
      console.log('视频', v.id, '进度:', res.data)
      if (res.data) {
        progress.value[v.id] = res.data
      }
    } catch (e) {
      console.log('视频', v.id, '获取进度失败')
    }
  }
  console.log('=== loadAllProgress 结束 ===')
  console.log('progress:', progress.value)
}

const loadVideo = async (videoId: number) => {
  try {
    const res = await getPlayUrl(videoId)
    const url = res.data

    // 找到当前视频信息
    for (const ch of chapters.value) {
      const v = ch.videos?.find((v: any) => v.id === videoId)
      if (v) { currentVideo.value = v; break }
    }

    // 获取该视频的历史进度
    const savedProgress = progress.value[videoId]
    const startTime = savedProgress?.watchTime || 0

    // 初始化 Video.js
    if (player) {
      player.src({ src: url, type: 'video/mp4' })
      // 播放器加载完成后跳转到历史进度
      player.one('loadedmetadata', () => {
        if (startTime > 0) {
          player.currentTime(startTime)
          console.log('从上次进度继续播放:', videoId, '时间:', startTime)
        }
      })
    } else {
      player = videojs(videoRef.value!, {
        controls: true,
        autoplay: false,
        fluid: true,
        playbackRates: [0.5, 1, 1.25, 1.5, 2],
      })
      player.src({ src: url, type: 'video/mp4' })
      // 播放器加载完成后跳转到历史进度
      player.one('loadedmetadata', () => {
        if (startTime > 0) {
          player.currentTime(startTime)
          console.log('从上次进度继续播放:', videoId, '时间:', startTime)
        }
      })
    }

    // 记录进度定时器
    if (progressTimer) clearInterval(progressTimer)
    progressTimer = window.setInterval(async () => {
      try {
        if (player && player.currentTime && player.currentTime() > 0) {
          const currentTime = Math.floor(player.currentTime())
          console.log('记录进度:', videoId, '时间:', currentTime)

          // 首次记录进度时检查今日打卡
          if (!hasNotifiedCheckin.value) {
            try {
              const checkinRes = await getCheckinStats()
              if (checkinRes.data && !checkinRes.data.todayCheckedIn) {
                hasNotifiedCheckin.value = true
                ElMessage({
                  message: '🎉 学习打卡成功！坚持就是胜利！',
                  type: 'success',
                  duration: 3000,
                  showClose: true,
                })
              } else {
                hasNotifiedCheckin.value = true
              }
            } catch (e) {
              hasNotifiedCheckin.value = true
            }
          }

          recordProgress(videoId, currentTime).catch(err => {
            console.error('记录进度失败:', err)
          })
        }
      } catch (e) {
        console.error('进度记录异常:', e)
      }
    }, 5000) // 改为每5秒记录一次，更频繁地保存

    // 视频播放结束时，标记为已完成
    player.one('ended', () => {
      const duration = Math.floor(player.duration() || 0)
      recordProgress(videoId, duration, true).then(() => {
        // 更新本地进度状态，立即刷新 UI
        progress.value[videoId] = { ...(progress.value[videoId] || {}), finished: 1 }
        console.log('视频看完，已标记为完成:', videoId)

        // 视频看完后，自动弹出章节测验（如果该视频有测验题）
        if (currentChapterId.value) {
          showQuiz.value = true
        }
      })
    })
  } catch (err: any) {
    const msg = err?.response?.data?.message || err.message || '加载视频失败'
    // 购买权限拦截：提示并跳转到课程详情页
    if (msg.includes('购买') || msg.includes('登录')) {
      ElMessageBox.confirm(
        msg,
        '温馨提示',
        {
          confirmButtonText: '立即购买',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).then(() => {
        router.push(`/course/${route.params.courseId}`)
      }).catch(() => {})
    } else {
      ElMessage.error(msg)
    }
  }
}

const switchVideo = (videoId: number, video?: any) => {
  // 前端拦截：付费视频且用户未购买，直接提示
  if (video && !video.isFree && !isPurchased.value) {
    ElMessageBox.confirm(
      '该视频为付费内容，请先购买课程后再观看',
      '温馨提示',
      {
        confirmButtonText: '立即购买',
        cancelButtonText: '取消',
        type: 'warning',
      }
    ).then(() => {
      router.push(`/course/${route.params.courseId}`)
    }).catch(() => {})
    return
  }
  // 测验锁拦截：需完成前置视频并通过测验
  if (isVideoLocked(videoId)) {
    ElMessage.warning(getVideoLockReason(videoId))
    return
  }
  router.push(`/learn/${route.params.courseId}/video/${videoId}`)
}

watch(() => route.params.videoId, (newId) => {
  if (newId) loadVideo(Number(newId))
})

const toggleFav = async () => {
  try {
    const res = await toggleFavorite(Number(route.params.courseId))
    isFavorite.value = res.data
    ElMessage.success(res.data ? '收藏成功' : '已取消收藏')
  } catch (e) {
    ElMessage.error('操作失败')
  }
}

// 打开章节测验
const openQuiz = () => {
  if (currentChapterId.value) {
    showQuiz.value = true
  } else {
    ElMessage.warning('无法获取当前章节信息')
  }
}

// 测验提交成功后，刷新测验通过状态
const onQuizSubmitted = async () => {
  try {
    const quizRes = await getQuizPassedStatus(Number(route.params.courseId))
    quizPassed.value = quizRes.data || {}
  } catch (e) {
    console.log('刷新测验状态失败', e)
  }
}

onBeforeUnmount(() => {
  if (player) player.dispose()
  if (progressTimer) clearInterval(progressTimer)
})
</script>

<style lang="scss" scoped>
.player-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #0f1117;
}

// 顶部导航栏
.top-nav {
  height: 60px;
  background: #1a1d2e;
  border-bottom: 1px solid #333;
  display: flex;
  align-items: center;
  padding: 0 20px;
  flex-shrink: 0;

  .nav-left {
    width: 200px;
  }

  .nav-center {
    flex: 1;
    text-align: center;

    h1 {
      color: #fff;
      font-size: 16px;
      font-weight: 500;
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }

  .nav-right {
    width: 200px;
    display: flex;
    justify-content: flex-end;
  }

  .user-info {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    transition: background 0.2s;

    &:hover {
      background: rgba(255,255,255,0.1);
    }

    .username {
      font-size: 14px;
    }
  }
}

// 主体内容
.main-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.player-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
}

.video-wrapper {
  background: #000;
  position: relative;
}

.video-info {
  padding: 16px 24px;
  background: #1a1d2e;
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;

  h2 { font-size: 16px; font-weight: 600; margin: 0; }
  .actions { display: flex; gap: 8px; }
}

// 右侧课程目录
.sidebar {
  width: 320px;
  background: #1e2130;
  display: flex;
  flex-direction: column;
  border-left: 1px solid #333;
  flex-shrink: 0;
}

.sidebar-title {
  padding: 14px 20px;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  border-bottom: 1px solid #333;
  display: flex;
  justify-content: space-between;
  align-items: center;

  .sidebar-tabs {
    display: flex;
    gap: 16px;
    align-items: center;

    .tab {
      cursor: pointer;
      padding: 4px 0;
      font-size: 13px;
      font-weight: normal;
      color: #8892b0;
      border-bottom: 2px solid transparent;
      transition: all 0.2s;

      &:hover { color: #d0d0d0; }
      &.active { color: var(--el-color-primary); border-bottom-color: var(--el-color-primary); font-weight: 600; }
    }
  }

  .progress-text {
    font-size: 12px;
    color: #52c41a;
    font-weight: normal;
    margin-left: auto;
  }
}

.outline-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}

.note-scroll {
  flex: 1;
  overflow-y: auto;
}

.chapter-title {
  padding: 12px 20px 6px;
  color: #8892b0;
  font-size: 12px;
  font-weight: 600;
}

.video-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 13px;
  color: #a8b2d8;
  transition: all 0.2s;

  &:hover { background: rgba(255,255,255,0.05); color: #fff; }
  &.active { background: rgba(64,158,255,0.15); color: var(--el-color-primary); }
  &.locked { opacity: 0.7; cursor: pointer; }
  &.quiz-locked { cursor: pointer; }

  .v-title { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .free-tag {
    flex-shrink: 0;
    font-size: 10px;
    color: #52c41a;
    border: 1px solid #52c41a;
    border-radius: 3px;
    padding: 1px 4px;
    line-height: 1.4;
  }

  .quiz-tag {
    flex-shrink: 0;
    font-size: 10px;
    color: #e6a23c;
    border: 1px solid #e6a23c;
    border-radius: 3px;
    padding: 1px 4px;
    line-height: 1.4;
  }
}

// 底部控制栏
.bottom-bar {
  height: 64px;
  background: #1a1d2e;
  border-top: 1px solid #333;
  display: flex;
  align-items: center;
  padding: 0 20px;
  flex-shrink: 0;

  .prev-btn, .next-btn {
    width: 220px;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #a8b2d8;
    font-size: 13px;
    cursor: pointer;
    padding: 8px 12px;
    border-radius: 6px;
    transition: all 0.2s;
    overflow: hidden;

    &:hover:not(.disabled) {
      background: rgba(255,255,255,0.1);
      color: #fff;
    }

    &.disabled {
      color: #555;
      cursor: not-allowed;
    }

    span {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .prev-btn { justify-content: flex-start; }
  .next-btn { justify-content: flex-end; }

  .progress-center {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;

    .progress-bar {
      width: 200px;
      height: 4px;
      background: #333;
      border-radius: 2px;
      overflow: hidden;

      .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #0891b2, #06b6d4);
        transition: width 0.3s;
      }
    }

    .progress-label {
      color: #8892b0;
      font-size: 12px;
    }
  }
}
</style>
