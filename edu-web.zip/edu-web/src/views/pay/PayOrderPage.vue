<template>
  <div class="pay-order-page">
    <div class="pay-container">
      <div class="pay-card">
        <div class="pay-header">
          <img src="/logo.svg" alt="知学在线" class="logo" />
          <h2>确认支付</h2>
        </div>

        <div v-if="loading" class="loading-wrap">
          <el-skeleton :rows="4" animated />
        </div>

        <template v-else-if="orderInfo">
          <!-- 课程信息 -->
          <div class="course-section">
            <img :src="orderInfo.courseCover" :alt="orderInfo.courseTitle" class="course-cover" @error="handleImgError" />
            <div class="course-detail">
              <div class="course-title">{{ orderInfo.courseTitle }}</div>
              <div class="course-teacher">讲师：{{ orderInfo.teacherName }}</div>
            </div>
          </div>

          <el-divider />

          <!-- 金额信息 -->
          <div class="amount-section">
            <div class="amount-row">
              <span>课程原价</span>
              <span>¥{{ orderInfo.totalAmount?.toFixed(2) }}</span>
            </div>
            <div class="amount-row total">
              <span>实付金额</span>
              <span class="total-amount">¥{{ orderInfo.totalAmount?.toFixed(2) }}</span>
            </div>
          </div>

          <el-divider />

          <!-- 支付方式 -->
          <div class="pay-method-section">
            <div class="section-title">选择支付方式</div>
            <div class="pay-methods">
              <div
                class="pay-method"
                :class="{ active: payMethod === 'alipay' }"
                @click="payMethod = 'alipay'"
              >
                <svg viewBox="0 0 24 24" class="pay-icon" style="fill: #1677ff;">
                  <path d="M11.943 5.433c-.532-.28-1.485-.626-2.847-.626-1.37 0-2.323.346-2.857.632-.74.396-1.024.79-1.073 1.296-.073.746.494 1.567 1.65 2.375.32.223.682.446 1.09.662-1.56.914-3.36 1.916-5.17 2.77-.36.17-.44.285-.456.48-.03.346.297.534.65.534.18 0 .362-.03.535-.1 1.778-.72 3.645-1.63 5.48-2.56.36.198.716.38 1.07.552.26.127.53.2.79.2.64 0 1.27-.26 1.71-.7.43-.44.64-1.06.57-1.68-.08-.62-.45-1.17-.98-1.48-.5-.3-1.18-.4-1.84-.4-.24 0-.49.03-.74.08-.03-.24-.08-.48-.18-.7-.32-.66-1.03-1.07-1.78-1.07-.5 0-.97.18-1.32.48-.35.3-.56.72-.56 1.17 0 .34.11.67.32.91.21.25.5.42.82.5-.04.11-.08.23-.1.36-.02.13-.03.26-.03.39 0 .52.17 1.01.47 1.38.3.37.71.6 1.16.64.45.04.88-.09 1.23-.35.27-.2.45-.48.55-.8.18.08.37.15.57.19.2.05.4.07.6.07.87 0 1.7-.29 2.35-.82.65-.53 1.01-1.26 1.01-2.04 0-.78-.36-1.51-1.01-2.04-.65-.53-1.48-.82-2.35-.82-.67 0-1.31.15-1.89.43zM9.78 3.2c.38-.22.83-.34 1.3-.34 1.11 0 2.03.56 2.53 1.41.5.85.56 1.85.18 2.73-.38.88-1.15 1.52-2.08 1.76-.93.23-1.93.07-2.7-.44-.77-.51-1.24-1.33-1.27-2.21-.03-.88.36-1.72 1.05-2.27.35-.28.78-.46 1.24-.53-.06-.15-.13-.3-.25-.11zm-1.7 5.16c.2-.13.48-.16.72-.07.24.1.41.32.46.57.05.26.02.54-.08.78-.1.24-.27.43-.49.54-.22.11-.48.13-.71.05-.24-.08-.42-.27-.5-.5-.08-.24-.07-.5.03-.73.1-.23.3-.4.55-.46l.02-.18zm3.38-.01c.2-.13.48-.16.72-.07.24.1.41.32.46.57.05.26.02.54-.08.78-.1.24-.27.43-.49.54-.22.11-.48.13-.71.05-.24-.08-.42-.27-.5-.5-.08-.24-.07-.5.03-.73.1-.23.3-.4.55-.46l.02-.18z"/>
                </svg>
                <span>支付宝</span>
                <el-icon v-if="payMethod === 'alipay'" class="check-icon"><CircleCheck /></el-icon>
              </div>
            </div>
          </div>

          <!-- 协议 -->
          <div class="agreement">
            <el-checkbox v-model="agreed">
              我已阅读并同意
              <a href="#" @click.prevent>《用户购买协议》</a>
            </el-checkbox>
          </div>

          <!-- 支付按钮 -->
          <el-button
            type="primary"
            size="large"
            :disabled="!agreed"
            :loading="paying"
            class="pay-btn"
            @click="handlePay"
          >
            立即支付 ¥{{ orderInfo.totalAmount?.toFixed(2) }}
          </el-button>

          <div class="order-info-row">
            <span class="order-no">订单号：{{ orderInfo.orderNo }}</span>
            <div class="order-actions">
              <el-button link @click="goBack">取消支付</el-button>
              <el-button link type="primary" @click="$router.push('/user/orders')">查看订单</el-button>
            </div>
          </div>
        </template>

        <div v-else class="error-wrap">
          <el-result icon="error" title="订单不存在">
            <template #extra>
              <el-button @click="$router.push('/')">返回首页</el-button>
            </template>
          </el-result>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { CircleCheck } from '@element-plus/icons-vue'
import { getAlipayForm, createOrder, getOrderDetail, getOrderStatus, getMyOrders } from '@/api/order'
import { getCourseDetail } from '@/api/course'

const route = useRoute()
const router = useRouter()
const loading = ref(true)
const paying = ref(false)
const orderInfo = ref<any>(null)
const payMethod = ref('alipay')
const agreed = ref(true)

function goBack() {
  router.push('/user/orders')
}

function handleImgError(e: Event) {
  (e.target as HTMLImageElement).src = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D"http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width%3D"80" height%3D"80"%3E%3Crect fill%3D"%23e2e8f0" width%3D"100%25" height%3D"100%25"%2F%3E%3Ctext fill%3D"%2394a3b8" font-size%3D"12" font-family%3D"sans-serif" x%3D"50%25" y%3D"50%25" dominant-baseline%3D"middle" text-anchor%3D"middle"%3E%E5%B0%81%E9%9D%A2%3C%2Ftext%3E%3C%2Fsvg%3E'
}

async function loadOrder() {
  // 支持 params (courseId) 和 query (orderNo/courseId)
  const orderNo = route.query.orderNo as string
  const courseIdParam = route.query.courseId as string || route.params.courseId as string
  const courseId = courseIdParam ? Number(courseIdParam) : null

  try {
    // 如果有 orderNo，说明是已存在的订单，直接获取订单详情
    if (orderNo) {
      const orderRes = await getOrderDetail(orderNo)
      if (orderRes.code !== 200 || !orderRes.data) {
        ElMessage.error(orderRes.message || '获取订单失败')
        loading.value = false
        return
      }
      const order = orderRes.data
      orderInfo.value = {
        orderNo: order.orderNo,
        totalAmount: order.totalAmount,
        courseTitle: order.courseTitle,
        courseCover: order.courseCover,
        teacherName: order.teacherName,
      }
      // 如果订单已支付，直接跳转到结果页
      if (order.status === 1) {
        router.replace(`/pay/result?orderNo=${orderNo}&success=true`)
        return
      }
    } 
    // 如果有 courseId，创建新订单（或者查询是否已有该课程的待支付订单）
    else if (courseId) {
      // 先查询用户是否已有该课程的待支付订单
      try {
        const ordersRes = await getMyOrders({ size: 100 })
        const orders = ordersRes.data?.records || ordersRes.data || []
        const pendingOrder = orders.find((o: any) => o.courseId === courseId && o.status === 0)
        
        if (pendingOrder) {
          // 已有待支付订单，复用它
          orderInfo.value = {
            orderNo: pendingOrder.orderNo,
            totalAmount: pendingOrder.totalAmount,
            courseTitle: pendingOrder.courseTitle,
            courseCover: pendingOrder.courseCover,
            teacherName: pendingOrder.teacherName,
          }
        } else {
          // 没有待支付订单，创建新订单
          const courseRes = await getCourseDetail(courseId)
          const course = courseRes.data.course || courseRes.data

          const orderRes = await createOrder(courseId)
          const order = orderRes.data

          orderInfo.value = {
            orderNo: order.orderNo,
            totalAmount: order.totalAmount || course.price,
            courseTitle: course.title,
            courseCover: course.cover,
            teacherName: course.teacherName,
          }
        }
      } catch {
        // 如果查询失败，直接创建新订单
        const courseRes = await getCourseDetail(courseId)
        const course = courseRes.data.course || courseRes.data

        const orderRes = await createOrder(courseId)
        const order = orderRes.data

        orderInfo.value = {
          orderNo: order.orderNo,
          totalAmount: order.totalAmount || course.price,
          courseTitle: course.title,
          courseCover: course.cover,
          teacherName: course.teacherName,
        }
      }
    } else {
      ElMessage.error('无效的订单参数')
    }
  } catch (e) {
    console.error(e)
    ElMessage.error('加载订单失败')
  } finally {
    loading.value = false
  }
}

async function handlePay() {
  if (!orderInfo.value) return
  paying.value = true
  try {
    const res = await getAlipayForm(orderInfo.value.orderNo)
    const html = res.data?.html || res.data

    // 解析支付宝返回的HTML表单，提取action和参数
    const parser = new DOMParser()
    const doc = parser.parseFromString(html, 'text/html')
    const alipayForm = doc.querySelector('form')

    if (alipayForm) {
      const action = alipayForm.getAttribute('action') || ''
      const method = alipayForm.getAttribute('method') || 'POST'

      // 创建新表单，target设为_self实现在当前页面跳转
      const form = document.createElement('form')
      form.method = method.toUpperCase()
      form.action = action
      form.target = '_self'  // 关键：在当前页面跳转，不是新窗口
      form.style.display = 'none'

      // 复制所有输入字段
      const inputs = alipayForm.querySelectorAll('input')
      inputs.forEach(input => {
        const newInput = document.createElement('input')
        newInput.type = 'hidden'
        newInput.name = input.name || ''
        newInput.value = input.value || ''
        form.appendChild(newInput)
      })

      document.body.appendChild(form)
      form.submit()  // 提交后页面会跳转到支付宝，支付完成后返回到return_url
    } else {
      ElMessage.error('支付表单解析失败')
    }
  } catch (e: any) {
    ElMessage.error(e.message || '发起支付失败')
  } finally {
    paying.value = false
  }
}

function pollPayStatus(orderNo: string) {
  let attempts = 0
  const timer = setInterval(async () => {
    attempts++
    if (attempts > 30) {
      clearInterval(timer)
      return
    }
    try {
      // 使用订单状态查询接口
      const res = await getOrderStatus(orderNo)
      if (res.code === 200 && res.data?.status === 1) {
        clearInterval(timer)
        router.push(`/pay/result?orderNo=${orderNo}&success=true`)
      }
    } catch (e) { /* ignore */ }
  }, 2000)
}

onMounted(loadOrder)
</script>

<style scoped lang="scss">
.pay-order-page {
  min-height: 100vh;
  background: #f5f7fa;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}

.pay-container { width: 100%; max-width: 560px; }

.pay-card {
  background: #fff;
  border-radius: 16px;
  padding: 40px;
  box-shadow: 0 8px 40px rgba(0,0,0,0.08);
}

.pay-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  margin-bottom: 32px;
  .logo { height: 40px; }
  h2 { font-size: 22px; font-weight: 700; color: #1f2329; margin: 0; }
}

.course-section {
  display: flex;
  gap: 16px;
  align-items: center;
  .course-cover {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 8px;
    flex-shrink: 0;
  }
  .course-title { font-size: 15px; font-weight: 500; margin-bottom: 8px; }
  .course-teacher { font-size: 13px; color: #999; }
}

.amount-section {
  padding: 8px 0;
  .amount-row {
    display: flex;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 14px;
    color: #666;
    &.total {
      font-size: 15px;
      font-weight: 600;
      color: #333;
      .total-amount { font-size: 22px; color: #e74c3c; }
    }
  }
}

.pay-method-section {
  margin-bottom: 20px;
  .section-title { font-size: 14px; font-weight: 500; margin-bottom: 12px; }
}

.pay-methods { display: flex; gap: 12px; }

.pay-method {
  flex: 1;
  border: 2px solid #e8e8e8;
  border-radius: 10px;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  &.active { border-color: #0891b2; background: #ecfeff; }
  .pay-icon { width: 28px; height: 28px; }
  .check-icon { margin-left: auto; color: #0891b2; }
}

.agreement {
  margin-bottom: 20px;
  a { color: #0891b2; }
}

.pay-btn {
  width: 100%;
  height: 50px;
  font-size: 16px;
  font-weight: 600;
  background: #0891b2;
  border: none;
  border-radius: 10px;
  margin-bottom: 16px;
  &:hover { background: #0e7490; }
  &:disabled { opacity: 0.6; }
}

.order-info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .order-no { font-size: 12px; color: #999; }
  .order-actions { display: flex; gap: 8px; }
}

.loading-wrap, .error-wrap { padding: 20px 0; }
</style>
