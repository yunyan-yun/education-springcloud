<template>
  <div class="pay-result-page">
    <div class="result-container">
      <div class="result-card">
        <img src="/logo.svg" alt="知学在线" class="logo" />

        <div v-if="isSuccess" class="result-success">
          <div class="success-icon">
            <el-icon :size="72" color="#22c55e"><CircleCheckFilled /></el-icon>
          </div>
          <h2 class="result-title">支付成功！</h2>
          <p class="result-desc">恭喜您成功购买课程，快去开始学习吧</p>
          <div class="order-info">
            <div class="info-row">
              <span class="label">订单号</span>
              <span class="value">{{ orderNo }}</span>
            </div>
            <div class="info-row" v-if="orderInfo">
              <span class="label">课程名称</span>
              <span class="value">{{ orderInfo.courseTitle }}</span>
            </div>
            <div class="info-row" v-if="orderInfo">
              <span class="label">支付金额</span>
              <span class="value price">¥{{ orderInfo.totalAmount?.toFixed(2) }}</span>
            </div>
            <div class="info-row" v-if="orderInfo?.payTime">
              <span class="label">支付时间</span>
              <span class="value">{{ formatTime(orderInfo.payTime) }}</span>
            </div>
          </div>
          <div class="result-actions">
            <router-link :to="studyLink">
              <el-button type="primary" size="large" class="action-btn">立即学习</el-button>
            </router-link>
            <router-link to="/user/orders">
              <el-button size="large" class="action-btn">查看订单</el-button>
            </router-link>
          </div>
        </div>

        <div v-else class="result-fail">
          <div class="fail-icon">
            <el-icon :size="72" color="#ef4444"><CircleCloseFilled /></el-icon>
          </div>
          <h2 class="result-title">支付未完成</h2>
          <p class="result-desc">订单尚未支付成功，您可以重新支付或取消订单</p>
          <div class="result-actions">
            <el-button type="primary" size="large" class="action-btn" @click="retryPay">
              重新支付
            </el-button>
            <router-link to="/user/orders">
              <el-button size="large" class="action-btn">查看订单</el-button>
            </router-link>
          </div>
        </div>

        <router-link to="/" class="back-home">返回首页</router-link>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { CircleCheckFilled, CircleCloseFilled } from '@element-plus/icons-vue'
import request from '@/utils/request'
import dayjs from 'dayjs'

const route = useRoute()
const router = useRouter()
const orderNo = computed(() => route.query.orderNo as string)
const isSuccess = ref(route.query.success === 'true')
const orderInfo = ref<any>(null)

const studyLink = computed(() => {
  if (orderInfo.value?.courseId) {
    return `/course/${orderInfo.value.courseId}`
  }
  return '/user/courses'
})

function formatTime(time: string) {
  return time ? dayjs(time).format('YYYY-MM-DD HH:mm:ss') : '-'
}

async function loadOrder() {
  if (!orderNo.value) return
  try {
    // 使用正确的API路径: /order/order/info/${orderNo}
    const res = await request.get(`/order/order/info/${orderNo.value}`)
    orderInfo.value = res.data
    // 根据实际订单状态判断是否成功
    if (res.data?.status === 1) {
      isSuccess.value = true
    } else {
      isSuccess.value = false
    }
  } catch (e) {
    console.error(e)
    // API调用失败时，尝试使用status接口
    try {
      const statusRes = await request.get(`/order/order/status/${orderNo.value}`)
      orderInfo.value = statusRes.data
      if (statusRes.data?.status === 1) {
        isSuccess.value = true
      }
    } catch (e2) {
      console.error('订单查询失败', e2)
    }
  }
}

function retryPay() {
  router.push({ path: '/pay/order', query: { orderNo: orderNo.value } })
}

onMounted(loadOrder)
</script>

<style scoped lang="scss">
.pay-result-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #ecfeff 0%, #f0fdfa 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}

.result-container { width: 100%; max-width: 480px; }

.result-card {
  background: #fff;
  border-radius: 20px;
  padding: 48px 40px;
  box-shadow: 0 16px 64px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.logo { height: 36px; margin-bottom: 16px; }

.result-success, .result-fail {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}

.success-icon, .fail-icon { margin-bottom: 8px; }

.result-title {
  font-size: 24px;
  font-weight: 700;
  color: #1f2329;
  margin: 0;
}

.result-desc { font-size: 14px; color: #999; margin: 0; }

.order-info {
  width: 100%;
  background: #fafafa;
  border-radius: 10px;
  padding: 16px 20px;
  margin: 12px 0;
  display: flex;
  flex-direction: column;
  gap: 10px;

  .info-row {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
    .label { color: #999; }
    .value { color: #333; font-weight: 500; }
    .price { color: #e74c3c; font-size: 16px; font-weight: 700; }
  }
}

.result-actions {
  display: flex;
  gap: 12px;
  margin-top: 8px;
  width: 100%;
  .action-btn {
    flex: 1;
    height: 44px;
    font-size: 15px;
  }
}

.back-home {
  font-size: 13px;
  color: #999;
  text-decoration: none;
  margin-top: 8px;
  &:hover { color: #0891b2; }
}
</style>
