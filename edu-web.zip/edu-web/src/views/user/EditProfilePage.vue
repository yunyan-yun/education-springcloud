<template>
  <div class="edit-profile-page">
    <div class="profile-card">
      <div class="card-title">基本信息</div>
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-position="top"
        label-width="auto"
        class="profile-form"
      >
        <!-- 头像 -->
        <el-form-item label="头像">
          <div class="avatar-wrap">
            <el-avatar :size="80" :src="form.avatar" class="avatar-preview">
              <el-icon :size="40"><UserFilled /></el-icon>
            </el-avatar>
            <div class="avatar-tip">
              <el-upload
                action="#"
                :show-file-list="false"
                :before-upload="beforeAvatarUpload"
                accept="image/*"
              >
                <el-button size="small">更换头像</el-button>
              </el-upload>
              <p class="tip-text">支持 JPG、PNG，建议正方形图片</p>
            </div>
          </div>
        </el-form-item>

        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="form.nickname" placeholder="请输入昵称" maxlength="20" show-word-limit />
        </el-form-item>

        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" placeholder="请输入邮箱" />
        </el-form-item>

        <el-form-item label="性别">
          <el-radio-group v-model="form.gender">
            <el-radio :value="0">保密</el-radio>
            <el-radio :value="1">男</el-radio>
            <el-radio :value="2">女</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="个人简介" prop="intro">
          <el-input
            v-model="form.intro"
            type="textarea"
            :rows="3"
            placeholder="介绍一下自己吧..."
            maxlength="100"
            show-word-limit
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="saving" @click="saveProfile">保存修改</el-button>
          <el-button @click="resetForm">重置</el-button>
          <el-button @click="goBack">取消</el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 修改密码 -->
    <div class="profile-card">
      <div class="card-title">修改密码</div>
      <el-form
        ref="pwdFormRef"
        :model="pwdForm"
        :rules="pwdRules"
        label-position="top"
        label-width="auto"
        class="profile-form"
      >
        <el-form-item label="原密码" prop="oldPassword">
          <el-input v-model="pwdForm.oldPassword" type="password" show-password placeholder="请输入原密码" />
        </el-form-item>
        <el-form-item label="新密码" prop="newPassword">
          <el-input v-model="pwdForm.newPassword" type="password" show-password placeholder="请输入新密码（6-20位）" />
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input v-model="pwdForm.confirmPassword" type="password" show-password placeholder="请再次输入新密码" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="changingPwd" @click="changePassword">修改密码</el-button>
          <el-button @click="goBack">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { UserFilled } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { updateProfile, changePassword as changePasswordApi } from '@/api/user'
import request from '@/utils/request'

const router = useRouter()

const userStore = useUserStore()
const formRef = ref<FormInstance>()
const pwdFormRef = ref<FormInstance>()
const saving = ref(false)
const changingPwd = ref(false)

const form = reactive({
  nickname: '',
  email: '',
  gender: 0,
  intro: '',
  avatar: ''
})

const pwdForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const rules = {
  nickname: [{ required: true, message: '请输入昵称', trigger: 'blur' }],
  email: [{ type: 'email', message: '邮箱格式不正确', trigger: 'blur' }]
}

const validateConfirmPwd = (_rule: any, value: string, callback: Function) => {
  if (value !== pwdForm.newPassword) {
    callback(new Error('两次输入密码不一致'))
  } else {
    callback()
  }
}

const validateNewPwd = (_rule: any, value: string, callback: Function) => {
  if (value === pwdForm.oldPassword) {
    callback(new Error('新密码不能与原密码相同'))
  } else {
    callback()
  }
}

const pwdRules = {
  oldPassword: [{ required: true, message: '请输入原密码', trigger: 'blur' }],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度6-20位', trigger: 'blur' },
    { validator: validateNewPwd, trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    { validator: validateConfirmPwd, trigger: 'blur' }
  ]
}

async function beforeAvatarUpload(file: File) {
  const isImage = file.type.startsWith('image/')
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isImage) { ElMessage.error('只支持图片格式！'); return false }
  if (!isLt10M) { ElMessage.error('图片大小不能超过10MB！'); return false }
  
  // 上传到阿里云 OSS
  const formData = new FormData()
  formData.append('file', file)
  try {
    const res = await request.post('/course/file/upload/avatar', formData)
    form.avatar = res.data
    ElMessage.success('头像上传成功')
  } catch (e: any) {
    ElMessage.error(e.message || '上传失败')
  }
  return false
}

function initForm() {
  const info = userStore.userInfo
  if (info) {
    form.nickname = info.nickname || ''
    form.email = info.email || ''
    form.gender = info.gender ?? 0
    form.intro = info.intro || ''
    form.avatar = info.avatar || ''
  }
}

function resetForm() { initForm() }

function goBack() { router.push('/user/center') }

async function saveProfile() {
  await formRef.value?.validate()
  saving.value = true
  try {
    console.log('提交的数据:', JSON.stringify(form))
    console.log('intro 字段值:', form.intro)
    await updateProfile(form)
    await userStore.fetchUserInfo()
    ElMessage.success('保存成功')
  } catch (e: any) {
    ElMessage.error(e.message || '保存失败')
  } finally {
    saving.value = false
  }
}

async function changePassword() {
  await pwdFormRef.value?.validate()
  changingPwd.value = true
  try {
    await changePasswordApi({
      oldPassword: pwdForm.oldPassword,
      newPassword: pwdForm.newPassword
    })
    ElMessage.success('密码修改成功，请重新登录')
    pwdForm.oldPassword = ''
    pwdForm.newPassword = ''
    pwdForm.confirmPassword = ''
    setTimeout(() => {
      userStore.logout()
    }, 1500)
  } catch (e: any) {
    ElMessage.error(e.message || '修改失败')
  } finally {
    changingPwd.value = false
  }
}

onMounted(initForm)
</script>

<style scoped lang="scss">
.edit-profile-page { display: flex; flex-direction: column; gap: 20px; }

.profile-card {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #1f2329;
  margin-bottom: 24px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.profile-form { max-width: 480px; }

.avatar-wrap {
  display: flex;
  align-items: center;
  gap: 16px;
}

.avatar-preview { border: 3px solid #f0f0f0; }

.avatar-tip {
  .tip-text { font-size: 12px; color: #999; margin-top: 6px; }
}
</style>
