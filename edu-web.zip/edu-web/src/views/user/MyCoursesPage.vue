<template>
  <div class="my-courses-page">
    <div class="page-header">
      <h2 class="page-title">我的课程</h2>
      <span class="course-count">共 {{ total }} 门课程</span>
    </div>

    <div v-if="loading" class="course-grid">
      <el-skeleton v-for="i in 8" :key="i" :rows="3" animated class="skeleton-card" />
    </div>

    <div v-else-if="courses.length === 0" class="empty-wrap">
      <el-empty description="还没有购买课程">
        <router-link to="/courses">
          <el-button type="primary">去选课</el-button>
        </router-link>
      </el-empty>
    </div>

    <div v-else class="course-grid">
      <div v-for="course in courses" :key="course.id" class="course-item">
        <div class="course-cover-wrap">
          <img :src="course.cover" :alt="course.title" class="course-cover" @error="handleImgError" />
          <div class="progress-bar-wrap">
            <div class="progress-bar" :style="{ width: (course.progress || 0) + '%' }"></div>
          </div>
        </div>
        <div class="course-body">
          <div class="course-title">{{ course.title }}</div>
          <div class="course-meta">
            <span class="teacher">{{ course.teacherName }}</span>
            <span class="progress-text">{{ course.progress || 0 }}%</span>
          </div>
          <div class="course-actions">
            <router-link
              v-if="course.firstVideoId"
              :to="`/learn/${course.id}/video/${course.firstVideoId}`"
            >
              <el-button
                :type="course.progress >= 100 ? 'info' : 'primary'"
                size="small"
                class="study-btn"
              >
                <el-icon><VideoPlay /></el-icon>
                {{ course.progress >= 100 ? '已学完' : (course.progress > 0 ? '继续学习' : '开始学习') }}
              </el-button>
            </router-link>
            <el-button
              v-if="course.progress >= 100"
              type="warning"
              size="small"
              @click="openCert(course.id)"
            >
              查看证书
            </el-button>
            <router-link :to="`/course/${course.id}`">
              <el-button size="small">课程详情</el-button>
            </router-link>
          </div>
        </div>
        <div v-if="course.progress >= 100" class="finished-badge">
          <el-icon><CircleCheck /></el-icon> 已完成
        </div>
      </div>
    </div>

    <div class="pagination-wrap" v-if="total > pageSize">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="loadCourses"
        background
      />
    </div>

    <!-- 学习证书弹窗 -->
    <CertificateView
      v-model="showCert"
      :course-id="certCourseId"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getPurchasedCourses } from '@/api/course'
import { VideoPlay, CircleCheck } from '@element-plus/icons-vue'
import CertificateView from '@/components/certificate/CertificateView.vue'

const loading = ref(true)
const courses = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(12)
const showCert = ref(false)
const certCourseId = ref(0)

function handleImgError(e: Event) {
  (e.target as HTMLImageElement).src = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D"http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width%3D"280" height%3D"158"%3E%3Crect fill%3D"%23e2e8f0" width%3D"100%25" height%3D"100%25"%2F%3E%3Ctext fill%3D"%2394a3b8" font-size%3D"14" font-family%3D"sans-serif" x%3D"50%25" y%3D"50%25" dominant-baseline%3D"middle" text-anchor%3D"middle"%3E%E8%AF%BE%E7%A8%8B%E5%B0%81%E9%9D%A2%3C%2Ftext%3E%3C%2Fsvg%3E'
}

async function loadCourses() {
  loading.value = true
  try {
    const res = await getPurchasedCourses()
    if (res.data) {
      courses.value = res.data.records || res.data || []
      total.value = res.data.total || courses.value.length
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

onMounted(loadCourses)

function openCert(courseId: number) {
  certCourseId.value = courseId
  showCert.value = true
}
</script>

<style scoped lang="scss">
.my-courses-page { display: flex; flex-direction: column; gap: 20px; }

.page-header {
  background: #fff;
  border-radius: 12px;
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  .page-title { font-size: 18px; font-weight: 600; margin: 0; }
  .course-count { font-size: 14px; color: #999; }
}

.course-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.skeleton-card {
  background: #fff;
  border-radius: 12px;
  padding: 16px;
}

.course-item {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  position: relative;
  transition: transform 0.2s, box-shadow 0.2s;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(124,58,237,0.15);
  }
}

.course-cover-wrap {
  position: relative;
  .course-cover {
    width: 100%;
    aspect-ratio: 16/9;
    object-fit: cover;
    display: block;
  }
  .progress-bar-wrap {
    height: 4px;
    background: #e8e8e8;
    .progress-bar {
      height: 100%;
      background: #0891b2;
      transition: width 0.3s;
    }
  }
}

.course-body {
  padding: 14px;
  .course-title {
    font-size: 14px;
    font-weight: 500;
    color: #1f2329;
    margin-bottom: 8px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    min-height: 40px;
  }
  .course-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    .teacher { font-size: 12px; color: #999; }
    .progress-text { font-size: 12px; color: #0891b2; font-weight: 600; }
  }
  .course-actions {
    display: flex;
    gap: 8px;
    .study-btn { display: flex; align-items: center; gap: 4px; }
  }
}

.finished-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(34,197,94,0.9);
  color: #fff;
  font-size: 12px;
  padding: 3px 8px;
  border-radius: 20px;
  display: flex;
  align-items: center;
  gap: 3px;
}

.empty-wrap {
  background: #fff;
  border-radius: 12px;
  padding: 60px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.pagination-wrap {
  display: flex;
  justify-content: center;
  padding: 20px 0;
}
</style>
