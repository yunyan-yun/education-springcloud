<template>
  <div class="my-favorites-page">
    <div class="page-header">
      <h2 class="page-title">我的收藏</h2>
      <span class="course-count">共 {{ total }} 门课程</span>
    </div>

    <div v-if="loading" class="course-grid">
      <el-skeleton v-for="i in 8" :key="i" :rows="3" animated class="skeleton-card" />
    </div>

    <div v-else-if="courses.length === 0" class="empty-wrap">
      <el-empty description="还没有收藏课程">
        <router-link to="/courses">
          <el-button type="primary">去发现课程</el-button>
        </router-link>
      </el-empty>
    </div>

    <div v-else class="course-grid">
      <div v-for="course in courses" :key="course.id" class="course-card">
        <router-link :to="`/course/${course.id}`" class="course-link">
          <div class="cover-wrap">
            <img :src="course.cover" :alt="course.title" class="cover" @error="handleImgError" />
            <div v-if="course.isFree" class="free-badge">免费</div>
          </div>
          <div class="card-body">
            <div class="course-title">{{ course.title }}</div>
            <div class="course-meta">
              <span class="teacher">{{ course.teacherName }}</span>
              <span class="study-count">{{ formatCount(course.studyCount) }}人学习</span>
            </div>
            <div class="course-footer">
              <span class="price">
                <template v-if="course.isFree">免费</template>
                <template v-else>¥{{ course.price?.toFixed(2) }}</template>
              </span>
              <el-button
                size="small"
                :type="course.isFavorite ? 'warning' : 'default'"
                circle
                @click.prevent="handleToggleFavorite(course)"
                :icon="Star"
              />
            </div>
          </div>
        </router-link>
      </div>
    </div>

    <div class="pagination-wrap" v-if="total > pageSize">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="loadFavorites"
        background
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Star } from '@element-plus/icons-vue'
import { getFavorites, toggleFavorite } from '@/api/course'
const loading = ref(true)
const courses = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(12)

function handleImgError(e: Event) {
  (e.target as HTMLImageElement).src = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D"http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width%3D"280" height%3D"158"%3E%3Crect fill%3D"%23e2e8f0" width%3D"100%25" height%3D"100%25"%2F%3E%3Ctext fill%3D"%2394a3b8" font-size%3D"14" font-family%3D"sans-serif" x%3D"50%25" y%3D"50%25" dominant-baseline%3D"middle" text-anchor%3D"middle"%3E%E8%AF%BE%E7%A8%8B%E5%B0%81%E9%9D%A2%3C%2Ftext%3E%3C%2Fsvg%3E'
}

function formatCount(count: number) {
  if (!count) return '0'
  if (count >= 10000) return (count / 10000).toFixed(1) + 'w'
  if (count >= 1000) return (count / 1000).toFixed(1) + 'k'
  return String(count)
}

async function handleToggleFavorite(course: any) {
  try {
    await toggleFavorite(course.id)
    ElMessage.success('已取消收藏')
    // 从列表中移除已取消收藏的课程
    courses.value = courses.value.filter(c => c.id !== course.id)
    total.value = Math.max(0, total.value - 1)
    // 如果当前页已空且不是第一页，回到上一页重新加载
    if (courses.value.length === 0 && currentPage.value > 1) {
      currentPage.value--
      loadFavorites()
    }
  } catch (e) {
    ElMessage.error('操作失败')
  }
}

async function loadFavorites() {
  loading.value = true
  try {
    const res = await getFavorites()
    if (res.data) {
      const allCourses = res.data.records || res.data || []
      const start = (currentPage.value - 1) * pageSize.value
      courses.value = allCourses.slice(start, start + pageSize.value).map((c: any) => ({
        ...c,
        isFavorite: true,
        isFree: c.isFree ?? (c.price === 0 || c.price === null)
      }))
      total.value = allCourses.length
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

onMounted(loadFavorites)
</script>

<style scoped lang="scss">
.my-favorites-page { display: flex; flex-direction: column; gap: 20px; }

.page-header {
  background: #fff;
  border-radius: 12px;
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  .page-title { font-size: 18px; font-weight: 600; margin: 0; }
  .course-count { font-size: 14px; color: #999; }
}

.course-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.skeleton-card {
  background: #fff;
  border-radius: 12px;
  padding: 16px;
}

.course-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  transition: transform 0.2s, box-shadow 0.2s;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(124,58,237,0.15);
  }
}

.course-link { display: block; text-decoration: none; color: inherit; }

.cover-wrap {
  position: relative;
  .cover {
    width: 100%;
    aspect-ratio: 16/9;
    object-fit: cover;
    display: block;
  }
  .free-badge {
    position: absolute;
    top: 8px;
    left: 8px;
    background: #22c55e;
    color: #fff;
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 20px;
  }
}

.card-body {
  padding: 14px;
  .course-title {
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 8px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    min-height: 40px;
    color: #1f2329;
  }
  .course-meta {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 12px;
    color: #999;
  }
  .course-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .price { font-size: 18px; font-weight: 700; color: #e74c3c; }
  }
}

.empty-wrap {
  background: #fff;
  border-radius: 12px;
  padding: 60px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.pagination-wrap { display: flex; justify-content: center; padding: 20px 0; }
</style>
