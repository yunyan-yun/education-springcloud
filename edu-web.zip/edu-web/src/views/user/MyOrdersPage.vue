<template>
  <div class="my-orders-page">
    <div class="page-header">
      <h2 class="page-title">我的订单</h2>
    </div>

    <!-- 状态筛选 -->
    <div class="filter-bar">
      <el-radio-group v-model="statusFilter" @change="handleStatusChange">
        <el-radio-button label="">全部</el-radio-button>
        <el-radio-button label="0">待支付</el-radio-button>
        <el-radio-button label="1">已支付</el-radio-button>
        <el-radio-button label="2">已取消</el-radio-button>
        <el-radio-button label="4">退款中</el-radio-button>
        <el-radio-button label="5">已退款</el-radio-button>
      </el-radio-group>
    </div>

    <div v-if="loading" class="loading-wrap">
      <el-skeleton :rows="4" animated v-for="i in 3" :key="i" style="margin-bottom:16px" />
    </div>

    <div v-else-if="orders.length === 0" class="empty-wrap">
      <el-empty description="暂无订单记录">
        <router-link to="/courses">
          <el-button type="primary">去选课</el-button>
        </router-link>
      </el-empty>
    </div>

    <div v-else class="order-list">
      <div v-for="order in orders" :key="order.id" class="order-card">
        <div class="order-header">
          <span class="order-no">订单号：{{ order.orderNo }}</span>
          <el-tag :type="statusTagType(order.status)" size="small">
            {{ statusText(order.status) }}
          </el-tag>
        </div>
        <div class="order-body">
          <img :src="order.courseCover" :alt="order.courseTitle" class="course-cover" @error="handleImgError" />
          <div class="course-info">
            <div class="course-title">{{ order.courseTitle }}</div>
            <div class="course-teacher">讲师：{{ order.teacherName }}</div>
            <div v-if="order.refundReason" class="refund-reason">退款原因：{{ order.refundReason }}</div>
          </div>
          <div class="order-amount">¥{{ order.totalAmount?.toFixed(2) }}</div>
        </div>
        <div class="order-footer">
          <span class="order-time">下单时间：{{ formatTime(order.createTime) }}</span>
          <div class="order-actions">
            <!-- 待支付订单 -->
            <template v-if="order.status === 0">
              <el-button size="small" type="primary" @click="goPay(order.orderNo)">
                立即支付
              </el-button>
              <el-button size="small" @click="handleCancelOrder(order)">取消订单</el-button>
            </template>
            <!-- 已支付可进入学习 -->
            <template v-else-if="order.status === 1">
              <div class="action-group">
                <router-link :to="`/course/${order.courseId}`">
                  <el-button size="small" type="primary">去学习</el-button>
                </router-link>
                <template v-if="(order.refundRejectCount || 0) < 2">
                  <el-button size="small" type="warning" @click="handleApplyRefund(order)">申请退款</el-button>
                </template>
                <el-tag v-else type="info" size="small">无法退款</el-tag>
              </div>
            </template>
            <!-- 退款中 -->
            <template v-else-if="order.status === 4">
              <el-tag type="warning" size="small">退款审核中</el-tag>
            </template>
            <!-- 已退款 -->
            <template v-else-if="order.status === 5">
              <el-tag type="danger" size="small">已退款</el-tag>
            </template>
          </div>
        </div>
      </div>
    </div>

    <div class="pagination-wrap" v-if="total > pageSize">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="loadOrders"
        background
      />
    </div>

    <!-- 退款原因对话框 -->
    <el-dialog v-model="refundDialogVisible" title="申请退款" width="450px">
      <el-form>
        <el-form-item label="退款原因" required>
          <el-input
            v-model="refundReason"
            type="textarea"
            :rows="3"
            placeholder="请输入退款原因..."
            maxlength="200"
            show-word-limit
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="refundDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmRefund" :loading="refundLoading">确认申请</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getMyOrders, cancelOrder as cancelOrderApi, applyRefund as applyRefundApi } from '@/api/order'
import dayjs from 'dayjs'

const router = useRouter()
const loading = ref(true)
const orders = ref<any[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const statusFilter = ref('')

// 退款相关
const refundDialogVisible = ref(false)
const refundReason = ref('')
const refundLoading = ref(false)
const currentRefundOrder = ref<any>(null)

function statusText(status: number) {
  const map: Record<number, string> = { 
    0: '待支付', 1: '已支付', 2: '已取消', 3: '已完成', 4: '退款中', 5: '已退款' 
  }
  return map[status] ?? '未知'
}

function statusTagType(status: number) {
  const map: Record<number, string> = { 
    0: 'warning', 1: 'success', 2: 'info', 3: '', 4: 'warning', 5: 'danger' 
  }
  return (map[status] ?? 'info') as any
}

function formatTime(time: string) {
  return time ? dayjs(time).format('YYYY-MM-DD HH:mm') : '-'
}

function handleImgError(e: Event) {
  (e.target as HTMLImageElement).src = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D"http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width%3D"100" height%3D"60"%3E%3Crect fill%3D"%23e2e8f0" width%3D"100%25" height%3D"100%25"%2F%3E%3Ctext fill%3D"%2394a3b8" font-size%3D"12" font-family%3D"sans-serif" x%3D"50%25" y%3D"50%25" dominant-baseline%3D"middle" text-anchor%3D"middle"%3E%E5%B0%81%E9%9D%A2%3C%2Ftext%3E%3C%2Fsvg%3E'
}

function handleStatusChange() {
  currentPage.value = 1
  loadOrders()
}

async function loadOrders() {
  loading.value = true
  try {
    const params: any = { current: currentPage.value, size: pageSize.value }
    if (statusFilter.value !== '') params.status = Number(statusFilter.value)
    const res = await getMyOrders(params)
    if (res.data) {
      orders.value = res.data.records || []
      total.value = res.data.total || 0
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

function goPay(orderNo: string) {
  router.push({ path: '/pay/order', query: { orderNo } })
}

async function handleCancelOrder(order: any) {
  try {
    await ElMessageBox.confirm('确定要取消该订单吗？', '提示', { type: 'warning' })
    await cancelOrderApi(order.orderNo)
    ElMessage.success('订单已取消')
    loadOrders()
  } catch (e: any) {
    if (e !== 'cancel') {
      ElMessage.error(e.message || '取消订单失败')
    }
  }
}

function handleApplyRefund(order: any) {
  currentRefundOrder.value = order
  refundReason.value = ''
  refundDialogVisible.value = true
}

async function confirmRefund() {
  if (!refundReason.value.trim()) {
    ElMessage.warning('请输入退款原因')
    return
  }
  refundLoading.value = true
  try {
    await applyRefundApi(currentRefundOrder.value.orderNo, refundReason.value)
    ElMessage.success('退款申请已提交，请等待审核')
    refundDialogVisible.value = false
    loadOrders()
  } catch (e: any) {
    ElMessage.error(e.message || '申请退款失败')
  } finally {
    refundLoading.value = false
  }
}

onMounted(loadOrders)
</script>

<style scoped lang="scss">
.my-orders-page { display: flex; flex-direction: column; gap: 16px; }

.page-header {
  background: #fff;
  border-radius: 12px;
  padding: 20px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
  .page-title { font-size: 18px; font-weight: 600; margin: 0; }
}

.filter-bar {
  background: #fff;
  border-radius: 12px;
  padding: 16px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.empty-wrap, .loading-wrap {
  background: #fff;
  border-radius: 12px;
  padding: 60px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.order-list { display: flex; flex-direction: column; gap: 12px; }

.order-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  background: #fafafa;
  border-bottom: 1px solid #f0f0f0;
  .order-no { font-size: 13px; color: #666; }
}

.order-body {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 20px;
  .course-cover {
    width: 100px;
    height: 60px;
    object-fit: cover;
    border-radius: 6px;
    flex-shrink: 0;
  }
  .course-info {
    flex: 1;
    .course-title { font-size: 15px; font-weight: 500; margin-bottom: 6px; }
    .course-teacher { font-size: 13px; color: #999; }
    .refund-reason { font-size: 12px; color: #f56c6c; margin-top: 4px; }
  }
  .order-amount { font-size: 20px; font-weight: 700; color: #e74c3c; white-space: nowrap; }
}

.order-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  border-top: 1px solid #f0f0f0;
  .order-time { font-size: 12px; color: #999; }
  .order-actions { display: flex; gap: 8px; align-items: center; }
  .action-group { display: flex; gap: 8px; align-items: center; }
}

.pagination-wrap { display: flex; justify-content: center; padding: 20px 0; }
</style>
