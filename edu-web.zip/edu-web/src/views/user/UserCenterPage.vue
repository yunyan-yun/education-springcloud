<template>
  <div class="user-center">
    <!-- 学习统计 -->
    <div class="stat-cards">
      <div class="stat-card">
        <div class="stat-num">{{ stats.courseCount }}</div>
        <div class="stat-label">已学课程</div>
      </div>
      <div class="stat-card">
        <div class="stat-num">{{ stats.studyMinutes }}</div>
        <div class="stat-label">学习分钟</div>
      </div>
      <div class="stat-card">
        <div class="stat-num">{{ stats.finishedCount }}</div>
        <div class="stat-label">完成课程</div>
      </div>
      <div class="stat-card checkin-card">
        <div class="stat-num checkin-num">
          <span class="fire" v-if="checkinStats.continuousDays > 0">🔥</span>
          {{ checkinStats.continuousDays }}
        </div>
        <div class="stat-label">连续打卡</div>
        <div class="checkin-sub">累计{{ checkinStats.totalDays }}天</div>
      </div>
    </div>

    <!-- 基本信息 -->
    <div class="info-card">
      <div class="card-header">
        <span class="card-title">基本信息</span>
        <router-link to="/user/profile" class="edit-btn">
          <el-icon><Edit /></el-icon> 编辑资料
        </router-link>
      </div>
      <div class="info-list">
        <div class="info-item">
          <span class="info-label">昵称</span>
          <span class="info-value">{{ userStore.userInfo?.nickname || '-' }}</span>
        </div>
        <div class="info-item">
          <span class="info-label">手机号</span>
          <span class="info-value">{{ maskMobile(userStore.userInfo?.mobile) }}</span>
        </div>
        <div class="info-item">
          <span class="info-label">邮箱</span>
          <span class="info-value">{{ userStore.userInfo?.email || '未绑定' }}</span>
        </div>
        <div class="info-item">
          <span class="info-label">性别</span>
          <span class="info-value">{{ genderText }}</span>
        </div>
        <div class="info-item">
          <span class="info-label">个人简介</span>
          <span class="info-value">{{ userStore.userInfo?.intro || '这个人很懒，什么都没留下' }}</span>
        </div>
      </div>
    </div>

    <!-- 最近学习 -->
    <div class="info-card">
      <div class="card-header">
        <span class="card-title">最近学习</span>
        <router-link to="/user/courses" class="edit-btn">查看全部</router-link>
      </div>
      <div v-if="recentCourses.length === 0" class="empty-tip">
        <el-empty description="还没有学习记录，快去选课吧" :image-size="80">
          <router-link to="/courses">
            <el-button type="primary" size="small">浏览课程</el-button>
          </router-link>
        </el-empty>
      </div>
      <div v-else class="recent-list">
        <div v-for="item in recentCourses" :key="item.id" class="recent-item">
          <img :src="item.cover" :alt="item.title" class="recent-cover" @error="handleImgError" />
          <div class="recent-info">
            <div class="recent-title">{{ item.title }}</div>
            <div class="recent-teacher">讲师：{{ item.teacherName }}</div>
            <el-progress :percentage="item.progress || 0" :stroke-width="6" color="#0891b2" />
          </div>
          <router-link :to="item.lastStudyVideoId ? `/learn/${item.id}/video/${item.lastStudyVideoId}` : `/course/${item.id}`">
            <el-button
              size="small"
              :type="item.progress >= 100 ? 'info' : 'primary'"
              plain
            >
              {{ item.progress >= 100 ? '已学完' : '继续学习' }}
            </el-button>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from '@/stores/user'
import { getRecentCourses, getCourseStats, getCheckinStats } from '@/api/course'
import { Edit } from '@element-plus/icons-vue'

const userStore = useUserStore()
const recentCourses = ref<any[]>([])

const stats = ref({
  courseCount: 0,
  studyMinutes: 0,
  finishedCount: 0
})

const checkinStats = ref({
  totalDays: 0,
  continuousDays: 0,
  todayCheckedIn: false
})

const genderText = computed(() => {
  const g = userStore.userInfo?.gender
  if (g === 1) return '男'
  if (g === 2) return '女'
  return '未设置'
})

function maskMobile(mobile?: string) {
  if (!mobile) return '未绑定'
  return mobile.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
}

function handleImgError(e: Event) {
  const img = e.target as HTMLImageElement
  img.src = 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D"http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg" width%3D"120" height%3D"68"%3E%3Crect fill%3D"%23e2e8f0" width%3D"100%25" height%3D"100%25"%2F%3E%3Ctext fill%3D"%2394a3b8" font-size%3D"12" font-family%3D"sans-serif" x%3D"50%25" y%3D"50%25" dominant-baseline%3D"middle" text-anchor%3D"middle"%3E%E8%AF%BE%E7%A8%8B%E5%B0%81%E9%9D%A2%3C%2Ftext%3E%3C%2Fsvg%3E'
}

async function loadData() {
  try {
    const [recentRes, statsRes, checkinRes] = await Promise.all([
      getRecentCourses(3),
      getCourseStats(),
      getCheckinStats()
    ])

    // 加载最近学习的课程
    if (recentRes.data) {
      recentCourses.value = Array.isArray(recentRes.data) ? recentRes.data : []
    }

    // 使用后端返回的真实统计数据
    if (statsRes.data) {
      stats.value.courseCount = statsRes.data.courseCount || 0
      stats.value.studyMinutes = statsRes.data.studyMinutes || 0
      stats.value.finishedCount = statsRes.data.finishedCount || 0
    }

    // 打卡统计数据
    if (checkinRes.data) {
      checkinStats.value.totalDays = checkinRes.data.totalDays || 0
      checkinStats.value.continuousDays = checkinRes.data.continuousDays || 0
      checkinStats.value.todayCheckedIn = checkinRes.data.todayCheckedIn || false
    }
  } catch (e) {
    console.error(e)
  }
}

onMounted(loadData)
</script>

<style scoped lang="scss">
.user-center { display: flex; flex-direction: column; gap: 20px; }

.stat-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.stat-card {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  text-align: center;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);

  .stat-num {
    font-size: 32px;
    font-weight: 700;
    color: #0891b2;
    line-height: 1;
    margin-bottom: 8px;
  }
  .stat-label { font-size: 14px; color: #999; }

  &.checkin-card {
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    color: #fff;

    .stat-num {
      color: #fff;
      font-size: 36px;
    }
    .stat-label {
      color: rgba(255,255,255,0.85);
    }
    .checkin-sub {
      font-size: 12px;
      color: rgba(255,255,255,0.7);
      margin-top: 4px;
    }
    .fire { margin-right: 2px; }
  }
}

.info-card {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #f0f0f0;
}

.card-title { font-size: 16px; font-weight: 600; color: #1f2329; }

.edit-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #0891b2;
  text-decoration: none;
  font-size: 14px;
  &:hover { text-decoration: underline; }
}

.info-list { display: flex; flex-direction: column; gap: 16px; }

.info-item {
  display: flex;
  align-items: center;
  .info-label {
    width: 80px;
    color: #999;
    font-size: 14px;
    flex-shrink: 0;
  }
  .info-value { font-size: 14px; color: #333; }
}

.recent-list { display: flex; flex-direction: column; gap: 16px; }

.recent-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px;
  border-radius: 8px;
  background: #fafafa;
  &:hover { background: #f3f0ff; }
}

.recent-cover {
  width: 120px;
  height: 68px;
  object-fit: cover;
  border-radius: 6px;
  flex-shrink: 0;
}

.recent-info {
  flex: 1;
  min-width: 0;
  .recent-title {
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 6px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .recent-teacher { font-size: 12px; color: #999; margin-bottom: 8px; }
}
</style>
