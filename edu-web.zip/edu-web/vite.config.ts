import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import { fileURLToPath, URL } from 'node:url'
import type { ProxyOptions } from 'vite'

function proxyConfig(url: string): Record<string, string | ProxyOptions> {
  return {
    target: url,
    changeOrigin: true,
    // 增加请求体大小限制
    configure: (proxy) => {
      proxy.on('proxyRes', () => {})
    },
  }
}

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
      imports: ['vue', 'vue-router', 'pinia'],
    }),
    Components({
      resolvers: [ElementPlusResolver()],
    }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    port: 3000,
    proxy: {
      // 所有 /api 请求统一转发到 API 网关（edu-gateway :8080）
      // 网关会根据路径前缀自动路由到对应微服务
      '/api/user': {
        ...proxyConfig('http://localhost:8080'),
        rewrite: (path) => path.replace(/^\/api\/user/, '/user'),
      },
      '/api/course': {
        ...proxyConfig('http://localhost:8080'),
        rewrite: (path) => path.replace(/^\/api\/course/, '/course'),
      },
      '/api/order': {
        ...proxyConfig('http://localhost:8080'),
        rewrite: (path) => path.replace(/^\/api\/order/, '/order'),
      },
      '/api/ai': {
        ...proxyConfig('http://localhost:8080'),
        rewrite: (path) => path.replace(/^\/api\/ai/, '/ai'),
      },
    },
  },
})
