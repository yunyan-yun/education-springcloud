-- ============================================================
--  在线教育平台 - 用户库（edu_user）
--  作者：苏慧琳  学号：22021601453
--  指导教师：曲秀清
--  功能：存储平台用户信息
-- ============================================================

SET NAMES utf8mb4;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

-- 创建用户数据库
CREATE DATABASE IF NOT EXISTS edu_user DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edu_user;

-- -------------------------------------------------------
-- 会员表（edu_member）
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_member;
CREATE TABLE edu_member (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    mobile      VARCHAR(20) UNIQUE COMMENT '手机号（登录账号）',
    username    VARCHAR(50) UNIQUE COMMENT '用户名',
    password    VARCHAR(100) COMMENT '密码（BCrypt加密）',
    nickname    VARCHAR(50) COMMENT '昵称',
    avatar      MEDIUMTEXT COMMENT '头像URL',
    email       VARCHAR(100) COMMENT '邮箱',
    gender      TINYINT DEFAULT 0 COMMENT '性别：0未知 1男 2女',
    intro       VARCHAR(500) COMMENT '个人简介',
    status      TINYINT DEFAULT 1 COMMENT '状态：0禁用 1正常',
    role        VARCHAR(20) DEFAULT 'user' COMMENT '角色：user普通用户 / admin管理员',
    open_id     VARCHAR(100) COMMENT '第三方平台OpenId',
    is_deleted  TINYINT DEFAULT 0 COMMENT '逻辑删除',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

    INDEX idx_mobile(mobile),
    INDEX idx_username(username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员表';

-- 插入默认账号（密码均为 123456）
INSERT INTO edu_member(mobile, username, password, nickname, avatar, status, role) VALUES
('13800000000', 'admin', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '管理员', NULL, 1, 'admin'),
('13800000001', 'test001', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '测试用户01', NULL, 1, 'user'),
('13800000002', 'test002', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '测试用户02', NULL, 1, 'user'),
('13800000003', 'test003', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '张小明', NULL, 1, 'user'),
('13800000004', 'test004', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '李晓红', NULL, 1, 'user'),
('13800000005', 'test005', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O',
 '王大力', NULL, 1, 'user');
