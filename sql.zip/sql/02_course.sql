-- ============================================================
--  在线教育平台 - 课程库（edu_course）
--  作者：苏慧琳  学号：22021601453
--  指导教师：曲秀清
--  功能：存储课程、讲师、视频、分类等教学资源
-- ============================================================

SET NAMES utf8mb4;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

CREATE DATABASE IF NOT EXISTS edu_course DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edu_course;

-- -------------------------------------------------------
-- 课程分类表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_category;
CREATE TABLE edu_category (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL COMMENT '分类名称',
    parent_id   BIGINT DEFAULT 0 COMMENT '父分类ID，0为一级',
    sort        INT DEFAULT 0 COMMENT '排序',
    icon        VARCHAR(255) COMMENT '图标',
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程分类';

INSERT INTO edu_category(id, name, parent_id, sort) VALUES
(1, '前端开发', 0, 1), (2, '后端开发', 0, 2), (3, '移动开发', 0, 3),
(4, '数据科学', 0, 4), (5, '云原生', 0, 5), (6, '人工智能', 0, 6),
(7, 'HTML/CSS', 1, 1), (8, 'JavaScript', 1, 2), (9, 'Vue.js', 1, 3),
(10, 'React', 1, 4), (11, 'Java', 2, 1), (12, 'Python', 2, 2),
(13, 'Go', 2, 3), (14, 'Spring Cloud', 2, 4), (15, 'Android', 3, 1),
(16, 'iOS', 3, 2), (17, '微信小程序', 3, 3), (18, '机器学习', 6, 1),
(19, '深度学习', 6, 2), (20, 'Docker/K8s', 5, 1);

-- -------------------------------------------------------
-- 讲师表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_teacher;
CREATE TABLE edu_teacher (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL COMMENT '姓名',
    avatar      MEDIUMTEXT COMMENT '头像URL',
    intro       VARCHAR(500) COMMENT '简介',
    career      VARCHAR(200) COMMENT '职业经历',
    sort        INT DEFAULT 0,
    status      TINYINT DEFAULT 1 COMMENT '0下架 1正常',
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='讲师表';

INSERT INTO edu_teacher(name, avatar, intro, career, sort, status) VALUES
('张伟', NULL, '10年Java开发经验，精通Spring Cloud微服务架构', '阿里巴巴 | 字节跳动', 1, 1),
('李芳', NULL, '前端技术专家，Vue.js开源贡献者', '腾讯 | 美团', 2, 1),
('王磊', NULL, 'Python AI方向技术专家', '百度AI Lab', 3, 1),
('赵丽', NULL, '全栈工程师，精通React/Node.js', '独立开发者', 4, 1),
('陈强', NULL, '云原生技术专家，CKAD认证', '华为云', 5, 1);

-- -------------------------------------------------------
-- 轮播图表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_banner;
CREATE TABLE edu_banner (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(100) COMMENT '标题',
    image_url   VARCHAR(255) NOT NULL DEFAULT '' COMMENT '图片URL',
    link_url    VARCHAR(255) COMMENT '跳转链接',
    sort        INT DEFAULT 0,
    status      TINYINT DEFAULT 1 COMMENT '0下线 1上线',
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='轮播图表';

INSERT INTO edu_banner(title, image_url, link_url, sort, status) VALUES
('Spring Cloud微服务架构实战', '', '/course/1', 1, 1),
('Vue3全栈开发精讲', '', '/course/2', 2, 1),
('Python机器学习入门', '', '/course/3', 3, 1),
('Docker与Kubernetes实战', '', '/course/4', 4, 1);

-- -------------------------------------------------------
-- 课程表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_course;
CREATE TABLE edu_course (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(100) NOT NULL COMMENT '课程标题',
    sub_title       VARCHAR(200) COMMENT '副标题',
    cover           VARCHAR(255) DEFAULT '' COMMENT '封面URL',
    price           DECIMAL(10,2) DEFAULT 0 COMMENT '价格',
    original_price  DECIMAL(10,2) DEFAULT 0 COMMENT '原价',
    teacher_id      BIGINT COMMENT '讲师ID',
    teacher_name    VARCHAR(50) COMMENT '讲师名称',
    category_id     BIGINT COMMENT '分类ID',
    category_name   VARCHAR(50) COMMENT '分类名称',
    description     VARCHAR(500) COMMENT '简介',
    detail          LONGTEXT COMMENT '详情',
    study_count     INT DEFAULT 0 COMMENT '学习人数',
    comment_count   INT DEFAULT 0 COMMENT '评价人数',
    score           DECIMAL(2,1) DEFAULT 0 COMMENT '评分',
    duration        INT DEFAULT 0 COMMENT '总时长（分钟）',
    chapter_count   INT DEFAULT 0 COMMENT '章节数',
    status          TINYINT DEFAULT 0 COMMENT '0草稿 1发布 2下架',
    is_free         TINYINT DEFAULT 0 COMMENT '0收费 1免费',
    is_recommend    TINYINT DEFAULT 0 COMMENT '是否推荐',
    is_hot          TINYINT DEFAULT 0 COMMENT '是否热门',
    sort            INT DEFAULT 0,
    is_deleted      TINYINT DEFAULT 0,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_category(category_id),
    INDEX idx_teacher(teacher_id),
    INDEX idx_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程表';

INSERT INTO edu_course(title, sub_title, cover, price, original_price, teacher_id, teacher_name, category_id, category_name, description, study_count, score, duration, chapter_count, status, is_free, is_recommend, is_hot, sort) VALUES
('Spring Cloud微服务架构实战', '从单体到微服务，零基础到企业级', '', 199.00, 399.00, 1, '张伟', 14, 'Spring Cloud', '全面讲解Spring Cloud微服务架构体系', 3821, 4.9, 1200, 12, 1, 0, 1, 1, 10),
('Vue3全栈开发精讲', '掌握Vue3+TypeScript+Vite现代前端开发', '', 149.00, 299.00, 2, '李芳', 9, 'Vue.js', '深入讲解Vue3 Composition API', 5234, 4.8, 960, 10, 1, 0, 1, 0, 9),
('Python机器学习入门', '从数据处理到模型部署的完整学习路径', '', 129.00, 259.00, 3, '王磊', 18, '机器学习', '通过实战案例讲解机器学习算法', 2143, 4.7, 800, 8, 1, 0, 0, 1, 8),
('Docker与Kubernetes实战', '云原生容器化技术从入门到精通', '', 169.00, 339.00, 5, '陈强', 20, 'Docker/K8s', '系统学习容器化技术', 1876, 4.8, 720, 9, 1, 0, 1, 0, 7),
('React18全栈开发', '企业级React应用开发实战', '', 159.00, 319.00, 4, '赵丽', 10, 'React', '全面掌握React技术栈', 1567, 4.6, 840, 9, 1, 0, 0, 0, 6),
('Java零基础入门', '适合完全零基础的Java学习路线', '', 0.00, 0.00, 1, '张伟', 11, 'Java', '从Java基本语法开始', 8923, 4.9, 600, 8, 1, 1, 1, 1, 10),
('微信小程序开发实战', 'WXML+WXSS+JavaScript完整入门', '', 99.00, 199.00, 2, '李芳', 17, '微信小程序', '从零开始学习微信小程序开发', 2341, 4.5, 480, 6, 1, 0, 0, 0, 5),
('Go语言并发编程', 'Goroutine、Channel深度解析', '', 139.00, 279.00, 1, '张伟', 13, 'Go', '深入Go语言并发模型', 987, 4.7, 540, 7, 1, 0, 0, 0, 4);

-- -------------------------------------------------------
-- 章节表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_chapter;
CREATE TABLE edu_chapter (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id   BIGINT NOT NULL COMMENT '课程ID',
    title       VARCHAR(100) NOT NULL COMMENT '章节标题',
    sort        INT DEFAULT 0,
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_course(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='章节表';

INSERT INTO edu_chapter(course_id, title, sort) VALUES
(1, '第一章 微服务架构概述', 1), (1, '第二章 Nacos服务注册与发现', 2),
(1, '第三章 Spring Cloud Gateway网关', 3), (1, '第四章 OpenFeign服务调用', 4),
(2, '第一章 Vue3基础入门', 1), (2, '第二章 Composition API深度解析', 2),
(2, '第三章 TypeScript集成', 3),
(6, '第一章 Java开发环境搭建', 1), (6, '第二章 Java基本语法', 2),
(6, '第三章 面向对象编程', 3);

-- -------------------------------------------------------
-- 视频小节表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_video;
CREATE TABLE edu_video (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id   BIGINT NOT NULL COMMENT '课程ID',
    chapter_id  BIGINT NOT NULL COMMENT '章节ID',
    title       VARCHAR(100) NOT NULL COMMENT '小节标题',
    video_url   VARCHAR(500) COMMENT '视频URL',
    duration    INT DEFAULT 0 COMMENT '时长（秒）',
    is_free     TINYINT DEFAULT 0 COMMENT '是否免费试看',
    sort        INT DEFAULT 0,
    play_count  INT DEFAULT 0,
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_course(course_id),
    INDEX idx_chapter(chapter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='视频小节表';

INSERT INTO edu_video(course_id, chapter_id, title, video_url, duration, is_free, sort, play_count) VALUES
(1, 1, '1-1 什么是微服务架构', NULL, 600, 1, 1, 1234),
(1, 1, '1-2 单体应用的痛点', NULL, 480, 1, 2, 987),
(1, 1, '1-3 微服务拆分原则', NULL, 720, 0, 3, 876),
(1, 2, '2-1 Nacos简介与安装', NULL, 540, 1, 1, 765),
(1, 2, '2-2 服务注册实战', NULL, 660, 0, 2, 654),
(2, 5, '1-1 Vue3新特性介绍', NULL, 480, 1, 1, 2341),
(2, 5, '1-2 项目环境搭建', NULL, 360, 1, 2, 1987),
(6, 8, '1-1 JDK安装与配置', NULL, 420, 1, 1, 5678),
(6, 8, '1-2 IDEA开发工具使用', NULL, 480, 1, 2, 4567);

-- -------------------------------------------------------
-- 课程评论表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_comment;
CREATE TABLE edu_comment (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id       BIGINT NOT NULL COMMENT '课程ID',
    member_id       BIGINT NOT NULL COMMENT '用户ID',
    member_nickname VARCHAR(50),
    member_avatar   TEXT,
    content         VARCHAR(1000) NOT NULL COMMENT '评论内容',
    score           TINYINT DEFAULT 5 COMMENT '评分1-5',
    course_name     VARCHAR(200),
    is_deleted      TINYINT DEFAULT 0,
    create_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_course(course_id),
    INDEX idx_member(member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程评论表';

INSERT INTO edu_comment(course_id, member_id, member_nickname, content, score, course_name) VALUES
(1, 3, '张小明', '课程内容非常系统，讲师讲解清晰！强烈推荐！', 5, 'Spring Cloud微服务架构实战'),
(1, 4, '李晓红', '知识点覆盖面广，实战案例丰富！', 5, 'Spring Cloud微服务架构实战'),
(2, 3, '张小明', 'Vue3的新特性讲解得很到位！', 4, 'Vue3全栈开发精讲'),
(6, 5, '王大力', '零基础入门的最佳选择！', 5, 'Java零基础入门');

-- -------------------------------------------------------
-- 学习进度表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_study_progress;
CREATE TABLE edu_study_progress (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id   BIGINT NOT NULL,
    course_id   BIGINT NOT NULL,
    video_id    BIGINT NOT NULL,
    watch_time  INT DEFAULT 0 COMMENT '已观看时长（秒）',
    total_time  INT DEFAULT 0,
    finished    TINYINT DEFAULT 0,
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uk_member_video(member_id, video_id),
    INDEX idx_member_course(member_id, course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学习进度表';

-- -------------------------------------------------------
-- 课程收藏表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_favorite;
CREATE TABLE edu_favorite (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id   BIGINT NOT NULL,
    course_id   BIGINT NOT NULL,
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uk_member_course(member_id, course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程收藏表';
