-- ============================================================
--  在线教育平台 - 订单库（edu_order）
--  作者：苏慧琳  学号：22021601453
--  指导教师：曲秀清
--  功能：存储订单信息和退款记录
-- ============================================================

SET NAMES utf8mb4;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

CREATE DATABASE IF NOT EXISTS edu_order DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edu_order;

-- -------------------------------------------------------
-- 订单表
-- 状态说明：
--   0: 待支付  1: 已支付  2: 已取消  3: 已完成
--   4: 退款中  5: 已退款
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_order;
CREATE TABLE edu_order (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    order_no            VARCHAR(50) UNIQUE NOT NULL COMMENT '订单号',
    member_id           BIGINT NOT NULL COMMENT '用户ID',
    course_id           BIGINT NOT NULL COMMENT '课程ID',
    course_title        VARCHAR(100) COMMENT '课程标题',
    course_cover        VARCHAR(255) COMMENT '课程封面',
    teacher_name        VARCHAR(50) COMMENT '讲师名称',
    total_amount        DECIMAL(10,2) NOT NULL COMMENT '订单金额',
    status              TINYINT DEFAULT 0 COMMENT '订单状态',
    pay_type            VARCHAR(20) COMMENT '支付方式',
    pay_time            DATETIME COMMENT '支付时间',
    trade_no            VARCHAR(100) COMMENT '第三方支付流水号',
    refund_reason       VARCHAR(500) COMMENT '退款原因',
    refund_time         DATETIME COMMENT '退款时间',
    refund_remark       VARCHAR(500) COMMENT '管理员退款备注',
    refund_reject_count INT DEFAULT 0 COMMENT '退款被拒绝次数',
    is_deleted          TINYINT DEFAULT 0 COMMENT '逻辑删除',
    create_time         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

    INDEX idx_member(member_id),
    INDEX idx_course(course_id),
    INDEX idx_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- 插入演示订单
INSERT INTO edu_order(order_no, member_id, course_id, course_title, course_cover, teacher_name, total_amount, status, pay_type, pay_time) VALUES
('EDU20240101001', 3, 1, 'Spring Cloud微服务架构实战', '', '张伟', 199.00, 1, 'alipay', '2024-01-01 10:30:00'),
('EDU20240101002', 4, 2, 'Vue3全栈开发精讲', '', '李芳', 149.00, 1, 'alipay', '2024-01-02 14:20:00'),
('EDU20240101003', 5, 1, 'Spring Cloud微服务架构实战', '', '张伟', 199.00, 1, 'alipay', '2024-01-03 09:15:00'),
('EDU20240110001', 3, 3, 'Python机器学习入门', '', '王磊', 129.00, 0, NULL, NULL);
