-- ============================================================
--  在线教育平台 - AI库（edu_ai）
--  作者：苏慧琳  学号：22021601453
--  指导教师：曲秀清
--  功能：存储AI智能助手的对话记录
-- ============================================================

SET NAMES utf8mb4;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

CREATE DATABASE IF NOT EXISTS edu_ai DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edu_ai;

-- -------------------------------------------------------
-- AI对话记录表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_ai_chat;
CREATE TABLE edu_ai_chat (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    member_id   BIGINT NOT NULL COMMENT '用户ID',
    role        VARCHAR(20) NOT NULL COMMENT '角色：user用户 / assistant助手',
    content     TEXT NOT NULL COMMENT '消息内容',
    session_id  VARCHAR(100) NOT NULL COMMENT '会话ID（UUID）',
    is_deleted  TINYINT DEFAULT 0 COMMENT '逻辑删除',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

    INDEX idx_member_session(member_id, session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AI对话记录表';
