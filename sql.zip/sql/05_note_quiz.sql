-- ============================================================
--  在线教育平台 - 学习笔记与章节测验（edu_course库）
--  作者：苏慧琳  学号：22021601453
--  指导教师：曲秀清
--  功能：学习笔记管理、章节测验题库、答题记录
-- ============================================================

USE edu_course;

-- -------------------------------------------------------
-- 学习笔记表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_note;
CREATE TABLE edu_note (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id   BIGINT NOT NULL COMMENT '用户ID',
    course_id   BIGINT NOT NULL COMMENT '课程ID',
    chapter_id  BIGINT COMMENT '章节ID',
    video_id    BIGINT NOT NULL COMMENT '视频ID',
    content     TEXT NOT NULL COMMENT '笔记内容',
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_member(member_id),
    INDEX idx_video(video_id),
    INDEX idx_course(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学习笔记表';

-- 测试数据
INSERT INTO edu_note(member_id, course_id, chapter_id, video_id, content) VALUES
(3, 1, 1, 1, '微服务架构的核心思想是将单体应用拆分为多个独立部署的小服务，每个服务围绕一个业务能力构建。'),
(3, 1, 1, 2, '单体应用的主要痛点：部署风险高、技术栈受限、扩展困难、团队协作成本大。');

-- -------------------------------------------------------
-- 章节测验题目表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_question;
CREATE TABLE edu_question (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    course_id   BIGINT NOT NULL COMMENT '课程ID',
    chapter_id  BIGINT NOT NULL COMMENT '章节ID',
    video_id    BIGINT COMMENT '视频ID（测验绑定到具体视频）',
    content     VARCHAR(500) NOT NULL COMMENT '题目内容',
    option_a    VARCHAR(200) NOT NULL COMMENT '选项A',
    option_b    VARCHAR(200) NOT NULL COMMENT '选项B',
    option_c    VARCHAR(200) NOT NULL COMMENT '选项C',
    option_d    VARCHAR(200) NOT NULL COMMENT '选项D',
    answer      CHAR(1) NOT NULL COMMENT '正确答案 A/B/C/D',
    analysis    VARCHAR(500) COMMENT '解析',
    sort        INT DEFAULT 0,
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_chapter(chapter_id),
    INDEX idx_video(video_id),
    INDEX idx_course(course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='章节测验题目表';

-- 课程1：Spring Cloud - 第一章测验
INSERT INTO edu_question(course_id, chapter_id, video_id, content, option_a, option_b, option_c, option_d, answer, analysis, sort) VALUES
-- 课程1：第一章 视频1
(1, 1, 1, '微服务架构的核心思想是什么？', '将所有功能集中在一个应用中', '将单体应用拆分为多个独立部署的小服务', '使用多线程提高性能', '通过负载均衡分发请求', 'B', '微服务架构的核心是将大型单体应用拆分为一组小型、独立部署的服务，每个服务围绕特定业务能力构建。', 1),
(1, 1, 1, '以下哪项不是微服务架构的特点？', '独立部署', '技术栈统一', '去中心化治理', '按业务能力划分', 'B', '微服务架构允许每个服务使用不同的技术栈，这是其重要特点之一，而非统一技术栈。', 2),
-- 课程1：第一章 视频2
(1, 1, 2, '微服务之间通常通过什么方式通信？', '共享数据库', '文件系统', 'RESTful API或消息队列', '直接内存共享', 'C', '微服务之间通常通过轻量级的RESTful API或异步消息队列进行通信。', 1),
-- 课程1：第二章 视频4
(1, 2, 4, 'Nacos的核心功能包括？', '服务注册与发现、配置管理', '负载均衡、熔断降级', '日志收集、链路追踪', '消息队列、缓存管理', 'A', 'Nacos主要提供服务注册与发现和动态配置管理两大核心功能。', 1),
(1, 2, 4, '在Spring Cloud中，服务注册中心的作用是？', '存储业务数据', '管理服务的注册与发现', '处理HTTP请求', '生成前端页面', 'B', '服务注册中心负责管理各个微服务实例的注册信息，提供服务发现功能。', 2);

-- 课程2：Vue3 - 第一章 视频7
INSERT INTO edu_question(course_id, chapter_id, video_id, content, option_a, option_b, option_c, option_d, answer, analysis, sort) VALUES
(2, 5, 7, 'Vue3中Composition API的核心函数是？', 'created()', 'setup()', 'mounted()', 'data()', 'B', 'setup()是Composition API的入口函数，在组件创建之前执行。', 1),
(2, 5, 7, 'Vue3相比Vue2的主要改进不包括？', '更小的打包体积', '更快的虚拟DOM', '强制使用TypeScript', '更好的TypeScript支持', 'C', 'Vue3改进了性能、体积和TypeScript支持，但不强制使用TypeScript。', 2),
-- 课程2：Vue3 - 第一章 视频8
(2, 5, 8, 'Vue3中ref和reactive的区别是？', '没有区别', 'ref用于基本类型，reactive用于对象', 'ref用于对象，reactive用于基本类型', 'reactive不能用于数组', 'B', 'ref()用于基本数据类型的响应式，reactive()用于对象类型的响应式。', 1);

-- 课程6：Java零基础 - 第一章 视频15
INSERT INTO edu_question(course_id, chapter_id, video_id, content, option_a, option_b, option_c, option_d, answer, analysis, sort) VALUES
(6, 8, 15, 'Java程序的入口方法是？', 'start()', 'run()', 'main()', 'init()', 'C', 'Java程序的入口是public static void main(String[] args)方法。', 1),
(6, 8, 15, 'JDK的全称是？', 'Java Development Kit', 'Java Deployment Kit', 'Java Design Kit', 'Java Debug Kit', 'A', 'JDK（Java Development Kit）是Java开发工具包，包含编译器、运行时等。', 2);

-- -------------------------------------------------------
-- 答题记录表
-- -------------------------------------------------------
DROP TABLE IF EXISTS edu_answer_record;
CREATE TABLE edu_answer_record (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id   BIGINT NOT NULL COMMENT '用户ID',
    question_id BIGINT NOT NULL COMMENT '题目ID',
    user_answer CHAR(1) COMMENT '用户答案',
    is_correct  TINYINT DEFAULT 0 COMMENT '是否正确 0错 1对',
    is_deleted  TINYINT DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uk_member_question(member_id, question_id),
    INDEX idx_member(member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='答题记录表';
