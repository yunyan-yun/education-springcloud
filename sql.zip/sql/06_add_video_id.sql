-- ============================================================
--  给 edu_question 表新增 video_id 字段
--  用于将测验题目从章节级绑定改为视频级绑定
-- ============================================================

USE edu_course;

-- 新增 video_id 字段
ALTER TABLE edu_question ADD COLUMN video_id BIGINT COMMENT '视频ID（测验绑定到具体视频）' AFTER chapter_id;

-- 添加索引
ALTER TABLE edu_question ADD INDEX idx_video(video_id);

-- 更新现有数据：将第一章的题目绑定到视频1，第二章绑定到视频4
-- 课程1 第一章(chapter_id=1) 的视频：video_id=1(课程介绍), 2(系统进化理论概述), 3(系统进化理论背景)
UPDATE edu_question SET video_id = 1 WHERE chapter_id = 1 AND course_id = 1;

-- 课程1 第二章(chapter_id=2) 的视频：video_id=4
UPDATE edu_question SET video_id = 4 WHERE chapter_id = 2 AND course_id = 1;

-- 课程2 Vue3 第一章(chapter_id=5) 的视频：video_id=7, 8
UPDATE edu_question SET video_id = 7 WHERE chapter_id = 5 AND course_id = 2 AND sort IN (1, 2);
UPDATE edu_question SET video_id = 8 WHERE chapter_id = 5 AND course_id = 2 AND sort = 3;

-- 课程6 Java零基础 第一章(chapter_id=8) 的视频：video_id=15
UPDATE edu_question SET video_id = 15 WHERE chapter_id = 8 AND course_id = 6;
