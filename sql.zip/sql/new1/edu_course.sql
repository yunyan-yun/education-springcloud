/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : edu_course

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 19/05/2026 19:54:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for edu_answer_record
-- ----------------------------
DROP TABLE IF EXISTS `edu_answer_record`;
CREATE TABLE `edu_answer_record`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) NOT NULL COMMENT '用户ID',
  `question_id` bigint(20) NOT NULL COMMENT '题目ID',
  `user_answer` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户答案',
  `is_correct` tinyint(4) NULL DEFAULT 0 COMMENT '是否正确 0错 1对',
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_member_question`(`member_id`, `question_id`) USING BTREE,
  INDEX `idx_member`(`member_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '答题记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_answer_record
-- ----------------------------
INSERT INTO `edu_answer_record` VALUES (1, 2, 1, 'B', 1, 0, '2026-05-13 14:16:57');
INSERT INTO `edu_answer_record` VALUES (2, 3, 1, 'B', 1, 0, '2026-05-14 22:22:44');

-- ----------------------------
-- Table structure for edu_banner
-- ----------------------------
DROP TABLE IF EXISTS `edu_banner`;
CREATE TABLE `edu_banner`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图片URL',
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '跳转链接',
  `sort` int(11) NULL DEFAULT 0,
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '0下线 1上线',
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '轮播图表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_banner
-- ----------------------------
INSERT INTO `edu_banner` VALUES (1, 'Spring Cloud微服务架构实战', 'http://localhost:9000/online-edu/banner/20260426/8883fdc453d3453597b5889f3f84d54b.png', '/course/1', 1, 1, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_banner` VALUES (2, 'Vue3全栈开发精讲', 'http://localhost:9000/online-edu/banner/20260426/82228dfbd794458b8de240908c9d1860.jpg', '/course/2', 2, 1, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_banner` VALUES (3, 'Python机器学习入门', 'http://localhost:9000/online-edu/banner/20260426/3f999af40b6248e0a037b7ac4cc4652b.png', '/course/3', 3, 1, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_banner` VALUES (4, 'Docker与Kubernetes实战', 'http://localhost:9000/online-edu/banner/20260426/26c9e83ce42c4494b18f258985514ec4.jpg', '/course/4', 4, 1, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');

-- ----------------------------
-- Table structure for edu_category
-- ----------------------------
DROP TABLE IF EXISTS `edu_category`;
CREATE TABLE `edu_category`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父分类ID，0为一级',
  `sort` int(11) NULL DEFAULT 0 COMMENT '排序',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_category
-- ----------------------------
INSERT INTO `edu_category` VALUES (1, '前端开发', 0, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (2, '后端开发', 0, 2, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (3, '移动开发', 0, 3, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (4, '数据科学', 0, 4, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (5, '云原生', 0, 5, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (6, '人工智能', 0, 6, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (7, 'HTML/CSS', 1, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (8, 'JavaScript', 1, 2, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (9, 'Vue.js', 1, 3, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (10, 'React', 1, 4, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (11, 'Java', 2, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (12, 'Python', 2, 2, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (13, 'Go', 2, 3, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (14, 'Spring Cloud', 2, 4, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (15, 'Android', 3, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (16, 'iOS', 3, 2, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (17, '微信小程序', 3, 3, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (18, '机器学习', 6, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (19, '深度学习', 6, 2, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');
INSERT INTO `edu_category` VALUES (20, 'Docker/K8s', 5, 1, NULL, 0, '2026-04-24 17:10:46', '2026-04-24 17:10:46');

-- ----------------------------
-- Table structure for edu_chapter
-- ----------------------------
DROP TABLE IF EXISTS `edu_chapter`;
CREATE TABLE `edu_chapter`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '章节标题',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '章节描述',
  `sort` int(11) NULL DEFAULT 0,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 93 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '章节表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_chapter
-- ----------------------------
INSERT INTO `edu_chapter` VALUES (65, 1, '第一章 微服务架构概述', NULL, 1, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_chapter` VALUES (66, 1, '第二章 认识Spring Cloud', NULL, 2, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_chapter` VALUES (67, 1, '未完待续...', NULL, 3, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_chapter` VALUES (68, 2, '第一章 Vue基础与项目搭建', NULL, 1, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_chapter` VALUES (69, 2, '第二章 状态管理', NULL, 2, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_chapter` VALUES (70, 2, '未完待续...', NULL, 3, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_chapter` VALUES (71, 3, '第1章课程安排', NULL, 1, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_chapter` VALUES (72, 3, '第2章Python开发环境', NULL, 2, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_chapter` VALUES (73, 3, '未完待续...', NULL, 3, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_chapter` VALUES (74, 4, '第1章Docker基础', NULL, 1, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_chapter` VALUES (75, 4, '未完待续...', NULL, 2, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_chapter` VALUES (83, 8, '第1章项目准备与初始化', NULL, 1, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_chapter` VALUES (84, 8, '第2章项目框架搭建 ', NULL, 2, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_chapter` VALUES (85, 8, '未完待续...', NULL, 3, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_chapter` VALUES (86, 5, '第1章React入门与JSX基础', NULL, 1, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_chapter` VALUES (87, 5, '未完待续...', NULL, 2, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_chapter` VALUES (88, 6, '第一章 Java开发环境搭建', NULL, 1, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_chapter` VALUES (89, 6, '未完待续...', NULL, 2, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_chapter` VALUES (90, 7, '第1章课程介绍与环境搭建', NULL, 1, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_chapter` VALUES (91, 7, '第2章项目结构与快速上手', NULL, 2, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_chapter` VALUES (92, 7, '未完待续...', NULL, 3, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');

-- ----------------------------
-- Table structure for edu_comment
-- ----------------------------
DROP TABLE IF EXISTS `edu_comment`;
CREATE TABLE `edu_comment`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `member_id` bigint(20) NOT NULL COMMENT '用户ID',
  `member_nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `member_avatar` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `content` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论内容',
  `score` tinyint(4) NULL DEFAULT 5 COMMENT '评分1-5',
  `course_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE,
  INDEX `idx_member`(`member_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程评论表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_comment
-- ----------------------------
INSERT INTO `edu_comment` VALUES (5, 6, 2, '测试用户1', 'http://localhost:9000/online-edu/avatar/20260424/3683c469e2dc4badb60289f3cd8c7755.jpg', '很不错', 4, 'Java零基础入门', 0, '2026-04-26 13:11:32', '2026-04-26 13:11:31');

-- ----------------------------
-- Table structure for edu_course
-- ----------------------------
DROP TABLE IF EXISTS `edu_course`;
CREATE TABLE `edu_course`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '课程标题',
  `sub_title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '副标题',
  `cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '' COMMENT '封面URL',
  `price` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '价格',
  `original_price` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '原价',
  `teacher_id` bigint(20) NULL DEFAULT NULL COMMENT '讲师ID',
  `teacher_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '讲师名称',
  `category_id` bigint(20) NULL DEFAULT NULL COMMENT '分类ID',
  `category_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '分类名称',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '简介',
  `detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '详情',
  `study_count` int(11) NULL DEFAULT 0 COMMENT '学习人数',
  `comment_count` int(11) NULL DEFAULT 0 COMMENT '评价人数',
  `score` decimal(2, 1) NULL DEFAULT 0.0 COMMENT '评分',
  `duration` int(11) NULL DEFAULT 0 COMMENT '总时长（分钟）',
  `chapter_count` int(11) NULL DEFAULT 0 COMMENT '章节数',
  `status` tinyint(4) NULL DEFAULT 0 COMMENT '0草稿 1发布 2下架',
  `is_free` tinyint(4) NULL DEFAULT 0 COMMENT '0收费 1免费',
  `is_recommend` tinyint(4) NULL DEFAULT 0 COMMENT '是否推荐',
  `is_hot` tinyint(4) NULL DEFAULT 0 COMMENT '是否热门',
  `sort` int(11) NULL DEFAULT 0,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_category`(`category_id`) USING BTREE,
  INDEX `idx_teacher`(`teacher_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_course
-- ----------------------------
INSERT INTO `edu_course` VALUES (1, 'Spring Cloud微服务架构实战', '从单体到微服务，零基础到企业级', 'http://localhost:9000/online-edu/cover/20260426/dc70cde60cb749ada979e9573dfc668e.png', 199.00, 399.00, 1, '杨利军', 14, 'Spring Cloud', '全面系统地讲解Spring Cloud微服务架构体系，包含Nacos、Gateway、OpenFeign、Sentinel等核心组件。', 'Spring Cloud是目前最流行的进行微服务架构的框架之一，是一个一站式的开发分布式系统的框架，为开发者提供了一系列的构建分布式系统的工具集。目前已经在各大互联网公司得到广泛应用，是进行微服务架构的优先选择工具，也是程序员进阶和架构师必备的技术。', 3821, 2, 5.0, 1200, 12, 1, 0, 1, 1, 10, 0, '2026-04-24 17:10:46', '2026-04-26 21:50:54');
INSERT INTO `edu_course` VALUES (2, 'Vue3全栈开发精讲', '', 'http://localhost:9000/online-edu/cover/20260426/705528db3ec34a518da0c799189c581b.webp', 149.00, 299.00, 2, 'Lison', 9, 'Vue.js', '深入讲解Vue3 Composition API、TypeScript集成、状态管理Vuex/Pinia等核心内容，全程项目实战驱动，从入门到精通。', NULL, 5234, 1, 4.0, 960, 10, 1, 0, 1, 0, 9, 0, '2026-04-24 17:10:46', '2026-04-26 21:52:50');
INSERT INTO `edu_course` VALUES (3, 'Python零基础入门到机器学习', '从数据处理到模型部署的完整学习路径', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', 129.00, 259.00, 5, '唐宇迪讲AI', 18, '机器学习', '通过实战案例讲解机器学习算法，包含线性回归、决策树、神经网络等', NULL, 2143, 0, 0.0, 800, 8, 1, 0, 0, 1, 8, 0, '2026-04-24 17:10:46', '2026-04-26 21:54:08');
INSERT INTO `edu_course` VALUES (4, '【2025最新】Docker与Kubernetes（K8s）从入门到实践全教程', '运维实用工具包+高级运维职业规划+红帽/K8S/Linux课程咨询', 'http://localhost:9000/online-edu/cover/20260426/c9c3744c4cf349e19b1a279089fa9e83.png', 169.00, 339.00, 4, '新盟教育', 20, 'Docker/K8s', '运维实用工具包+高级运维职业规划+红帽/K8S/Linux课程咨询', NULL, 1876, 0, 0.0, 720, 9, 1, 0, 1, 0, 7, 0, '2026-04-24 17:10:46', '2026-04-26 21:55:07');
INSERT INTO `edu_course` VALUES (5, 'React18入门到实战', '从react+hooks核心基础到企业级项目开发实战及大厂面试全通关', 'http://localhost:9000/online-edu/cover/20260426/eeb17838b785424db5a81ed74a0dcd33.png', 159.00, 319.00, 6, '黑马程序员', 10, 'React', '全面掌握传智教育-黑马程序员前端研究院全新录制的前端入门教程，从react+hooks核心基础到企业级项目开发实战，包含B站评论、极客园项目等实战案例。', NULL, 1567, 0, 0.0, 840, 9, 1, 0, 0, 0, 6, 0, '2026-04-24 17:10:46', '2026-04-26 22:04:56');
INSERT INTO `edu_course` VALUES (6, 'Java零基础入门', '适合完全零基础的Java学习路线', 'http://localhost:9000/online-edu/cover/20260426/7dd00aeb733d43b89b7c0f1681767c16.png', 0.00, 0.00, 8, '尚学堂-百战程序员', 11, 'Java', '从Java基本语法开始', NULL, 8923, 1, 5.0, 600, 8, 1, 1, 1, 1, 10, 0, '2026-04-24 17:10:46', '2026-04-26 22:05:35');
INSERT INTO `edu_course` VALUES (7, '2024新版【微信小程序开发】', '全套流程详细讲解，从搭建到上线，全程干货无废话，从入门到精通视频教程。', 'http://localhost:9000/online-edu/cover/20260426/277bcb7284934acc9b7ab9289c209f13.png', 99.00, 199.00, 3, 'python收藏夹', 17, '微信小程序', '2024新版【微信小程序开发】全套流程详细讲解，从搭建到上线，全程干货无废话，从入门到精通视频教程。学不会我退出IT界！', NULL, 2341, 0, 0.0, 480, 6, 1, 0, 0, 0, 5, 0, '2026-04-24 17:10:46', '2026-04-26 22:10:13');
INSERT INTO `edu_course` VALUES (8, 'Go语言实战项目《百万级并发IM即时消息系统》', '程序员转行golang开发必看，手把手教你从零入门Go语言开发', 'http://localhost:9000/online-edu/cover/20260426/fa929c979c204b2e97bcfd9f9118ef9e.png', 139.00, 279.00, 7, '云原生架构师', 13, 'Go', '程序员转行golang开发必看，手把手教你从零入门Go语言开发，打造百万级并发IM即时消息系统。', 'golang教程，手把手教你做golang实战项目，想学你就来吧！', 987, 0, 0.0, 540, 7, 1, 0, 0, 0, 4, 0, '2026-04-24 17:10:46', '2026-04-26 21:58:33');

-- ----------------------------
-- Table structure for edu_favorite
-- ----------------------------
DROP TABLE IF EXISTS `edu_favorite`;
CREATE TABLE `edu_favorite`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_member_course`(`member_id`, `course_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '课程收藏表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_favorite
-- ----------------------------
INSERT INTO `edu_favorite` VALUES (1, 2, 2, 0, '2026-04-26 22:57:15', '2026-04-26 22:57:14');
INSERT INTO `edu_favorite` VALUES (2, 3, 5, 1, '2026-04-27 16:08:25', '2026-04-27 16:08:25');
INSERT INTO `edu_favorite` VALUES (3, 2, 1, 1, '2026-05-12 22:23:07', '2026-05-13 15:27:18');

-- ----------------------------
-- Table structure for edu_note
-- ----------------------------
DROP TABLE IF EXISTS `edu_note`;
CREATE TABLE `edu_note`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) NOT NULL COMMENT '用户ID',
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `chapter_id` bigint(20) NULL DEFAULT NULL COMMENT '章节ID',
  `video_id` bigint(20) NOT NULL COMMENT '视频ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '笔记内容',
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_member`(`member_id`) USING BTREE,
  INDEX `idx_video`(`video_id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '学习笔记表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_note
-- ----------------------------
INSERT INTO `edu_note` VALUES (1, 3, 1, 1, 1, '微服务架构的核心思想是将单体应用拆分为多个独立部署的小服务，每个服务围绕一个业务能力构建。', 0, '2026-05-13 13:56:45', '2026-05-13 13:56:45');
INSERT INTO `edu_note` VALUES (2, 3, 1, 1, 2, '单体应用的主要痛点：部署风险高、技术栈受限、扩展困难、团队协作成本大。', 0, '2026-05-13 13:56:45', '2026-05-13 13:56:45');
INSERT INTO `edu_note` VALUES (3, 2, 1, 65, 134, 'zhege', 0, '2026-05-13 14:18:22', '2026-05-13 14:18:22');
INSERT INTO `edu_note` VALUES (4, 2, 1, 66, 135, '哈哈', 0, '2026-05-13 15:44:26', '2026-05-13 15:44:26');

-- ----------------------------
-- Table structure for edu_question
-- ----------------------------
DROP TABLE IF EXISTS `edu_question`;
CREATE TABLE `edu_question`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `chapter_id` bigint(20) NOT NULL COMMENT '章节ID',
  `video_id` bigint(20) NULL DEFAULT NULL COMMENT '视频ID（测验绑定到具体视频）',
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '题目内容',
  `option_a` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '选项A',
  `option_b` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '选项B',
  `option_c` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '选项C',
  `option_d` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '选项D',
  `answer` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '正确答案 A/B/C/D',
  `analysis` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '解析',
  `sort` int(11) NULL DEFAULT 0,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_chapter`(`chapter_id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE,
  INDEX `idx_video`(`video_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '章节测验题目表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_question
-- ----------------------------
INSERT INTO `edu_question` VALUES (1, 1, 65, 132, '微服务架构的核心思想是什么？', '将所有功能集中在一个应用中', '将单体应用拆分为多个独立部署的小服务', '使用多线程提高性能', '通过负载均衡分发请求', 'B', '微服务架构的核心是将大型单体应用拆分为一组小型、独立部署的服务，每个服务围绕特定业务能力构建。', 1, 0, '2026-05-13 13:56:45', '2026-05-14 19:59:58');
INSERT INTO `edu_question` VALUES (2, 1, 1, 1, '以下哪项不是微服务架构的特点？', '独立部署', '技术栈统一', '去中心化治理', '按业务能力划分', 'B', '微服务架构允许每个服务使用不同的技术栈，这是其重要特点之一，而非统一技术栈。', 2, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (3, 1, 1, 1, '微服务之间通常通过什么方式通信？', '共享数据库', '文件系统', 'RESTful API或消息队列', '直接内存共享', 'C', '微服务之间通常通过轻量级的RESTful API或异步消息队列进行通信。', 3, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (4, 1, 66, 135, 'Nacos的核心功能包括？', '服务注册与发现、配置管理', '负载均衡、熔断降级', '日志收集、链路追踪', '消息队列、缓存管理', 'A', 'Nacos主要提供服务注册与发现和动态配置管理两大核心功能。', 1, 0, '2026-05-13 13:56:45', '2026-05-14 20:00:17');
INSERT INTO `edu_question` VALUES (5, 1, 2, 4, '在Spring Cloud中，服务注册中心的作用是？', '存储业务数据', '管理服务的注册与发现', '处理HTTP请求', '生成前端页面', 'B', '服务注册中心负责管理各个微服务实例的注册信息，提供服务发现功能。', 2, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (6, 2, 5, 7, 'Vue3中Composition API的核心函数是？', 'created()', 'setup()', 'mounted()', 'data()', 'B', 'setup()是Composition API的入口函数，在组件创建之前执行。', 1, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (7, 2, 5, 7, 'Vue3相比Vue2的主要改进不包括？', '更小的打包体积', '更快的虚拟DOM', '强制使用TypeScript', '更好的TypeScript支持', 'C', 'Vue3改进了性能、体积和TypeScript支持，但不强制使用TypeScript。', 2, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (8, 2, 5, 8, 'Vue3中ref和reactive的区别是？', '没有区别', 'ref用于基本类型，reactive用于对象', 'ref用于对象，reactive用于基本类型', 'reactive不能用于数组', 'B', 'ref()用于基本数据类型的响应式，reactive()用于对象类型的响应式。', 3, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (9, 6, 8, 15, 'Java程序的入口方法是？', 'start()', 'run()', 'main()', 'init()', 'C', 'Java程序的入口是public static void main(String[] args)方法。', 1, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');
INSERT INTO `edu_question` VALUES (10, 6, 8, 15, 'JDK的全称是？', 'Java Development Kit', 'Java Deployment Kit', 'Java Design Kit', 'Java Debug Kit', 'A', 'JDK（Java Development Kit）是Java开发工具包，包含编译器、运行时等。', 2, 0, '2026-05-13 13:56:45', '2026-05-13 14:29:12');

-- ----------------------------
-- Table structure for edu_study_progress
-- ----------------------------
DROP TABLE IF EXISTS `edu_study_progress`;
CREATE TABLE `edu_study_progress`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL,
  `video_id` bigint(20) NOT NULL,
  `watch_time` int(11) NULL DEFAULT 0 COMMENT '已观看时长（秒）',
  `total_time` int(11) NULL DEFAULT 0,
  `finished` tinyint(4) NULL DEFAULT 0,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_member_video`(`member_id`, `video_id`) USING BTREE,
  INDEX `idx_member_course`(`member_id`, `course_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '学习进度表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_study_progress
-- ----------------------------
INSERT INTO `edu_study_progress` VALUES (1, 2, 6, 108, 13, 255, 0, 0, '2026-04-25 15:55:13', '2026-04-25 15:55:13');
INSERT INTO `edu_study_progress` VALUES (2, 2, 2, 139, 289, 2403, 0, 0, '2026-04-26 22:34:40', '2026-04-26 22:34:40');
INSERT INTO `edu_study_progress` VALUES (3, 2, 1, 132, 131, 131, 1, 0, '2026-04-26 22:35:30', '2026-04-26 22:35:30');
INSERT INTO `edu_study_progress` VALUES (4, 2, 8, 174, 380, 380, 1, 0, '2026-04-27 01:30:22', '2026-04-27 01:30:22');
INSERT INTO `edu_study_progress` VALUES (5, 2, 8, 175, 6, 661, 0, 0, '2026-04-27 01:35:17', '2026-04-27 01:35:17');
INSERT INTO `edu_study_progress` VALUES (6, 2, 8, 176, 0, 632, 0, 0, '2026-04-27 14:33:06', '2026-04-27 14:33:06');
INSERT INTO `edu_study_progress` VALUES (7, 3, 6, 186, 255, 255, 1, 0, '2026-04-27 20:48:19', '2026-04-27 20:48:19');
INSERT INTO `edu_study_progress` VALUES (8, 2, 1, 134, 227, 232, 1, 0, '2026-05-13 14:17:51', '2026-05-13 14:17:51');
INSERT INTO `edu_study_progress` VALUES (9, 2, 1, 133, 227, 227, 1, 0, '2026-05-13 15:05:43', '2026-05-13 15:05:43');
INSERT INTO `edu_study_progress` VALUES (10, 2, 1, 135, 299, 299, 1, 0, '2026-05-13 15:07:29', '2026-05-13 15:07:29');
INSERT INTO `edu_study_progress` VALUES (11, 2, 1, 136, 376, 376, 1, 0, '2026-05-13 15:10:41', '2026-05-13 15:10:41');
INSERT INTO `edu_study_progress` VALUES (12, 2, 1, 137, 512, 512, 1, 0, '2026-05-13 15:14:21', '2026-05-13 15:14:21');
INSERT INTO `edu_study_progress` VALUES (13, 3, 1, 132, 131, 131, 1, 0, '2026-05-14 22:28:24', '2026-05-14 22:28:24');

-- ----------------------------
-- Table structure for edu_teacher
-- ----------------------------
DROP TABLE IF EXISTS `edu_teacher`;
CREATE TABLE `edu_teacher`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `avatar` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '头像URL',
  `intro` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '简介',
  `career` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '职业经历',
  `sort` int(11) NULL DEFAULT 0,
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '0下架 1正常',
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '讲师表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_teacher
-- ----------------------------
INSERT INTO `edu_teacher` VALUES (1, '杨利军', 'http://localhost:9000/online-edu/teacher/20260426/f1c32bb02e9247798b88baf614f2a13a.jpeg', '专注于Java后端开发与微服务架构领域，拥有丰富的企业级项目实战经验', '资深Java架构师/微服务技术专家', 0, 1, 0, '2026-04-24 19:23:27', '2026-04-26 21:45:27');
INSERT INTO `edu_teacher` VALUES (2, 'Lison', 'http://localhost:9000/online-edu/teacher/20260426/74cf7e62e77b47179fcde103a082091a.jpg', '', 'TalkingData可视化研发工程师，iView核心开发者', 1, 1, 0, '2026-04-24 19:23:38', '2026-04-26 21:45:51');
INSERT INTO `edu_teacher` VALUES (3, 'python收藏夹', 'http://localhost:9000/online-edu/teacher/20260426/a8533a7522a243d28559e13caf95ffa6.jpeg', '会Python数据分析、人工智能、爬虫、Flask框架、Excel函\n数、数据结构&算法、AI大模型等\n', '讲师', 2, 1, 0, '2026-04-24 19:23:52', '2026-04-26 21:46:27');
INSERT INTO `edu_teacher` VALUES (4, '新盟教育', 'http://localhost:9000/online-edu/teacher/20260426/7a0dad71226346c8bc672f162bdcfb9b.jpg', 'HCIA+HCIP+HCIE考证速通、华为常用命令、EVE-NG模\n拟器、网络安全认证等\n', '讲师', 3, 1, 0, '2026-04-24 19:24:03', '2026-04-26 21:46:45');
INSERT INTO `edu_teacher` VALUES (5, '唐宇迪讲AI', 'http://localhost:9000/online-edu/teacher/20260426/043183f8c7a14715a8e7aac55220bfdd.jpg', '提供付费咨询/1V1辅导，论文发表，核心期刊，SCI论文，EI会议、期刊、论文带读', 'AI教育讲师', 4, 1, 0, '2026-04-24 19:24:28', '2026-04-26 21:47:07');
INSERT INTO `edu_teacher` VALUES (6, '黑马程序员', 'http://localhost:9000/online-edu/teacher/20260426/1a9cc72e74154fa1af37f79bbad0acae.webp', '提供Python+AI、Java、前端、鸿蒙、大数据、软件测试、C/C++等课程。', 'IT职业教育机构', 5, 1, 0, '2026-04-24 19:24:45', '2026-04-26 21:47:26');
INSERT INTO `edu_teacher` VALUES (7, '云原生架构师', 'http://localhost:9000/online-edu/teacher/20260426/61ea923dbaad4c4d81def12dd4519f8f.webp', '学无先后，达者为师！专注Kubernetes、Docker、云原生技术教学。', '云原生架构师', 7, 1, 0, '2026-04-24 19:24:57', '2026-04-26 21:47:40');
INSERT INTO `edu_teacher` VALUES (8, '尚学堂-百战程序员', 'http://localhost:9000/online-edu/teacher/20260426/a8eab719095441ed8e4b2f5cb3732d97.png', '尚学堂·百战程序员提供了一套全面的IT学习课程，包括6000集视频，涵盖了人工智能(350集)、Python(900集)、JAVA(1101集)、大数据(750集)、互联网架构(300集)、C语言(199集)、PHP(700集)、区块链(500集)、前端开发(700集)、中小学编程(500集)等多个专业领域。课程设计系统化，适合初学者步步深入，目标是让学习者节省1000小时学习时间，提高学习效率。CEO高淇强调每集视频都将精心制作，力求成为中国最系统、最优质的课程。', 'IT职业教育品牌', 8, 1, 0, '2026-04-24 19:29:57', '2026-04-26 21:47:57');

-- ----------------------------
-- Table structure for edu_video
-- ----------------------------
DROP TABLE IF EXISTS `edu_video`;
CREATE TABLE `edu_video`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `chapter_id` bigint(20) NOT NULL COMMENT '章节ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '小节标题',
  `description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '视频描述，用于AI摘要生成',
  `video_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '视频URL',
  `duration` int(11) NULL DEFAULT 0 COMMENT '时长（秒）',
  `is_free` tinyint(4) NULL DEFAULT 0 COMMENT '是否免费试看',
  `sort` int(11) NULL DEFAULT 0,
  `play_count` int(11) NULL DEFAULT 0,
  `is_deleted` tinyint(4) NULL DEFAULT 0,
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE,
  INDEX `idx_chapter`(`chapter_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 198 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '视频小节表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_video
-- ----------------------------
INSERT INTO `edu_video` VALUES (132, 1, 65, '1-1 课程介绍', NULL, 'http://localhost:9000/online-edu/video/20260426/6444d16771224af28fb0826325511366.mp4', 131, 1, 1, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (133, 1, 65, '1-2 系统进化理论概述', NULL, 'http://localhost:9000/online-edu/video/20260426/c2b8a30171a44bfd9244809d684da9fd.mp4', 227, 1, 2, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (134, 1, 65, '1-3 系统进化理论背景', NULL, 'http://localhost:9000/online-edu/video/20260426/27d2bed3f03a4bcdb859ef645a5b100f.mp4', 232, 0, 3, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (135, 1, 66, '2-1 什么是微服务架构', NULL, 'http://localhost:9000/online-edu/video/20260426/9e45068f9f304eca95788f131db86f49.mp4', 299, 1, 1, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (136, 1, 66, '2-2 微服务架构的优缺点', NULL, 'http://localhost:9000/online-edu/video/20260426/ab329c5ab57e452b92c90e03b36f7f5f.mp4', 376, 0, 2, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (137, 1, 66, '2-3  为什么选择Spring Cloud构建微服务', NULL, 'http://localhost:9000/online-edu/video/20260426/fcd200f0d8e943fcb34f4b784b2ec00e.mp4', 512, 0, 3, 0, 0, '2026-04-26 21:50:54', '2026-04-26 21:50:54');
INSERT INTO `edu_video` VALUES (138, 2, 68, '1-1 Vue技术栈开发实战.使用vue.cli3创建项目', NULL, 'http://localhost:9000/online-edu/video/20260426/5d5bb83f68ae409da15fc52a0cbd76cd.mp4', 2405, 1, 1, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (139, 2, 68, '1-2 路由基础篇', NULL, 'http://localhost:9000/online-edu/video/20260426/542ad78f232d42a783c7aac977a6c73a.mp4', 2403, 1, 2, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (140, 2, 68, '1-3 路由进阶篇', NULL, 'http://localhost:9000/online-edu/video/20260426/8c2a1239257645fc9c2aec7ea741ed3b.mp4', 3063, 0, 3, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (141, 2, 69, '2-1 状态管理bus的使用', NULL, 'http://localhost:9000/online-edu/video/20260426/06b7c687d2c94d12814bc0b9eb62c6a4.mp4', 2199, 0, 1, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (142, 2, 69, '2-2 状态管理Vuex（一）', NULL, 'http://localhost:9000/online-edu/video/20260426/f41423b27a484b46a11c69b757ce3633.mp4', 2385, 0, 2, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (143, 2, 69, '2-3 状态管理Vuex（二）', NULL, 'http://localhost:9000/online-edu/video/20260426/da8a23d049864792a0c7311315990b41.mp4', 2431, 0, 3, 0, 0, '2026-04-26 21:52:50', '2026-04-26 21:52:50');
INSERT INTO `edu_video` VALUES (144, 3, 71, '1-1	课程学习安排：挑战一周学会Python基础与机器学习', NULL, 'http://localhost:9000/online-edu/video/20260426/206c53ffbd1c4aefb5296a8966641511.mp4', 750, 0, 1, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (145, 3, 71, '1-2 初学者必备人工智能学习路线图', NULL, 'http://localhost:9000/online-edu/video/20260426/72726b12f11e4a19b36d17e2aad28059.mp4', 503, 0, 2, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (146, 3, 72, '2-1 Python环境配置', NULL, 'http://localhost:9000/online-edu/video/20260426/af5d9fc8b95d42cb86c15155dde3864b.mp4', 932, 0, 1, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (147, 3, 72, '2-2 Python库安装工具', NULL, 'http://localhost:9000/online-edu/video/20260426/63a275b0b0db48b9966be096e5a961ea.mp4', 601, 0, 2, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (148, 3, 72, '2-3 Notebook工具使用', NULL, 'http://localhost:9000/online-edu/video/20260426/756b8e8eb75e4977891f5f8b20abb6cc.mp4', 1303, 0, 3, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (149, 3, 72, '2-4 Python简介', NULL, 'http://localhost:9000/online-edu/video/20260426/a867237b8fa84acbb14eb8d9824cfbc8.mp4', 1057, 0, 4, 0, 0, '2026-04-26 21:54:08', '2026-04-26 21:54:08');
INSERT INTO `edu_video` VALUES (150, 4, 74, '1-1	学习环境介绍', NULL, 'http://localhost:9000/online-edu/video/20260426/01e6914bf11646d19a1f96c8ed3fabc2.mp4', 1010, 0, 1, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (151, 4, 74, '1-2	Docker容器基本概念', NULL, 'http://localhost:9000/online-edu/video/20260426/e47f38065b6c440da2ab17792b7aa944.mp4', 2104, 0, 2, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (152, 4, 74, '1-3	Docker安装、镜像加速器配置、Docker镜像管理命令', NULL, 'http://localhost:9000/online-edu/video/20260426/fa9c6f6cbaf04f289209dc1a3c5faecf.mp4', 1963, 0, 3, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (153, 4, 74, '1-4	Docker容器管理命令-1', NULL, 'http://localhost:9000/online-edu/video/20260426/c1e4e5fc5b4a4a94b5f2c2ceb109ab6c.mp4', 1432, 0, 4, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (154, 4, 74, '1-5	Docker容器管理命令-2', NULL, 'http://localhost:9000/online-edu/video/20260426/7e92bbf44bf34da4b29e2e5732324977.mp4', 1240, 0, 5, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (155, 4, 74, '1-6	Docker容器数据卷', NULL, 'http://localhost:9000/online-edu/video/20260426/40c14bb3975d4844b6337c5bb742d737.mp4', 1517, 0, 6, 0, 0, '2026-04-26 21:55:07', '2026-04-26 21:55:07');
INSERT INTO `edu_video` VALUES (174, 8, 83, '1-1	项目背景能获得什么技术栈', NULL, 'http://localhost:9000/online-edu/video/20260426/ddb896ac63a840cab6ac0ecc7bdc9cac.mp4', 380, 1, 1, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (175, 8, 83, '1-2	项目架构及网络结构消息流程', NULL, 'http://localhost:9000/online-edu/video/20260426/e0c54d3a08734b9e888aaccacfbd677c.mp4', 661, 0, 2, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (176, 8, 83, '1-3	项目需求整理', NULL, 'http://localhost:9000/online-edu/video/20260426/f01e22fa4f3c4cf0a4dcae237698ae4e.mp4', 632, 0, 3, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (177, 8, 83, '1-4	效果演示', NULL, 'http://localhost:9000/online-edu/video/20260426/3c96ecc3a1ec42ea95295761c5617209.mp4', 504, 0, 4, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (178, 8, 83, '1-5	Gin项目初始化及GORM引入', NULL, 'http://localhost:9000/online-edu/video/20260426/2cbe344f52964032b6ecca98b0146afd.mp4', 1007, 0, 5, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (179, 8, 84, '2-1	Gin引入以及项目目录建立', NULL, 'http://localhost:9000/online-edu/video/20260426/98eaf2874f94459bb51343e7b521d4ee.mp4', 611, 0, 1, 0, 0, '2026-04-26 21:58:33', '2026-04-26 21:58:33');
INSERT INTO `edu_video` VALUES (180, 5, 86, '1-1	React入门到实战导学课程', NULL, 'http://localhost:9000/online-edu/video/20260426/a0564ff3e2134f548d2a6c52f7bdc25a.mp4', 588, 1, 1, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (181, 5, 86, '1-2	React简单介绍', NULL, 'http://localhost:9000/online-edu/video/20260426/9bc879451b89460fb2d08e6f14fc1f9e.mp4', 313, 1, 2, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (182, 5, 86, '1-3	React开发环境创建', NULL, 'http://localhost:9000/online-edu/video/20260426/471af53eae45421faa9a0388b59c5ca8.mp4', 798, 0, 3, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (183, 5, 86, '1-4	JSX基础-概念和本质', NULL, 'http://localhost:9000/online-edu/video/20260426/1ed173e5e30f450fb11364d2646edd12.mp4', 394, 0, 4, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (184, 5, 86, '1-5	JSX基础-识别js表达式', NULL, 'http://localhost:9000/online-edu/video/20260426/5571981c69904ea3a609a5dc1ebb087e.mp4', 342, 0, 5, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (185, 5, 86, '1-6	JSX基础-实现列表渲染', NULL, 'http://localhost:9000/online-edu/video/20260426/6d20ce2c84f244c981b4af7c22f56e8a.mp4', 355, 0, 6, 0, 0, '2026-04-26 22:04:56', '2026-04-26 22:04:56');
INSERT INTO `edu_video` VALUES (186, 6, 88, '1-1	JAVA最全学习路线图和就业分析', NULL, 'http://localhost:9000/online-edu/video/20260426/bfb26b877c8a4539990f3e780f19bb25.mp4', 255, 1, 1, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (187, 6, 88, '1-2	多种计算机语言特点介绍', NULL, 'http://localhost:9000/online-edu/video/20260426/5ce56b5ba6ad4599a094e1be28dcdc9f.mp4', 499, 1, 2, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (188, 6, 88, '1-3	JAVA发展史_三大版本含义_JAVA的核心优势和特点', NULL, 'http://localhost:9000/online-edu/video/20260426/4eaa46a22ba34b069a8fb3da4a051cc3.mp4', 533, 1, 3, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (189, 6, 88, '1-4	JAVA运行机制_JDK和JRE和JVM的区别', NULL, 'http://localhost:9000/online-edu/video/20260426/9b03e37a3bef439692d5cb300d8ec7de.mp4', 359, 1, 4, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (190, 6, 88, '1-5	JDK的下载和安装', NULL, 'http://localhost:9000/online-edu/video/20260426/6310a4e5e51b424a9f36cbcec6de10a5.mp4', 449, 1, 5, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (191, 6, 88, '1-6	JDK环境变量配置(win10下配置JDK8)', NULL, 'http://localhost:9000/online-edu/video/20260426/34ff0201532a499999869ca2c8a14127.mp4', 539, 1, 6, 0, 0, '2026-04-26 22:05:35', '2026-04-26 22:05:35');
INSERT INTO `edu_video` VALUES (192, 7, 90, '1-1	微信小程序概述', NULL, 'http://localhost:9000/online-edu/video/20260426/7f9441d97db64eb5be5d43e0d285525b.mp4', 655, 0, 1, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_video` VALUES (193, 7, 90, '1-2	环境-创建项目', NULL, 'http://localhost:9000/online-edu/video/20260426/fbcc5bf389224462842c1568b3858e63.mp4', 768, 0, 2, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_video` VALUES (194, 7, 90, '1-3	环境-django实现API', NULL, 'http://localhost:9000/online-edu/video/20260426/81f6eeac4caf46fa9ac3edeff63cbab0.mp4', 231, 0, 3, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_video` VALUES (195, 7, 91, '2-1	项目-目录文件', NULL, 'http://localhost:9000/online-edu/video/20260426/ed9838a4b1b94a139a532a790da93fcb.mp4', 1040, 0, 1, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_video` VALUES (196, 7, 91, '2-2	项目-纯净版', NULL, 'http://localhost:9000/online-edu/video/20260426/4e37920c8d954129a460bbad248d1891.mp4', 329, 0, 2, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');
INSERT INTO `edu_video` VALUES (197, 7, 91, '2-3	快速上手-入门', NULL, 'http://localhost:9000/online-edu/video/20260426/3b96771c857541879e5a9249934dcae7.mp4', 497, 0, 3, 0, 0, '2026-04-26 22:10:13', '2026-04-26 22:10:13');

SET FOREIGN_KEY_CHECKS = 1;
