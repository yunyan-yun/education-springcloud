/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : edu_order

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 19/05/2026 19:54:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for edu_order
-- ----------------------------
DROP TABLE IF EXISTS `edu_order`;
CREATE TABLE `edu_order`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单号',
  `member_id` bigint(20) NOT NULL COMMENT '用户ID',
  `course_id` bigint(20) NOT NULL COMMENT '课程ID',
  `course_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程标题',
  `course_cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '课程封面',
  `teacher_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '讲师名称',
  `total_amount` decimal(10, 2) NOT NULL COMMENT '订单金额',
  `status` tinyint(4) NULL DEFAULT 0 COMMENT '订单状态',
  `pay_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '支付方式',
  `pay_time` datetime(0) NULL DEFAULT NULL COMMENT '支付时间',
  `trade_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '第三方支付流水号',
  `refund_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '退款原因',
  `refund_time` datetime(0) NULL DEFAULT NULL COMMENT '退款时间',
  `refund_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '管理员退款备注',
  `refund_reject_count` int(11) NULL DEFAULT 0 COMMENT '退款被拒绝次数',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `order_no`(`order_no`) USING BTREE,
  INDEX `idx_member`(`member_id`) USING BTREE,
  INDEX `idx_course`(`course_id`) USING BTREE,
  INDEX `idx_status`(`status`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '订单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_order
-- ----------------------------
INSERT INTO `edu_order` VALUES (5, 'ORD1777031364909DA0C', 2, 5, 'React18入门到实战', 'http://localhost:9000/online-edu/cover/20260426/eeb17838b785424db5a81ed74a0dcd33.png', '黑马程序员', 159.00, 1, 'mock', '2026-04-24 19:49:28', NULL, '不需要了1', NULL, '', 2, 0, '2026-04-24 19:49:25', '2026-04-26 21:56:48');
INSERT INTO `edu_order` VALUES (6, 'ORD177703468244114F3', 2, 9, '建安八年', 'http://localhost:9000/online-edu/cover/20260424/f15881af438a4fa586024769b8c1ef04.jpg', '杨利军', 0.00, 1, 'mock', '2026-04-24 20:44:45', NULL, NULL, NULL, NULL, 0, 0, '2026-04-24 20:44:42', '2026-04-24 20:44:42');
INSERT INTO `edu_order` VALUES (7, 'ORD17770367193490ED3', 2, 1, 'Spring Cloud微服务架构实战', 'http://localhost:9000/online-edu/cover/20260426/dc70cde60cb749ada979e9573dfc668e.png', '杨利军', 199.00, 1, 'mock', '2026-04-24 21:18:42', NULL, NULL, NULL, NULL, 0, 0, '2026-04-24 21:18:39', '2026-04-26 21:50:02');
INSERT INTO `edu_order` VALUES (8, 'ORD1777036945959AF61', 2, 2, 'Vue3全栈开发精讲', 'http://localhost:9000/online-edu/cover/20260426/705528db3ec34a518da0c799189c581b.webp', 'Lison', 149.00, 1, 'mock', '2026-04-24 21:23:13', NULL, '不', NULL, '', 2, 0, '2026-04-24 21:22:26', '2026-04-27 00:22:50');
INSERT INTO `edu_order` VALUES (9, 'ORD1777212067723E758', 2, 4, '【2025最新】Docker与Kubernetes（K8s）从入门到实践全教程', 'http://localhost:9000/online-edu/cover/20260426/c9c3744c4cf349e19b1a279089fa9e83.png', '新盟教育', 169.00, 1, 'mock', '2026-04-26 22:01:12', NULL, NULL, NULL, NULL, 0, 0, '2026-04-26 22:01:08', '2026-04-26 22:01:08');
INSERT INTO `edu_order` VALUES (10, 'ORD177721215664993EE', 2, 7, '2024新版【微信小程序开发】', 'http://localhost:9000/online-edu/cover/20260426/277bcb7284934acc9b7ab9289c209f13.png', 'python收藏夹', 99.00, 1, 'mock', '2026-04-26 22:02:39', NULL, NULL, NULL, NULL, 0, 0, '2026-04-26 22:02:37', '2026-04-26 22:02:37');
INSERT INTO `edu_order` VALUES (11, 'ORD177721220087028B0', 2, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 1, 'mock', '2026-04-26 22:03:23', NULL, NULL, NULL, NULL, 0, 0, '2026-04-26 22:03:21', '2026-04-26 22:03:21');
INSERT INTO `edu_order` VALUES (12, 'ORD1777271571166518C', 2, 8, 'Go语言实战项目《百万级并发IM即时消息系统》', 'http://localhost:9000/online-edu/cover/20260426/fa929c979c204b2e97bcfd9f9118ef9e.png', '云原生架构师', 139.00, 1, 'mock', '2026-04-27 14:32:53', NULL, NULL, NULL, NULL, 0, 0, '2026-04-27 14:32:51', '2026-04-27 14:32:51');
INSERT INTO `edu_order` VALUES (13, 'ORD17772716266423DB9', 3, 1, 'Spring Cloud微服务架构实战', 'http://localhost:9000/online-edu/cover/20260426/dc70cde60cb749ada979e9573dfc668e.png', '杨利军', 199.00, 1, 'alipay', '2026-04-27 15:47:50', '2026042722001485880509680513', NULL, NULL, NULL, 0, 0, '2026-04-27 14:33:47', '2026-04-27 14:33:47');
INSERT INTO `edu_order` VALUES (14, 'ORD17772762534175E56', 3, 1, 'Spring Cloud微服务架构实战', 'http://localhost:9000/online-edu/cover/20260426/dc70cde60cb749ada979e9573dfc668e.png', '杨利军', 199.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-04-27 15:50:53', '2026-04-27 15:51:01');
INSERT INTO `edu_order` VALUES (15, 'ORD17772762729822EE5', 3, 4, '【2025最新】Docker与Kubernetes（K8s）从入门到实践全教程', 'http://localhost:9000/online-edu/cover/20260426/c9c3744c4cf349e19b1a279089fa9e83.png', '新盟教育', 169.00, 1, 'alipay', '2026-04-27 15:51:54', '2026042722001485880509669826', NULL, NULL, NULL, 0, 0, '2026-04-27 15:51:13', '2026-04-27 15:51:13');
INSERT INTO `edu_order` VALUES (16, 'ORD17772764336524515', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 5, 'alipay', '2026-04-27 15:55:33', '2026042722001485880509680514', '不想要了', '2026-04-27 15:56:13', NULL, 0, 0, '2026-04-27 15:53:54', '2026-04-27 15:56:13');
INSERT INTO `edu_order` VALUES (17, 'ORD17772772030792290', 3, 2, 'Vue3全栈开发精讲', 'http://localhost:9000/online-edu/cover/20260426/705528db3ec34a518da0c799189c581b.webp', 'Lison', 149.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-04-27 16:06:43', '2026-04-27 16:06:48');
INSERT INTO `edu_order` VALUES (18, 'ORD17772772140349FBB', 3, 2, 'Vue3全栈开发精讲', 'http://localhost:9000/online-edu/cover/20260426/705528db3ec34a518da0c799189c581b.webp', 'Lison', 149.00, 1, 'alipay', '2026-04-27 16:07:54', '2026042722001485880509667067', NULL, NULL, NULL, 0, 0, '2026-04-27 16:06:54', '2026-04-27 16:06:54');
INSERT INTO `edu_order` VALUES (19, 'ORD17772773059146541', 3, 5, 'React18入门到实战', 'http://localhost:9000/online-edu/cover/20260426/eeb17838b785424db5a81ed74a0dcd33.png', '黑马程序员', 159.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-04-27 16:08:26', '2026-04-27 16:08:32');
INSERT INTO `edu_order` VALUES (20, 'ORD17772941276402794', 3, 5, 'React18入门到实战', 'http://localhost:9000/online-edu/cover/20260426/eeb17838b785424db5a81ed74a0dcd33.png', '黑马程序员', 159.00, 1, 'alipay', '2026-04-27 20:49:15', '2026042722001485880509675662', NULL, NULL, NULL, 0, 0, '2026-04-27 20:48:48', '2026-04-27 20:48:48');
INSERT INTO `edu_order` VALUES (21, 'ORD1778159917416F0AC', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 21:18:37', '2026-05-07 21:18:57');
INSERT INTO `edu_order` VALUES (22, 'ORD17781599459025C19', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 21:19:06', '2026-05-07 21:47:38');
INSERT INTO `edu_order` VALUES (23, 'ORD1778161670131CAF1', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 21:47:50', '2026-05-07 21:51:06');
INSERT INTO `edu_order` VALUES (24, 'ORD177816187183404DE', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 21:51:12', '2026-05-07 21:53:01');
INSERT INTO `edu_order` VALUES (25, 'ORD17781621026004538', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 2, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 21:55:03', '2026-05-07 22:32:08');
INSERT INTO `edu_order` VALUES (26, 'ORD17781643565983CCE', 3, 7, '2024新版【微信小程序开发】', 'http://localhost:9000/online-edu/cover/20260426/277bcb7284934acc9b7ab9289c209f13.png', 'python收藏夹', 99.00, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '2026-05-07 22:32:37', '2026-05-07 22:32:37');
INSERT INTO `edu_order` VALUES (27, 'ORD1778164448678E6FA', 3, 3, 'Python零基础入门到机器学习', 'http://localhost:9000/online-edu/cover/20260426/b5dd9fa3f364484aaa2b5146d1edd4c3.png', '唐宇迪讲AI', 129.00, 1, 'alipay', '2026-05-07 22:35:08', '2026050722001485880509739505', NULL, NULL, NULL, 0, 0, '2026-05-07 22:34:09', '2026-05-07 22:34:09');

SET FOREIGN_KEY_CHECKS = 1;
