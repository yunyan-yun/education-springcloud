/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : edu_user

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 19/05/2026 19:55:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for edu_member
-- ----------------------------
DROP TABLE IF EXISTS `edu_member`;
CREATE TABLE `edu_member`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '手机号（登录账号）',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码（BCrypt加密）',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '昵称',
  `avatar` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '头像URL',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `gender` tinyint(4) NULL DEFAULT 0 COMMENT '性别：0未知 1男 2女',
  `intro` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '个人简介',
  `status` tinyint(4) NULL DEFAULT 1 COMMENT '状态：0禁用 1正常',
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT 'user' COMMENT '角色：user普通用户 / admin管理员',
  `open_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '第三方平台OpenId',
  `is_deleted` tinyint(4) NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `mobile`(`mobile`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  INDEX `idx_mobile`(`mobile`) USING BTREE,
  INDEX `idx_username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '会员表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of edu_member
-- ----------------------------
INSERT INTO `edu_member` VALUES (1, '13800000000', 'admin', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O', '管理员', NULL, NULL, 0, NULL, 1, 'admin', NULL, 0, '2026-04-24 17:10:39', '2026-04-24 17:10:39');
INSERT INTO `edu_member` VALUES (2, '13800000001', 'test001', '$2a$10$Wt5uRor2.TQVxctrkrMMdewYqpxNoqMQekwCyf2VYHjpvojctG96W', '测试用户1', 'http://localhost:9000/online-edu/avatar/20260426/321ec43a82aa42dc87978eced33b33cb.jpg', '', 0, '', 1, 'user', NULL, 0, '2026-04-24 17:10:39', '2026-04-24 17:10:39');
INSERT INTO `edu_member` VALUES (3, '13800000002', 'test002', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O', '测试用户02', NULL, NULL, 0, NULL, 1, 'user', NULL, 0, '2026-04-24 17:10:39', '2026-05-10 14:51:30');
INSERT INTO `edu_member` VALUES (4, '13800000003', 'test003', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O', '张小明', NULL, NULL, 0, NULL, 1, 'user', NULL, 0, '2026-04-24 17:10:39', '2026-04-24 17:10:39');
INSERT INTO `edu_member` VALUES (5, '13800000004', 'test004', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O', '李晓红', NULL, NULL, 0, NULL, 1, 'user', NULL, 0, '2026-04-24 17:10:39', '2026-04-24 17:10:39');
INSERT INTO `edu_member` VALUES (6, '13800000005', 'test005', '$2a$10$QMIgvuYnfI4JWNju24pxIexugK.m1.m10TH3haN2ojHRv4hbHyd/O', '王大力', NULL, NULL, 0, NULL, 1, 'user', NULL, 0, '2026-04-24 17:10:39', '2026-04-24 17:10:39');

SET FOREIGN_KEY_CHECKS = 1;
